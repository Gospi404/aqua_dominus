// Made with Blockbench 5.2.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modeldrake_skeleton<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "drake_skeleton"), "main");
	private final ModelPart body;
	private final ModelPart head;
	private final ModelPart left_arm;
	private final ModelPart up_left_arm;
	private final ModelPart bottom_left_arm;
	private final ModelPart right_arm;
	private final ModelPart up_right_arm;
	private final ModelPart bottom_right_arm;
	private final ModelPart left_leg;
	private final ModelPart up_left_leg;
	private final ModelPart bottom_left_leg;
	private final ModelPart right_leg;
	private final ModelPart up_right_leg;
	private final ModelPart bottom_right_leg;

	public Modeldrake_skeleton(ModelPart root) {
		this.body = root.getChild("body");
		this.head = this.body.getChild("head");
		this.left_arm = root.getChild("left_arm");
		this.up_left_arm = this.left_arm.getChild("up_left_arm");
		this.bottom_left_arm = this.left_arm.getChild("bottom_left_arm");
		this.right_arm = root.getChild("right_arm");
		this.up_right_arm = this.right_arm.getChild("up_right_arm");
		this.bottom_right_arm = this.right_arm.getChild("bottom_right_arm");
		this.left_leg = root.getChild("left_leg");
		this.up_left_leg = this.left_leg.getChild("up_left_leg");
		this.bottom_left_leg = this.left_leg.getChild("bottom_left_leg");
		this.right_leg = root.getChild("right_leg");
		this.up_right_leg = this.right_leg.getChild("up_right_leg");
		this.bottom_right_leg = this.right_leg.getChild("bottom_right_leg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition body = partdefinition.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(6, 41)
						.addBox(-4.05F, -5.8F, -2.0F, 8.0F, 6.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 51)
						.addBox(-6.05F, -12.8F, -3.0F, 12.0F, 7.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(45, 0)
						.addBox(-6.55F, -12.8F, -3.5F, 13.0F, 8.0F, 7.0F, new CubeDeformation(0.25F)).texOffs(51, 16)
						.addBox(-4.55F, -5.05F, -3.5F, 9.0F, 13.0F, 6.0F, new CubeDeformation(0.15F)),
				PartPose.offset(0.05F, 8.8F, 0.0F));

		PartDefinition head = body.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0)
						.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(34, 37)
						.addBox(-7.0F, -13.0F, -4.5F, 14.0F, 7.0F, 9.0F, new CubeDeformation(0.01F)).texOffs(0, 16)
						.addBox(-4.5F, -12.0F, -4.5F, 9.0F, 6.0F, 9.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-0.05F, -12.8F, 0.0F));

		PartDefinition left_arm = partdefinition.addOrReplaceChild("left_arm", CubeListBuilder.create(),
				PartPose.offset(6.0F, -2.0F, 0.0F));

		PartDefinition up_left_arm = left_arm.addOrReplaceChild("up_left_arm",
				CubeListBuilder.create().texOffs(85, 0).mirror()
						.addBox(-0.75F, -2.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(85, 23).mirror()
						.addBox(-0.75F, -2.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.25F)).mirror(false),
				PartPose.offset(0.0F, -0.5F, 0.0F));

		PartDefinition bottom_left_arm = left_arm.addOrReplaceChild("bottom_left_arm", CubeListBuilder.create()
				.texOffs(87, 12).mirror().addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F, new CubeDeformation(0.0F))
				.mirror(false).texOffs(87, 35).mirror()
				.addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F, new CubeDeformation(0.25F)).mirror(false).texOffs(32, 12)
				.mirror().addBox(-1.0F, 5.5F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(1.0F, 4.5F, 0.0F));

		PartDefinition right_arm = partdefinition.addOrReplaceChild("right_arm", CubeListBuilder.create(),
				PartPose.offset(-6.0F, -2.0F, 0.0F));

		PartDefinition up_right_arm = right_arm.addOrReplaceChild("up_right_arm",
				CubeListBuilder.create().texOffs(85, 0)
						.addBox(-3.25F, -2.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(85, 23)
						.addBox(-3.25F, -2.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, -0.5F, 0.0F));

		PartDefinition bottom_right_arm = right_arm.addOrReplaceChild("bottom_right_arm",
				CubeListBuilder.create().texOffs(87, 12)
						.addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(87, 35)
						.addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F, new CubeDeformation(0.25F)).texOffs(32, 12)
						.addBox(-1.0F, 5.5F, -1.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-1.0F, 4.5F, 0.0F));

		PartDefinition left_leg = partdefinition.addOrReplaceChild("left_leg", CubeListBuilder.create(),
				PartPose.offset(2.5F, 9.0F, 0.0F));

		PartDefinition up_left_leg = left_leg.addOrReplaceChild("up_left_leg",
				CubeListBuilder.create().texOffs(101, 0).mirror()
						.addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(101, 23).mirror()
						.addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.25F)).mirror(false),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bottom_left_leg = left_leg.addOrReplaceChild("bottom_left_leg",
				CubeListBuilder.create().texOffs(103, 12).mirror()
						.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false)
						.texOffs(103, 35).mirror()
						.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F, new CubeDeformation(0.25F)).mirror(false),
				PartPose.offset(0.0F, 8.0F, 0.0F));

		PartDefinition right_leg = partdefinition.addOrReplaceChild("right_leg", CubeListBuilder.create(),
				PartPose.offset(-2.5F, 9.0F, 0.0F));

		PartDefinition up_right_leg = right_leg.addOrReplaceChild("up_right_leg",
				CubeListBuilder.create().texOffs(101, 0)
						.addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(101, 23)
						.addBox(-2.0F, 0.0F, -2.0F, 4.0F, 8.0F, 4.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, 0.0F, 0.0F));

		PartDefinition bottom_right_leg = right_leg.addOrReplaceChild("bottom_right_leg",
				CubeListBuilder.create().texOffs(103, 12)
						.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(103, 35)
						.addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F, new CubeDeformation(0.25F)),
				PartPose.offset(0.0F, 8.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 128, 64);
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		left_arm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		right_arm.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		left_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		right_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {
		this.head.yRot = netHeadYaw / (180F / (float) Math.PI);
		this.head.xRot = headPitch / (180F / (float) Math.PI);
	}
}
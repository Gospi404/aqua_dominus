// Made with Blockbench 5.2.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelprismy<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "prismy"), "main");
	private final ModelPart body;
	private final ModelPart eye;
	private final ModelPart tail;
	private final ModelPart tail2;
	private final ModelPart spine1;
	private final ModelPart spine1_rotation;
	private final ModelPart spine2;
	private final ModelPart spine3_rotation;
	private final ModelPart spine3;
	private final ModelPart spine4_rotation;
	private final ModelPart spine4;
	private final ModelPart spine9_rotation;

	public Modelprismy(ModelPart root) {
		this.body = root.getChild("body");
		this.eye = root.getChild("eye");
		this.tail = root.getChild("tail");
		this.tail2 = root.getChild("tail2");
		this.spine1 = root.getChild("spine1");
		this.spine1_rotation = this.spine1.getChild("spine1_rotation");
		this.spine2 = root.getChild("spine2");
		this.spine3_rotation = this.spine2.getChild("spine3_rotation");
		this.spine3 = root.getChild("spine3");
		this.spine4_rotation = this.spine3.getChild("spine4_rotation");
		this.spine4 = root.getChild("spine4");
		this.spine9_rotation = this.spine4.getChild("spine9_rotation");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition body = partdefinition.addOrReplaceChild("body", CubeListBuilder.create().texOffs(8, 0).addBox(
				-4.0F, 12.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 4.0F, 0.0F));

		PartDefinition eye = partdefinition.addOrReplaceChild("eye", CubeListBuilder.create().texOffs(8, 0)
				.addBox(-1.0F, -1.0F, -0.5F, 2.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 20.5F, -3.75F));

		PartDefinition tail = partdefinition.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(30, 16).addBox(
				-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 20.0F, 4.0F));

		PartDefinition tail2 = partdefinition.addOrReplaceChild("tail2",
				CubeListBuilder.create().texOffs(20, 18)
						.addBox(-1.25F, -1.0F, 0.0F, 2.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(32, -7)
						.addBox(-0.25F, -3.5F, 0.0F, 0.0F, 7.0F, 7.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.25F, 20.0F, 8.0F));

		PartDefinition spine1 = partdefinition.addOrReplaceChild("spine1", CubeListBuilder.create(),
				PartPose.offset(0.0F, 12.5F, 0.0F));

		PartDefinition spine1_rotation = spine1.addOrReplaceChild("spine1_rotation", CubeListBuilder.create()
				.texOffs(0, 3).addBox(-1.0F, 3.0F, -1.0F, 2.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.5F, 0.0F));

		PartDefinition spine2 = partdefinition.addOrReplaceChild("spine2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(7.5F, 20.5F, 0.0F, 0.0F, 0.0F, 1.5708F));

		PartDefinition spine3_rotation = spine2.addOrReplaceChild("spine3_rotation", CubeListBuilder.create()
				.texOffs(0, 3).addBox(-1.0F, 3.0F, -1.0F, 2.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.5F, 0.0F));

		PartDefinition spine3 = partdefinition.addOrReplaceChild("spine3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-7.5F, 20.5F, 0.0F, 0.0F, 0.0F, -1.5708F));

		PartDefinition spine4_rotation = spine3.addOrReplaceChild("spine4_rotation", CubeListBuilder.create()
				.texOffs(0, 3).addBox(-1.0F, 3.0F, -1.0F, 2.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -2.5F, 0.0F));

		PartDefinition spine4 = partdefinition.addOrReplaceChild("spine4", CubeListBuilder.create(),
				PartPose.offset(0.0F, 29.5F, 0.0F));

		PartDefinition spine9_rotation = spine4
				.addOrReplaceChild("spine9_rotation",
						CubeListBuilder.create().texOffs(0, 3).addBox(-1.0F, 3.0F, -1.0F, 2.0F, 5.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.5F, 0.0F, 3.1416F, 0.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		body.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		eye.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		tail.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		tail2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		spine1.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		spine2.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		spine3.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		spine4.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
// Made with Blockbench 5.2.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelseaper<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "seaper"), "main");
	private final ModelPart Head;
	private final ModelPart left_front_leg;
	private final ModelPart right_front_leg;
	private final ModelPart left_back_leg;
	private final ModelPart right_back_leg;

	public Modelseaper(ModelPart root) {
		this.Head = root.getChild("Head");
		this.left_front_leg = root.getChild("left_front_leg");
		this.right_front_leg = root.getChild("right_front_leg");
		this.left_back_leg = root.getChild("left_back_leg");
		this.right_back_leg = root.getChild("right_back_leg");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition Head = partdefinition.addOrReplaceChild("Head",
				CubeListBuilder.create().texOffs(0, 24)
						.addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(-6.0F, -12.0F, -6.0F, 12.0F, 12.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition left_front_leg = partdefinition.addOrReplaceChild("left_front_leg",
				CubeListBuilder.create().texOffs(32, 24).addBox(-1.0F, 0.0F, -2.5F, 13.0F, 0.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0F, 24.0F, -2.0F, 0.6155F, 0.5236F, 0.9553F));

		PartDefinition right_front_leg = partdefinition.addOrReplaceChild("right_front_leg",
				CubeListBuilder.create().texOffs(32, 24).addBox(-12.0F, 0.0F, -2.5F, 13.0F, 0.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.0F, 24.0F, -2.0F, 0.6155F, -0.5236F, -0.9553F));

		PartDefinition left_back_leg = partdefinition.addOrReplaceChild("left_back_leg",
				CubeListBuilder.create().texOffs(32, 24).addBox(-1.0F, 0.0F, -2.5F, 13.0F, 0.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0F, 24.0F, 2.0F, -0.6155F, -0.5236F, 0.9553F));

		PartDefinition right_back_leg = partdefinition.addOrReplaceChild("right_back_leg",
				CubeListBuilder.create().texOffs(32, 24).addBox(-12.0F, 0.0F, -2.5F, 13.0F, 0.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.0F, 24.0F, 2.0F, -0.6155F, 0.5236F, -0.9553F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		Head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		left_front_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		right_front_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		left_back_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		right_back_leg.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
package com.gospi.aquadominus;

import com.gospi.aquadominus.registry.ModRegistry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

@Mod(AquaDominus.MODID)
public class AquaDominus {
    public static final String MODID = "aqua_dominus";

    /** Ваша существующая вкладка из beacon/ModRegistry: aqua_dominus:beacons */
    private static final ResourceKey<CreativeModeTab> BEACONS_TAB =
            ResourceKey.create(Registries.CREATIVE_MODE_TAB, ModRegistry.id("beacons"));

    public AquaDominus(IEventBus modBus) {
        modBus.addListener(ModRegistry::onRegister);
        modBus.addListener(AquaDominus::onTab);
    }

    private static void onTab(BuildCreativeModeTabContentsEvent e) {
        if (!e.getTabKey().equals(BEACONS_TAB)) return;
        e.accept(ModRegistry.DEEP_LANTERN_ITEM);
        e.accept(ModRegistry.ANKLE_WEIGHT);
    }
}
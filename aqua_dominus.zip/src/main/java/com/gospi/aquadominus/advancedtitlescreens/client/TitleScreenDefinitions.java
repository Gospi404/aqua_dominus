package com.gospi.aquadominus.advancedtitlescreens.client;

import net.minecraft.util.RandomSource;

import javax.annotation.Nullable;

import java.util.List;
import java.util.ArrayList;

/** Advanced Title Screens: every Custom Title Screen element defined in this mod. */
public final class TitleScreenDefinitions {
	public static final List<TitleScreenDef> ALL = new ArrayList<>();
	@Nullable
	private static TitleScreenDef active;
	private static boolean picked;
	static {
		build();
		TitleScreenApi.applySaved();
	}

	private static void build() {
		ALL.add(create_TetropiaMenu());
	}

	/** Rebuilds every definition exactly as designed (keeps the same title screen picked), then re-applies the
	 *  procedure changes that are still kept. */
	static synchronized void reload() {
		String keep = active == null ? null : active.id;
		ALL.clear();
		build();
		active = null;
		for (TitleScreenDef def : ALL)
			if (def.id.equals(keep))
				active = def;
		picked = active != null;
		TitleScreenApi.reapply();
	}

	private TitleScreenDefinitions() {
	}

	/** The title screen used for this game session: a weighted random pick among enabled ones, made once. */
	@Nullable
	public static TitleScreenDef active() {
		if (!picked) {
			picked = true;
			int total = 0;
			for (TitleScreenDef def : ALL)
				if (def.enabled)
					total += Math.max(1, def.selectionWeight);
			if (total > 0) {
				int roll = RandomSource.create().nextInt(total);
				for (TitleScreenDef def : ALL) {
					if (!def.enabled)
						continue;
					roll -= Math.max(1, def.selectionWeight);
					if (roll < 0) {
						active = def;
						break;
					}
				}
			}
		}
		return active;
	}

	private static TitleScreenDef create_TetropiaMenu() {
		TitleScreenDef d = new TitleScreenDef("TetropiaMenu");
		d.enabled = true;
		d.selectionWeight = 1;
		d.introFade = true;
		d.introFadeMs = 2000;
		d.introOnlyOnce = true;
		d.showBranding = true;
		d.showCopyright = false;
		d.backgroundType = "GRADIENT";
		d.panoramaFaces[0] = null;
		d.panoramaFaces[1] = null;
		d.panoramaFaces[2] = null;
		d.panoramaFaces[3] = null;
		d.panoramaFaces[4] = null;
		d.panoramaFaces[5] = null;
		d.panoramaSpeed = 2;
		d.panoramaPitch = 10;
		d.panoramaOverlay = true;
		d.panoramaDistance = 0;
		d.panoramaFov = 85;
		d.backgroundImage = null;
		d.imageScaling = "COVER";
		d.slideshowImages.removeIf(java.util.Objects::isNull);
		d.slideDurationMs = 7000;
		d.slideFadeMs = 1500;
		d.slideshowShuffle = false;
		d.kenBurns = true;
		d.video = "";
		d.videoLoop = true;
		d.videoEndBehavior = "HOLD";
		d.backgroundColor = 1776420;
		d.gradientTopColor = 1214378;
		d.gradientBottomColor = 266532;
		d.parallax = false;
		d.parallaxStrength = 12;
		d.overlayColor = 0;
		d.overlayOpacity = 0;
		d.vignette = true;
		d.vignetteStrength = 55;
		d.blurBackground = false;
		d.particleType = "NONE";
		d.particleColor = 16777215;
		d.particleCount = 60;
		d.particleSpeed = 1;
		d.particleSize = 2;
		d.particleTexture = null;
		d.logoType = "TEXT";
		d.logoImage = null;
		d.logoWidth = 256;
		d.logoHeight = 64;
		d.logoText = "Tetropia";
		d.logoFont = "";
		d.logoTextColor = 10865401;
		d.logoTextScale = 3.5;
		d.logoTextShadow = true;
		d.logoAnchor = "CENTER_LEFT";
		d.logoX = 28;
		d.logoY = -62;
		d.logoAnimation = "BOB";
		d.logoAnimationSpeed = 0.5;
		d.splashMode = "NONE";
		d.customSplashes.add("Welcome back, %player%!");
		d.splashColor = 16762987;
		d.splashFont = "";
		d.splashScale = 1;
		d.splashRotation = -12;
		d.splashPulse = true;
		d.splashAttachToLogo = true;
		d.splashAnchor = "TOP_CENTER";
		d.splashX = -5;
		d.splashY = 39;
		{
			TitleScreenDef.ButtonDef b = new TitleScreenDef.ButtonDef();
			b.menu = "TITLE";
			b.order = 2;
			b.page = "main";
			b.id = "button1";
			b.hidden = false;
			b.label = "lang:menu.singleplayer";
			b.action = "SINGLEPLAYER";
			b.actionValue = "";
			b.tooltip = "";
			b.anchor = "CENTER_LEFT";
			b.x = 28;
			b.y = -30;
			b.width = 180;
			b.height = 18;
			b.style = "TEXT";
			b.texture = null;
			b.hoverTexture = null;
			b.textureTint = 16777215;
			b.hoverTextureTint = 16777215;
			b.backgroundColor = 0;
			b.backgroundOpacity = 55;
			b.hoverBackgroundColor = 16777215;
			b.hoverBackgroundOpacity = 25;
			b.borderColor = 16777215;
			b.hoverBorderColor = 16777215;
			b.borderThickness = 0;
			b.textColor = 15263976;
			b.hoverTextColor = 7256570;
			b.font = "";
			b.textScale = 1.5;
			b.textShadow = true;
			b.textAlign = "LEFT";
			b.underlineOnHover = false;
			b.hoverEffect = "SLIDE";
			b.icon = null;
			b.vanillaIcon = "NONE";
			b.iconSize = 16;
			b.clickSound = null;
			b.hoverSound = null;
			d.buttons.add(b);
		}
		{
			TitleScreenDef.ButtonDef b = new TitleScreenDef.ButtonDef();
			b.menu = "TITLE";
			b.order = 3;
			b.page = "main";
			b.id = "button2";
			b.hidden = false;
			b.label = "lang:menu.multiplayer";
			b.action = "MULTIPLAYER";
			b.actionValue = "";
			b.tooltip = "";
			b.anchor = "CENTER_LEFT";
			b.x = 28;
			b.y = -9;
			b.width = 180;
			b.height = 18;
			b.style = "TEXT";
			b.texture = null;
			b.hoverTexture = null;
			b.textureTint = 16777215;
			b.hoverTextureTint = 16777215;
			b.backgroundColor = 0;
			b.backgroundOpacity = 55;
			b.hoverBackgroundColor = 16777215;
			b.hoverBackgroundOpacity = 25;
			b.borderColor = 16777215;
			b.hoverBorderColor = 16777215;
			b.borderThickness = 0;
			b.textColor = 15263976;
			b.hoverTextColor = 7256570;
			b.font = "";
			b.textScale = 1.5;
			b.textShadow = true;
			b.textAlign = "LEFT";
			b.underlineOnHover = false;
			b.hoverEffect = "SLIDE";
			b.icon = null;
			b.vanillaIcon = "NONE";
			b.iconSize = 16;
			b.clickSound = null;
			b.hoverSound = null;
			d.buttons.add(b);
		}
		{
			TitleScreenDef.ButtonDef b = new TitleScreenDef.ButtonDef();
			b.menu = "TITLE";
			b.order = 4;
			b.page = "main";
			b.id = "button3";
			b.hidden = false;
			b.label = "lang:fml.menu.mods";
			b.action = "MODS";
			b.actionValue = "";
			b.tooltip = "";
			b.anchor = "CENTER_LEFT";
			b.x = 28;
			b.y = 14;
			b.width = 180;
			b.height = 18;
			b.style = "TEXT";
			b.texture = null;
			b.hoverTexture = null;
			b.textureTint = 16777215;
			b.hoverTextureTint = 16777215;
			b.backgroundColor = 0;
			b.backgroundOpacity = 55;
			b.hoverBackgroundColor = 16777215;
			b.hoverBackgroundOpacity = 25;
			b.borderColor = 16777215;
			b.hoverBorderColor = 16777215;
			b.borderThickness = 0;
			b.textColor = 15263976;
			b.hoverTextColor = 7256570;
			b.font = "";
			b.textScale = 1.5;
			b.textShadow = true;
			b.textAlign = "LEFT";
			b.underlineOnHover = false;
			b.hoverEffect = "SLIDE";
			b.icon = null;
			b.vanillaIcon = "NONE";
			b.iconSize = 16;
			b.clickSound = null;
			b.hoverSound = null;
			d.buttons.add(b);
		}
		{
			TitleScreenDef.ButtonDef b = new TitleScreenDef.ButtonDef();
			b.menu = "TITLE";
			b.order = 5;
			b.page = "main";
			b.id = "button4";
			b.hidden = false;
			b.label = "lang:menu.options";
			b.action = "OPTIONS";
			b.actionValue = "";
			b.tooltip = "";
			b.anchor = "CENTER_LEFT";
			b.x = 28;
			b.y = 36;
			b.width = 180;
			b.height = 18;
			b.style = "TEXT";
			b.texture = null;
			b.hoverTexture = null;
			b.textureTint = 16777215;
			b.hoverTextureTint = 16777215;
			b.backgroundColor = 0;
			b.backgroundOpacity = 55;
			b.hoverBackgroundColor = 16777215;
			b.hoverBackgroundOpacity = 25;
			b.borderColor = 16777215;
			b.hoverBorderColor = 16777215;
			b.borderThickness = 0;
			b.textColor = 15263976;
			b.hoverTextColor = 7256570;
			b.font = "";
			b.textScale = 1.5;
			b.textShadow = true;
			b.textAlign = "LEFT";
			b.underlineOnHover = false;
			b.hoverEffect = "SLIDE";
			b.icon = null;
			b.vanillaIcon = "NONE";
			b.iconSize = 16;
			b.clickSound = null;
			b.hoverSound = null;
			d.buttons.add(b);
		}
		{
			TitleScreenDef.ButtonDef b = new TitleScreenDef.ButtonDef();
			b.menu = "TITLE";
			b.order = 6;
			b.page = "main";
			b.id = "button5";
			b.hidden = false;
			b.label = "lang:menu.quit";
			b.action = "QUIT";
			b.actionValue = "";
			b.tooltip = "";
			b.anchor = "CENTER_LEFT";
			b.x = 30;
			b.y = 59;
			b.width = 180;
			b.height = 18;
			b.style = "TEXT";
			b.texture = null;
			b.hoverTexture = null;
			b.textureTint = 16777215;
			b.hoverTextureTint = 16777215;
			b.backgroundColor = 0;
			b.backgroundOpacity = 55;
			b.hoverBackgroundColor = 16777215;
			b.hoverBackgroundOpacity = 25;
			b.borderColor = 16777215;
			b.hoverBorderColor = 16777215;
			b.borderThickness = 0;
			b.textColor = 15263976;
			b.hoverTextColor = 16711680;
			b.font = "";
			b.textScale = 1.5;
			b.textShadow = true;
			b.textAlign = "LEFT";
			b.underlineOnHover = false;
			b.hoverEffect = "SLIDE";
			b.icon = null;
			b.vanillaIcon = "NONE";
			b.iconSize = 16;
			b.clickSound = null;
			b.hoverSound = null;
			d.buttons.add(b);
		}
		{
			TitleScreenDef.TextDef t = new TitleScreenDef.TextDef();
			t.menu = "TITLE";
			t.order = 7;
			t.page = "main";
			t.id = "text1";
			t.hidden = false;
			t.text = "&7Aqua Dominus &8v%modversion%";
			t.anchor = "BOTTOM_RIGHT";
			t.x = -4;
			t.y = -5;
			t.color = 16777215;
			t.opacity = 100;
			t.font = "";
			t.scale = 0.75;
			t.shadow = true;
			t.url = "";
			t.hoverColor = 16777215;
			t.rotation = 0;
			t.animation = "NONE";
			t.animationSpeed = 1;
			d.texts.add(t);
		}
		{
			TitleScreenDef.WidgetDef w = new TitleScreenDef.WidgetDef();
			w.kind = "EFFECT";
			w.id = "effect2";
			w.hidden = false;
			w.menu = "TITLE";
			w.order = 0;
			w.page = "";
			w.anchor = "CENTER";
			w.x = 0;
			w.y = 0;
			w.width = 200;
			w.height = 120;
			w.opacity = 100;
			w.rotation = 0;
			w.color = 6001876;
			w.color2 = 0;
			w.opacity2 = 0;
			w.gradient = "NONE";
			w.borderColor = 16777215;
			w.borderThickness = 0;
			w.texture = TitleScreenDef.rl("aqua_dominus:textures/screens/bubble.png");
			w.tint = 16777215;
			w.stretch = "BOTH";
			w.skinMode = "BUST";
			w.model3d = false;
			w.skinFit = true;
			w.skinScale = 2;
			w.skinOffsetX = 0;
			w.skinOffsetY = 0;
			w.skinClip = true;
			w.followMouse = true;
			w.modelYaw = 20;
			w.modelSpin = 0;
			w.texture2 = null;
			w.spinX = 0;
			w.spinY = 30;
			w.spinZ = 0;
			w.tiltX = 20;
			w.tiltY = 30;
			w.shading = true;
			w.glowColor = 16777215;
			w.glowOpacity = 0;
			w.glowSize = 250;
			w.rowHeight = 28;
			w.textColor = 16777215;
			w.secondaryColor = 10526880;
			w.hoverColor = 3815994;
			w.showMotd = true;
			w.effectType = "BUBBLES";
			w.effectCount = 65;
			w.effectSpeed = 1;
			w.effectSize = 2;
			w.layer = "WIDGETS";
			w.layerIndex = 0;
			d.widgets.add(w);
		}
		{
			TitleScreenDef.WidgetDef w = new TitleScreenDef.WidgetDef();
			w.kind = "PANEL";
			w.id = "widget1";
			w.hidden = false;
			w.menu = "TITLE";
			w.order = 1;
			w.page = "";
			w.anchor = "TOP_LEFT";
			w.x = 0;
			w.y = 0;
			w.width = 240;
			w.height = 80;
			w.opacity = 70;
			w.rotation = 0;
			w.color = 0;
			w.color2 = 0;
			w.opacity2 = 0;
			w.gradient = "HORIZONTAL";
			w.borderColor = 16777215;
			w.borderThickness = 0;
			w.texture = null;
			w.tint = 16777215;
			w.stretch = "HEIGHT";
			w.skinMode = "BUST";
			w.model3d = false;
			w.skinFit = true;
			w.skinScale = 2;
			w.skinOffsetX = 0;
			w.skinOffsetY = 0;
			w.skinClip = true;
			w.followMouse = true;
			w.modelYaw = 20;
			w.modelSpin = 0;
			w.texture2 = null;
			w.spinX = 0;
			w.spinY = 30;
			w.spinZ = 0;
			w.tiltX = 20;
			w.tiltY = 30;
			w.shading = true;
			w.glowColor = 16777215;
			w.glowOpacity = 0;
			w.glowSize = 250;
			w.rowHeight = 28;
			w.textColor = 16777215;
			w.secondaryColor = 10526880;
			w.hoverColor = 3815994;
			w.showMotd = true;
			w.effectType = "SNOW";
			w.effectCount = 60;
			w.effectSpeed = 1;
			w.effectSize = 2;
			w.layer = "WIDGETS";
			w.layerIndex = 0;
			d.widgets.add(w);
		}
		d.pages.add("main");
		d.pageTransitionMs = 250;
		d.confirmLinks = true;
		d.scaleLayout = true;
		d.designWidth = 427;
		d.designHeight = 240;
		d.buttonEntrance = "SLIDE_LEFT";
		d.buttonEntranceDurationMs = 600;
		d.buttonEntranceStaggerMs = 70;
		d.musicMode = "CUSTOM";
		d.music = TitleScreenDef.rl("music.under_water");
		d.musicMinDelay = 20;
		d.musicMaxDelay = 600;
		d.musicInSubmenus = true;
		d.stopMusicInWorld = true;
		d.openSound = null;
		d.cursorMode = "TEXTURE";
		d.cursorTexture = TitleScreenDef.rl("aqua_dominus:textures/screens/pointer.png");
		d.cursorHoverTexture = TitleScreenDef.rl("aqua_dominus:textures/screens/hover.png");
		d.cursorSize = 12;
		d.cursorHotspotX = 0;
		d.cursorHotspotY = 0;
		d.trailType = "TEXTURE";
		d.trailColor = 2869247;
		d.trailColor2 = 2053631;
		d.trailSize = 1;
		d.trailDensity = 4;
		d.trailLifetimeMs = 600;
		d.trailGravity = -100;
		d.trailTexture = TitleScreenDef.rl("aqua_dominus:textures/screens/bubble.png");
		d.clickEffect = "NONE";
		d.clickColor = 16777215;
		d.clickCount = 12;
		d.clickSize = 2;
		d.mouseFxTitle = true;
		d.mouseFxPause = true;
		d.mouseFxOptions = true;
		d.mouseFxMods = true;
		d.mouseFxOther = false;
		d.pauseMenu.enabled = false;
		d.pauseMenu.mode = "DECORATE";
		d.pauseMenu.background = "KEEP";
		d.pauseMenu.image = null;
		d.pauseMenu.imageScaling = "COVER";
		d.pauseMenu.color = 1052692;
		d.pauseMenu.gradientTopColor = 1976906;
		d.pauseMenu.gradientBottomColor = 526348;
		d.pauseMenu.overlayColor = 0;
		d.pauseMenu.overlayOpacity = 0;
		d.pauseMenu.blur = false;
		d.pauseMenu.vignette = false;
		d.pauseMenu.vignetteStrength = 60;
		d.pauseMenu.particles = false;
		d.optionsMenu.enabled = false;
		d.optionsMenu.mode = "DECORATE";
		d.optionsMenu.background = "KEEP";
		d.optionsMenu.image = null;
		d.optionsMenu.imageScaling = "COVER";
		d.optionsMenu.color = 1052692;
		d.optionsMenu.gradientTopColor = 1976906;
		d.optionsMenu.gradientBottomColor = 526348;
		d.optionsMenu.overlayColor = 0;
		d.optionsMenu.overlayOpacity = 0;
		d.optionsMenu.blur = false;
		d.optionsMenu.vignette = false;
		d.optionsMenu.vignetteStrength = 60;
		d.optionsMenu.particles = false;
		d.modsMenu.enabled = false;
		d.modsMenu.mode = "DECORATE";
		d.modsMenu.background = "KEEP";
		d.modsMenu.image = null;
		d.modsMenu.imageScaling = "COVER";
		d.modsMenu.color = 1052692;
		d.modsMenu.gradientTopColor = 1976906;
		d.modsMenu.gradientBottomColor = 526348;
		d.modsMenu.overlayColor = 0;
		d.modsMenu.overlayOpacity = 0;
		d.modsMenu.blur = false;
		d.modsMenu.vignette = false;
		d.modsMenu.vignetteStrength = 60;
		d.modsMenu.particles = false;
		return d;
	}
}
package com.gospi.aquadominus.api;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.Event;

/** Публикуется модом маяков (aqua_dominus) в NeoForge.EVENT_BUS, когда маяк полностью включён. */
public class BeaconActivatedEvent extends Event {
    private final ServerPlayer player;
    private final BeaconSide side;
    private final BlockPos pos;

    public BeaconActivatedEvent(ServerPlayer player, BeaconSide side, BlockPos pos) {
        this.player = player;
        this.side = side;
        this.pos = pos;
    }

    public ServerPlayer player() { return player; }
    public BeaconSide side() { return side; }
    public BlockPos pos() { return pos; }
}

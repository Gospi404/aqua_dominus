package com.gospi.aquadominus.api;

/** Четыре маяка. Общий для связанных модов enum. */
public enum BeaconSide { NORTH, SOUTH, WEST, EAST }

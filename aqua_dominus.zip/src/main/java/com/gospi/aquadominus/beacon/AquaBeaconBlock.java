package com.gospi.aquadominus.beacon;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;

public class AquaBeaconBlock extends Block implements EntityBlock {
    public static final MapCodec<AquaBeaconBlock> CODEC = simpleCodec(p -> new AquaBeaconBlock(p, BeaconType.NORTH));
    public static final BooleanProperty ACTIVE = BooleanProperty.create("active");

    private final BeaconType type;

    public AquaBeaconBlock(Properties properties, BeaconType type) {
        super(properties);
        this.type = type;
        registerDefaultState(stateDefinition.any().setValue(ACTIVE, false));
    }

    public BeaconType type() { return type; }

    @Override
    protected MapCodec<? extends Block> codec() { return CODEC; }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new AquaBeaconBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> betype) {
        if (level.isClientSide() || betype != ModRegistry.BEACON_BE.get()) {
            return null;
        }
        return (l, p, s, be) -> AquaBeaconBlockEntity.serverTick(l, p, s, (AquaBeaconBlockEntity) be);
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer sp && level.getBlockEntity(pos) instanceof AquaBeaconBlockEntity be) {
            be.interact(sp, stack);
        }
        return InteractionResult.SUCCESS_SERVER;
    }
}

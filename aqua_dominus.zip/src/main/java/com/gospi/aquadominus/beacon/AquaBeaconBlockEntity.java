package com.gospi.aquadominus.beacon;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.mojang.serialization.Codec;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.UUIDUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.neoforged.neoforge.common.NeoForge;

import com.gospi.aquadominus.api.BeaconActivatedEvent;
import com.gospi.aquadominus.api.BeaconSide;

public class AquaBeaconBlockEntity extends BlockEntity {
    private static final Item[] DYES = {Items.BLUE_DYE, Items.CYAN_DYE, Items.LIME_DYE, Items.WHITE_DYE};
    private static final int[] DYE_COLORS = {0x3C44AA, 0x158991, 0x80C71F, 0xF9FFFE};
    private static final float[] PITCH = {0.63f, 0.84f, 1.12f, 1.5f};
    private static final Identifier STATE_KEY = Identifier.fromNamespaceAndPath(ModRegistry.MODID, "state");

    private BeaconStage stage = BeaconStage.DORMANT;
    private List<Integer> puzzle = new ArrayList<>();
    private int puzzleProgress;
    private boolean waveRunning;
    private boolean waveSpawned;
    private int waveIndex;
    private int waveDelay;
    private int emptySeconds;
    private List<UUID> mobs = new ArrayList<>();
    private long lastInput = -1000;
    private UUID starter;
    private long capturedUntil;

    public AquaBeaconBlockEntity(BlockPos pos, BlockState state) {
        super(ModRegistry.BEACON_BE.get(), pos, state);
    }

    public BeaconType type() {
        return ((AquaBeaconBlock) getBlockState().getBlock()).type();
    }

    // ================= Сохранение =================

    @Override
    protected void saveAdditional(ValueOutput out) {
        super.saveAdditional(out);
        out.putInt("stage", stage.ordinal());
        out.putInt("puzzle_progress", puzzleProgress);
        out.putLong("captured_until", capturedUntil);
        out.store("puzzle", Codec.INT.listOf(), puzzle);
        out.putBoolean("wave_running", waveRunning);
        out.putBoolean("wave_spawned", waveSpawned);
        out.putInt("wave_index", waveIndex);
        out.putInt("wave_delay", waveDelay);
        out.store("mobs", UUIDUtil.CODEC.listOf(), mobs);
        if (starter != null) out.store("starter", UUIDUtil.CODEC, starter);
    }

    @Override
    protected void loadAdditional(ValueInput in) {
        super.loadAdditional(in);
        stage = BeaconStage.byOrdinal(in.getIntOr("stage", 0));
        puzzleProgress = in.getIntOr("puzzle_progress", 0);
        capturedUntil = in.getLongOr("captured_until", 0L);
        puzzle = new ArrayList<>(in.read("puzzle", Codec.INT.listOf()).orElse(List.of()));
        waveRunning = in.getBooleanOr("wave_running", false);
        waveSpawned = in.getBooleanOr("wave_spawned", false);
        waveIndex = in.getIntOr("wave_index", 0);
        waveDelay = in.getIntOr("wave_delay", 0);
        mobs = new ArrayList<>(in.read("mobs", UUIDUtil.CODEC.listOf()).orElse(List.of()));
        starter = in.read("starter", UUIDUtil.CODEC).orElse(null);
    }

    // ================= Тик =================

    public static void serverTick(net.minecraft.world.level.Level level, BlockPos pos, BlockState state,
                                  AquaBeaconBlockEntity be) {
        if (level instanceof ServerLevel sl) {
            be.tick(sl, sl.getGameTime());
        }
    }

    private void tick(ServerLevel sl, long t) {
        BeaconType type = type();
        switch (stage) {
            case DORMANT -> { }
            case RESOURCES, ARTIFACT -> BeaconFx.idle(sl, worldPosition, type, t);
            case PUZZLE -> tickPuzzle(sl, t);
            case WAVES -> {
                if (waveRunning) {
                    BeaconFx.trial(sl, worldPosition, type, t);
                    tickWaves(sl, t);
                } else {
                    BeaconFx.idle(sl, worldPosition, type, t);
                }
            }
            case ACTIVE -> tickActive(sl, t);
            case CAPTURED -> tickCaptured(sl, t);
        }
    }

    private void tickActive(ServerLevel sl, long t) {
        BeaconFx.active(sl, worldPosition, type(), t);
        if (t % 80 != 0) return;
        BeaconConfig.Section cfg = BeaconConfig.SECTIONS.get(type());
        Identifier id = Identifier.tryParse(cfg.effect().get());
        if (id == null) return;
        Holder<MobEffect> effect = BuiltInRegistries.MOB_EFFECT.get(id).orElse(null);
        if (effect == null) return;
        double r = BeaconConfig.EFFECT_RADIUS.get();
        for (Player p : sl.getEntitiesOfClass(Player.class, new AABB(worldPosition).inflate(r))) {
            // 400 тиков, чтобы не было мерцания «заканчивающегося» ночного зрения
            p.addEffect(new MobEffectInstance(effect, 400, cfg.amplifier().get(), true, true));
        }
    }

    // ================= Захват (рейды Дрейка) =================

    public boolean isActiveStage() { return stage == BeaconStage.ACTIVE; }

    /** Маяк захвачен: отключается на указанное число секунд. */
    public void capture(ServerLevel sl, int seconds) {
        capturedUntil = sl.getGameTime() + seconds * 20L;
        setStage(BeaconStage.CAPTURED);
        sl.playSound(null, worldPosition, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2f, 0.6f);
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, worldPosition.getX() + 0.5, worldPosition.getY() + 1.2,
                worldPosition.getZ() + 0.5, 60, 0.6, 0.8, 0.6, 0.05);
    }

    private void tickCaptured(ServerLevel sl, long t) {
        if (t % 10 == 0) {
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, worldPosition.getX() + 0.5, worldPosition.getY() + 1.2,
                    worldPosition.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.01);
        }
        if (t >= capturedUntil) {
            setStage(BeaconStage.ACTIVE);
            sl.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2f, 1f);
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level instanceof ServerLevel sl && stage == BeaconStage.ACTIVE) BeaconRegistry.add(sl, worldPosition);
    }

    @Override
    public void setRemoved() {
        BeaconRegistry.remove(level, worldPosition);
        super.setRemoved();
    }

    // ================= Взаимодействие =================

    public void interact(ServerPlayer player, ItemStack held) {
        ServerLevel sl = (ServerLevel) level;
        switch (stage) {
            case DORMANT -> {
                setStage(BeaconStage.RESOURCES);
                sl.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 0.6f, 1.6f);
                tell(player, "start");
                showRequirements(player);
            }
            case RESOURCES -> tryResources(sl, player);
            case ARTIFACT -> tryArtifact(sl, player, held);
            case PUZZLE -> tryPuzzle(sl, player, held);
            case WAVES -> tryWaves(sl, player, held);
            case ACTIVE -> tell(player, "active");
            case CAPTURED -> tell(player, "captured");
        }
    }

    private void setStage(BeaconStage s) {
        stage = s;
        setChanged();
        if (level instanceof ServerLevel rl) {
            if (s == BeaconStage.ACTIVE) BeaconRegistry.add(rl, worldPosition);
            else BeaconRegistry.remove(rl, worldPosition);
        }
        if (level != null) {
            BlockState st = getBlockState();
            boolean act = s == BeaconStage.ACTIVE;
            if (st.getValue(AquaBeaconBlock.ACTIVE) != act) {
                level.setBlock(worldPosition, st.setValue(AquaBeaconBlock.ACTIVE, act), 3);
            }
        }
    }

    private static void tell(ServerPlayer p, String key, Object... args) {
        p.sendSystemMessage(Component.translatable("msg.aqua_dominus." + key, args));
    }

    private void showRequirements(ServerPlayer player) {
        tell(player, "resources_title");
        for (BeaconConfig.ItemReq r : BeaconConfig.resources(type())) {
            player.sendSystemMessage(Component.literal(" - " + r.count() + "x ")
                    .append(new ItemStack(r.item()).getHoverName()));
        }
    }

    // ---- Этап 1: ресурсы ----

    private static int count(ServerPlayer p, Item item) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    private static void take(ServerPlayer p, Item item, int amount) {
        for (int i = 0; i < 36 && amount > 0; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (s.is(item)) {
                int d = Math.min(amount, s.getCount());
                s.shrink(d);
                amount -= d;
            }
        }
    }

    private void tryResources(ServerLevel sl, ServerPlayer player) {
        List<BeaconConfig.ItemReq> reqs = BeaconConfig.resources(type());
        MutableComponent missing = Component.empty();
        boolean ok = true;
        for (BeaconConfig.ItemReq r : reqs) {
            int have = count(player, r.item());
            if (have < r.count()) {
                ok = false;
                missing.append(Component.literal("\n - " + (r.count() - have) + "x ")
                        .append(new ItemStack(r.item()).getHoverName()));
            }
        }
        if (!ok) {
            tell(player, "missing", missing);
            return;
        }
        for (BeaconConfig.ItemReq r : reqs) take(player, r.item(), r.count());
        sl.playSound(null, worldPosition, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 1f, 1f);
        setStage(BeaconStage.ARTIFACT);
        tell(player, "resources_ok", artifactName());
    }

    // ---- Этап 2: артефакт ----

    private Component artifactName() {
        return BeaconConfig.item(BeaconConfig.SECTIONS.get(type()).artifact().get())
                .map(i -> new ItemStack(i).getHoverName())
                .orElse(Component.literal("?"));
    }

    private void tryArtifact(ServerLevel sl, ServerPlayer player, ItemStack held) {
        Item artifact = BeaconConfig.item(BeaconConfig.SECTIONS.get(type()).artifact().get()).orElse(null);
        if (artifact == null || !held.is(artifact)) {
            tell(player, "need_artifact", artifactName());
            return;
        }
        held.shrink(1);
        sl.playSound(null, worldPosition, SoundEvents.END_PORTAL_FRAME_FILL, SoundSource.BLOCKS, 1f, 1f);
        sl.sendParticles(ParticleTypes.PORTAL, worldPosition.getX() + 0.5, worldPosition.getY() + 1.2,
                worldPosition.getZ() + 0.5, 40, 0.4, 0.4, 0.4, 0.5);
        generatePuzzle(sl);
        setStage(BeaconStage.PUZZLE);
        tell(player, "artifact_ok");
    }

    // ---- Этап 3: головоломка ----

    private void generatePuzzle(ServerLevel sl) {
        RandomSource r = sl.getRandom();
        puzzle = new ArrayList<>();
        for (int i = 0; i < BeaconConfig.PUZZLE_LENGTH.get(); i++) puzzle.add(r.nextInt(4));
        puzzleProgress = 0;
        lastInput = -1000;
        setChanged();
    }

    private static int dyeIndex(ItemStack s) {
        for (int i = 0; i < DYES.length; i++) if (s.is(DYES[i])) return i;
        return -1;
    }

    private void flash(ServerLevel sl, int idx) {
        sl.sendParticles(BeaconFx.dust(DYE_COLORS[idx], 1.6f), worldPosition.getX() + 0.5,
                worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5, 25, 0.35, 0.35, 0.35, 0);
        sl.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 1f, PITCH[idx]);
    }

    private void tickPuzzle(ServerLevel sl, long t) {
        if (puzzle.isEmpty()) generatePuzzle(sl);
        if (t - lastInput < 120) return; // игрок вводит ответ, не мешаем
        long cycle = puzzle.size() * 20L + 60L;
        long phase = t % cycle;
        if (phase < puzzle.size() * 20L && phase % 20 == 0) flash(sl, puzzle.get((int) (phase / 20)));
    }

    private void tryPuzzle(ServerLevel sl, ServerPlayer player, ItemStack held) {
        int idx = dyeIndex(held);
        if (idx < 0) {
            tell(player, "puzzle_hint");
            return;
        }
        lastInput = sl.getGameTime();
        if (puzzle.get(puzzleProgress) == idx) {
            flash(sl, idx);
            puzzleProgress++;
            if (puzzleProgress >= puzzle.size()) {
                sl.playSound(null, worldPosition, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 1f, 1f);
                setStage(BeaconStage.WAVES);
                tell(player, "puzzle_ok");
            } else {
                tell(player, "puzzle_step", puzzleProgress, puzzle.size());
                setChanged();
            }
        } else {
            sl.playSound(null, worldPosition, SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.BLOCKS, 1f, 0.5f);
            sl.sendParticles(ParticleTypes.SMOKE, worldPosition.getX() + 0.5, worldPosition.getY() + 1.2,
                    worldPosition.getZ() + 0.5, 20, 0.3, 0.3, 0.3, 0.02);
            tell(player, "puzzle_fail");
            generatePuzzle(sl); // новая последовательность: перебором не пройти
        }
    }

    // ---- Этап 4: испытание ----

    private List<ServerPlayer> nearbyPlayers(ServerLevel sl) {
        double r = BeaconConfig.PLAYER_RADIUS.get();
        return sl.getEntitiesOfClass(ServerPlayer.class, new AABB(worldPosition).inflate(r),
                p -> p.isAlive() && !p.isSpectator());
    }

    private void tryWaves(ServerLevel sl, ServerPlayer player, ItemStack held) {
        if (waveRunning) {
            tell(player, "wave_running");
            return;
        }
        Item key = BeaconConfig.item(BeaconConfig.TRIAL_KEY.get()).orElse(Items.AIR);
        if (!held.is(key)) {
            tell(player, "need_key");
            return;
        }
        held.shrink(1);
        starter = player.getUUID();
        waveRunning = true;
        waveSpawned = false;
        waveIndex = 0;
        waveDelay = 60;
        emptySeconds = 0;
        mobs.clear();
        setChanged();
        sl.playSound(null, worldPosition, SoundEvents.TRIAL_SPAWNER_OPEN_SHUTTER, SoundSource.BLOCKS, 1.5f, 0.8f);
        for (ServerPlayer p : nearbyPlayers(sl)) tell(p, "wave_start");
    }

    private void tickWaves(ServerLevel sl, long t) {
        List<ServerPlayer> players = nearbyPlayers(sl);
        if (t % 20 == 0) {
            if (players.isEmpty()) {
                if (++emptySeconds >= BeaconConfig.ABORT_AFTER_SECONDS.get()) {
                    abort(sl);
                    return;
                }
            } else {
                emptySeconds = 0;
            }
        }
        if (t % 10 != 0) return;

        mobs.removeIf(id -> {
            Entity e = sl.getEntity(id);
            return e == null || !e.isAlive();
        });

        if (waveSpawned) {
            if (mobs.isEmpty()) {
                waveSpawned = false;
                waveIndex++;
                setChanged();
                if (waveIndex >= BeaconConfig.WAVE_COUNT.get()) {
                    complete(sl, players);
                } else {
                    waveDelay = BeaconConfig.WAVE_DELAY_TICKS.get();
                    for (ServerPlayer p : players) tell(p, "wave_clear", waveIndex, BeaconConfig.WAVE_COUNT.get());
                }
            }
        } else {
            waveDelay -= 10;
            if (waveDelay <= 0 && !players.isEmpty()) spawnWave(sl, players);
        }
    }

    private void spawnWave(ServerLevel sl, List<ServerPlayer> players) {
        int n = players.size();
        int count = BeaconConfig.BASE_MOBS.get()
                + BeaconConfig.MOBS_PER_EXTRA_PLAYER.get() * (n - 1)
                + BeaconConfig.MOBS_PER_WAVE.get() * waveIndex;
        double hpMul = 1.0 + BeaconConfig.HEALTH_PER_EXTRA_PLAYER.get() * (n - 1);

        List<BeaconConfig.MobEntry> pool = new ArrayList<>();
        for (BeaconConfig.MobEntry m : BeaconConfig.mobs(type())) if (m.minWave() <= waveIndex + 1) pool.add(m);
        if (pool.isEmpty()) pool.add(new BeaconConfig.MobEntry(EntityType.ZOMBIE, 1, 1));
        int total = pool.stream().mapToInt(BeaconConfig.MobEntry::weight).sum();

        RandomSource r = sl.getRandom();
        for (int i = 0; i < count; i++) {
            int roll = r.nextInt(total);
            EntityType<?> chosen = pool.get(0).type();
            for (BeaconConfig.MobEntry m : pool) {
                roll -= m.weight();
                if (roll < 0) { chosen = m.type(); break; }
            }
            Entity e = chosen.spawn(sl, findSpot(sl, r), EntitySpawnReason.TRIGGERED);
            if (e == null) continue;
            if (e instanceof LivingEntity le) {
                if (hpMul > 1.0) {
                    AttributeInstance hp = le.getAttribute(Attributes.MAX_HEALTH);
                    if (hp != null) {
                        hp.setBaseValue(hp.getBaseValue() * hpMul);
                        le.setHealth(le.getMaxHealth());
                    }
                }
                le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 12000, 0, false, false));
            }
            if (e instanceof Mob mob) {
                mob.setPersistenceRequired();
                mob.setTarget(players.get(r.nextInt(n)));
            }
            mobs.add(e.getUUID());
        }

        if (mobs.isEmpty()) { // не удалось заспавнить, попробуем позже
            waveDelay = 100;
            return;
        }
        waveSpawned = true;
        setChanged();
        sl.playSound(null, worldPosition, SoundEvents.TRIAL_SPAWNER_SPAWN_MOB, SoundSource.HOSTILE, 1.5f, 0.7f);
        for (ServerPlayer p : players) tell(p, "wave_spawn", waveIndex + 1, BeaconConfig.WAVE_COUNT.get());
    }

    private BlockPos findSpot(ServerLevel sl, RandomSource r) {
        int rad = BeaconConfig.SPAWN_RADIUS.get();
        int[] dys = {1, 2, 0, 3, -1};
        for (int attempt = 0; attempt < 12; attempt++) {
            int dx = r.nextInt(rad * 2 + 1) - rad;
            int dz = r.nextInt(rad * 2 + 1) - rad;
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;
            for (int dy : dys) {
                BlockPos p = worldPosition.offset(dx, dy, dz);
                if (free(sl, p) && free(sl, p.above())) return p;
            }
        }
        return worldPosition.above(2);
    }

    private static boolean free(ServerLevel sl, BlockPos p) {
        return sl.getBlockState(p).getCollisionShape(sl, p).isEmpty();
    }

    private void abort(ServerLevel sl) {
        for (UUID id : mobs) {
            Entity e = sl.getEntity(id);
            if (e != null) e.discard();
        }
        mobs.clear();
        waveRunning = false;
        waveSpawned = false;
        setChanged();
        Item key = BeaconConfig.item(BeaconConfig.TRIAL_KEY.get()).orElse(Items.AIR);
        if (key != Items.AIR) Block.popResource(sl, worldPosition.above(), new ItemStack(key));
    }

    private void complete(ServerLevel sl, List<ServerPlayer> players) {
        waveRunning = false;
        setStage(BeaconStage.ACTIVE);
        sl.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2f, 1f);
        sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, worldPosition.getX() + 0.5, worldPosition.getY() + 1.5,
                worldPosition.getZ() + 0.5, 120, 0.8, 1.2, 0.8, 0.4);
        for (ServerPlayer p : players) {
            sl.playSound(null, p.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1f, 1f);
            tell(p, "complete");
        }
        giftIfFirst(sl, players);

        // Событие для связанных модов (например, glow_soul)
        ServerPlayer activator = starter == null ? null : sl.getServer().getPlayerList().getPlayer(starter);
        if (activator == null && !players.isEmpty()) activator = players.get(0);
        if (activator != null) {
            NeoForge.EVENT_BUS.post(new BeaconActivatedEvent(activator, BeaconSide.valueOf(type().name()), worldPosition));
        }
    }

    /** Дар света выдаётся один раз на мир: за первый включённый маяк. Флаг: /data get storage aqua_dominus:state */
    private void giftIfFirst(ServerLevel sl, List<ServerPlayer> players) {
        if (!BeaconConfig.GIVE_GIFT.get()) return;
        var storage = sl.getServer().getCommandStorage();
        CompoundTag tag = storage.get(STATE_KEY);
        if (tag.getBooleanOr("gift_given", false)) return;
        tag.putBoolean("gift_given", true);
        storage.set(STATE_KEY, tag);

        Item gift = BeaconConfig.item(BeaconConfig.GIFT_ITEM.get()).orElse(Items.AIR);
        if (gift == Items.AIR) return;
        for (ServerPlayer p : players) {
            ItemStack s = new ItemStack(gift);
            if (!p.getInventory().add(s)) p.drop(s, false);
            tell(p, "gift");
        }
    }
}
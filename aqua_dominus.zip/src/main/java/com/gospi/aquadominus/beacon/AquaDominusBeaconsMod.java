package com.gospi.aquadominus.beacon;

import com.mojang.logging.LogUtils;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

/**
 * Точка входа модуля маяков и рогов. init() идемпотентна: её можно вызывать и отсюда,
 * и из BeaconBootstrap (запасной путь, если FML не запустил этот @Mod рядом с главным классом MCreator).
 */
@Mod(ModRegistry.MODID)
public class AquaDominusBeaconsMod {
    private static boolean initialised = false;

    public AquaDominusBeaconsMod(IEventBus modBus, ModContainer container) {
        init(modBus, container);
    }

    public static synchronized void init(IEventBus modBus, ModContainer container) {
        if (initialised) return;
        initialised = true;
        ModRegistry.BLOCKS.register(modBus);
        ModRegistry.ITEMS.register(modBus);
        ModRegistry.BLOCK_ENTITIES.register(modBus);
        ModRegistry.TABS.register(modBus);
        com.gospi.aquadominus.drake.DrakeRegistry.ENTITIES.register(modBus);
        container.registerConfig(ModConfig.Type.COMMON, BeaconConfig.SPEC, "aqua_dominus-beacons.toml");
        container.registerConfig(ModConfig.Type.COMMON, com.gospi.aquadominus.horn.HornConfig.SPEC, "aqua_dominus-horns.toml");
        container.registerConfig(ModConfig.Type.COMMON, com.gospi.aquadominus.drake.DrakeConfig.SPEC, "aqua_dominus-drake.toml");
        container.registerConfig(ModConfig.Type.COMMON, com.gospi.aquadominus.mob.MobConfig.SPEC, "aqua_dominus-mobs.toml");
        LogUtils.getLogger().info("[aqua_dominus] Beacons + horns module initialised");
    }
}
package com.gospi.aquadominus.beacon;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;

/**
 * Запасной запуск. FML сам загружает классы с @EventBusSubscriber при создании мода,
 * и статический блок ниже регистрирует всё, даже если отдельный @Mod-класс не был запущен.
 */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class BeaconBootstrap {
    static {
        ModContainer container = ModList.get().getModContainerById(ModRegistry.MODID).orElse(null);
        if (container != null && container.getEventBus() != null) {
            AquaDominusBeaconsMod.init(container.getEventBus(), container);
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        // намеренно пусто: нужен хотя бы один обработчик, чтобы класс точно загрузился
    }

    private BeaconBootstrap() {}
}

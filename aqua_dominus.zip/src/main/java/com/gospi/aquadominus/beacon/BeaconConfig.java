package com.gospi.aquadominus.beacon;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Конфиг: config/aqua_dominus-beacons.toml
 * Форматы строк:
 *   ресурсы: "minecraft:iron_ingot=16"
 *   мобы:    "minecraft:zombie;вес;с_какой_волны"  (волны считаются с 1)
 */
public final class BeaconConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<String> TRIAL_KEY;
    public static final ModConfigSpec.ConfigValue<String> GIFT_ITEM;
    public static final ModConfigSpec.BooleanValue GIVE_GIFT;
    public static final ModConfigSpec.ConfigValue<String> CREATIVE_TAB;
    public static final ModConfigSpec.IntValue PUZZLE_LENGTH;

    public static final ModConfigSpec.IntValue PLAYER_RADIUS;
    public static final ModConfigSpec.IntValue SPAWN_RADIUS;
    public static final ModConfigSpec.IntValue WAVE_COUNT;
    public static final ModConfigSpec.IntValue BASE_MOBS;
    public static final ModConfigSpec.IntValue MOBS_PER_EXTRA_PLAYER;
    public static final ModConfigSpec.IntValue MOBS_PER_WAVE;
    public static final ModConfigSpec.DoubleValue HEALTH_PER_EXTRA_PLAYER;
    public static final ModConfigSpec.IntValue WAVE_DELAY_TICKS;
    public static final ModConfigSpec.IntValue ABORT_AFTER_SECONDS;

    public static final ModConfigSpec.IntValue EFFECT_RADIUS;

    public record Section(
            ModConfigSpec.ConfigValue<List<? extends String>> resources,
            ModConfigSpec.ConfigValue<String> artifact,
            ModConfigSpec.ConfigValue<String> effect,
            ModConfigSpec.IntValue amplifier,
            ModConfigSpec.ConfigValue<List<? extends String>> mobs) {}

    public static final Map<BeaconType, Section> SECTIONS = new EnumMap<>(BeaconType.class);

    public record ItemReq(Item item, int count) {}
    public record MobEntry(EntityType<?> type, int weight, int minWave) {}

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Общие настройки").push("general");
        TRIAL_KEY = b.comment("Предмет, которым запускается испытание (волны мобов)")
                .define("trialKeyItem", "minecraft:trial_key");
        GIFT_ITEM = b.comment("Предмет, выдаваемый за первый включённый маяк (нужен для западного)")
                .define("giftOfLightItem", "aqua_dominus:gift_of_light");
        CREATIVE_TAB = b.comment("Id вашей творческой вкладки (например aqua_dominus:aqua_tab). Предметы мода лягут туда. Пусто: своя вкладка мода")
                .define("creativeTab", "");
        GIVE_GIFT = b.comment("Выдавать Дар света за первый включённый маяк. Выключите, если это делает другой мод")
                .define("giveGiftOnFirstBeacon", true);
        PUZZLE_LENGTH = b.comment("Длина последовательности в головоломке")
                .defineInRange("puzzleLength", 5, 2, 12);
        EFFECT_RADIUS = b.comment("Радиус действия эффекта включённого маяка (блоки)")
                .defineInRange("effectRadius", 40, 4, 256);
        b.pop();

        b.comment("Волны мобов (как у спавнера испытаний: сложность растёт с числом игроков)").push("waves");
        PLAYER_RADIUS = b.comment("Игроки в этом радиусе считаются участниками")
                .defineInRange("playerRadius", 32, 4, 128);
        SPAWN_RADIUS = b.defineInRange("spawnRadius", 8, 3, 24);
        WAVE_COUNT = b.defineInRange("waveCount", 5, 1, 20);
        BASE_MOBS = b.comment("Мобов в первой волне для одного игрока")
                .defineInRange("baseMobs", 5, 1, 100);
        MOBS_PER_EXTRA_PLAYER = b.comment("Прибавка мобов за каждого игрока сверх первого")
                .defineInRange("mobsPerExtraPlayer", 3, 0, 50);
        MOBS_PER_WAVE = b.comment("Прибавка мобов за каждую следующую волну")
                .defineInRange("mobsPerWave", 3, 0, 50);
        HEALTH_PER_EXTRA_PLAYER = b.comment("Множитель здоровья мобов за каждого игрока сверх первого (0.25 = +25%)")
                .defineInRange("healthPerExtraPlayer", 0.25, 0.0, 5.0);
        WAVE_DELAY_TICKS = b.defineInRange("waveDelayTicks", 100, 20, 1200);
        ABORT_AFTER_SECONDS = b.comment("Если рядом нет игроков столько секунд, испытание сбрасывается, а ключ выпадает")
                .defineInRange("abortAfterSeconds", 45, 5, 600);
        b.pop();

        for (BeaconType t : BeaconType.values()) {
            b.comment("Маяк: " + t.configName()).push(t.configName());
            Section s = new Section(
                    b.comment("Ресурсы для этапа 1 (забираются из инвентаря игрока)")
                            .defineListAllowEmpty("resources", defaultResources(t),
                                    () -> "minecraft:iron_ingot=16", o -> o instanceof String str && str.contains("=")),
                    b.comment("Артефакт для этапа 2").define("artifact", defaultArtifact(t)),
                    b.comment("Эффект включённого маяка").define("effect", defaultEffect(t)),
                    b.comment("Уровень эффекта (0 = I)").defineInRange("amplifier", 0, 0, 10),
                    b.comment("Мобы волн: id;вес;минимальная_волна")
                            .defineListAllowEmpty("mobs", defaultMobs(t),
                                    () -> "minecraft:zombie;1;1", o -> o instanceof String str && str.split(";").length == 3));
            SECTIONS.put(t, s);
            b.pop();
        }
        SPEC = b.build();
    }

    private static List<String> defaultResources(BeaconType t) {
        return switch (t) {
            case NORTH -> List.of("minecraft:prismarine_crystals=32", "minecraft:prismarine_shard=32", "minecraft:sea_lantern=8");
            case SOUTH -> List.of("minecraft:blaze_rod=16", "minecraft:quartz=32", "minecraft:magma_block=16");
            case EAST -> List.of("minecraft:amethyst_shard=32", "minecraft:redstone=64", "minecraft:iron_ingot=32");
            case WEST -> List.of("minecraft:gold_ingot=24", "minecraft:glowstone=16", "minecraft:lapis_lazuli=32");
        };
    }

    private static String defaultArtifact(BeaconType t) {
        return switch (t) {
            case NORTH -> "aqua_dominus:great_heart_of_the_sea";
            case SOUTH -> "aqua_dominus:nether_prism";
            case EAST -> "aqua_dominus:dungeon_mechanism";
            case WEST -> "aqua_dominus:gift_of_light";
        };
    }

    private static String defaultEffect(BeaconType t) {
        return switch (t) {
            case NORTH -> "minecraft:conduit_power";
            case SOUTH -> "minecraft:fire_resistance";
            case EAST -> "minecraft:haste";
            case WEST -> "minecraft:night_vision";
        };
    }

    private static List<String> defaultMobs(BeaconType t) {
        return switch (t) {
            case NORTH -> List.of("variantsandventures:gelid;10;1", "minecraft:stray;8;2", "freezery:freeze;8;3");
            case SOUTH -> List.of("minecraft:blaze;8;1", "minecraft:wither_skeleton;6;1", "minecraft:piglin_brute;3;2");
            case EAST -> List.of("minecraft:zombie;8;1", "minecraft:skeleton;8;1", "minecraft:bogged;5;1", "minecraft:breeze;3;2", "minecraft:vindicator;2;3");
            case WEST -> List.of("minecraft:pillager;8;1", "minecraft:vindicator;5;1", "minecraft:evoker;2;2", "minecraft:ravager;1;3");
        };
    }

    // ---------- Разбор значений ----------

    public static Optional<Item> item(String id) {
        Identifier r = Identifier.tryParse(id);
        if (r == null || !BuiltInRegistries.ITEM.containsKey(r)) {
            return Optional.empty();
        }
        return Optional.of(BuiltInRegistries.ITEM.getValue(r));
    }

    public static List<ItemReq> resources(BeaconType t) {
        List<ItemReq> out = new ArrayList<>();
        for (String s : SECTIONS.get(t).resources().get()) {
            String[] p = s.split("=");
            Optional<Item> it = item(p[0].trim());
            if (it.isEmpty()) continue;
            try {
                out.add(new ItemReq(it.get(), Math.max(1, Integer.parseInt(p[1].trim()))));
            } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    public static List<MobEntry> mobs(BeaconType t) {
        List<MobEntry> out = new ArrayList<>();
        for (String s : SECTIONS.get(t).mobs().get()) {
            String[] p = s.split(";");
            Identifier id = Identifier.tryParse(p[0].trim());
            if (id == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(id)) continue;
            try {
                out.add(new MobEntry(BuiltInRegistries.ENTITY_TYPE.getValue(id),
                        Math.max(1, Integer.parseInt(p[1].trim())), Math.max(1, Integer.parseInt(p[2].trim()))));
            } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    private BeaconConfig() {}
}
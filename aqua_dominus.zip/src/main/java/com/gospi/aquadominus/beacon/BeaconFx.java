package com.gospi.aquadominus.beacon;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;

/** Ванильные частицы. Для каждого маяка свой рисунок: спираль + столб + «искры». */
public final class BeaconFx {

    private static ParticleOptions main(BeaconType t) {
        return switch (t) {
            case NORTH -> ParticleTypes.NAUTILUS;
            case SOUTH -> ParticleTypes.SOUL_FIRE_FLAME;
            case EAST -> ParticleTypes.ELECTRIC_SPARK;
            case WEST -> ParticleTypes.END_ROD;
        };
    }

    private static ParticleOptions accent(BeaconType t) {
        return switch (t) {
            case NORTH -> ParticleTypes.BUBBLE_POP;
            case SOUTH -> ParticleTypes.FLAME;
            case EAST -> ParticleTypes.ENCHANT;
            case WEST -> ParticleTypes.GLOW;
        };
    }

    public static DustParticleOptions dust(int rgb, float size) {
        return new DustParticleOptions(0xFF000000 | rgb, size);
    }

    /** Включённый маяк. */
    public static void active(ServerLevel level, BlockPos pos, BeaconType type, long t) {
        if (PhotonBridge.tryPlay(level, pos, type, t)) {
            return;
        }
        double cx = pos.getX() + 0.5, cy = pos.getY() + 1.0, cz = pos.getZ() + 0.5;
        double ang = t * 0.18;
        double rise = (t % 40) / 40.0 * 3.5;
        int strands = type == BeaconType.EAST ? 3 : 2;
        for (int i = 0; i < strands; i++) {
            double a = ang + i * (Math.PI * 2 / strands);
            double r = type == BeaconType.SOUTH ? 0.9 + 0.3 * Math.sin(t * 0.1) : 1.1;
            level.sendParticles(main(type), cx + Math.cos(a) * r, cy + rise, cz + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
        if (t % 3 == 0) {
            level.sendParticles(dust(type.color(), 1.2f), cx, cy + 0.4 + rise * 0.5, cz, 1, 0.25, 0.3, 0.25, 0);
        }
        if (t % 5 == 0) {
            level.sendParticles(accent(type), cx, cy + 0.3, cz, 2, 0.4, 0.5, 0.4, 0.02);
        }
        if (t % 8 == 0) {
            // световой столб вверх
            for (int i = 0; i < 12; i++) {
                level.sendParticles(ParticleTypes.END_ROD, cx, cy + 1 + i, cz, 1, 0.05, 0.0, 0.05, 0.0);
            }
        }
    }

    /** Промежуточные стадии: еле заметное мерцание цвета маяка. */
    public static void idle(ServerLevel level, BlockPos pos, BeaconType type, long t) {
        if (t % 20 == 0) {
            level.sendParticles(dust(type.color(), 0.8f), pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
                    3, 0.3, 0.2, 0.3, 0);
        }
    }

    /** Волны: тревожные частицы вокруг. */
    public static void trial(ServerLevel level, BlockPos pos, BeaconType type, long t) {
        if (t % 4 == 0) {
            double a = t * 0.3;
            level.sendParticles(main(type), pos.getX() + 0.5 + Math.cos(a) * 1.4, pos.getY() + 1.2,
                    pos.getZ() + 0.5 + Math.sin(a) * 1.4, 1, 0, 0.05, 0, 0.01);
        }
    }

    private BeaconFx() {}
}

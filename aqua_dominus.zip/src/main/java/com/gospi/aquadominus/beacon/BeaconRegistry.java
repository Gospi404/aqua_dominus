package com.gospi.aquadominus.beacon;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;

/** Включённые и загруженные маяки (в памяти): нужны Дрейку, чтобы выбирать цель рейда. */
public final class BeaconRegistry {
    private static final Map<ServerLevel, Set<BlockPos>> ACTIVE = new HashMap<>();

    public static void add(ServerLevel level, BlockPos pos) {
        ACTIVE.computeIfAbsent(level, k -> new HashSet<>()).add(pos.immutable());
    }

    public static void remove(Level level, BlockPos pos) {
        if (level instanceof ServerLevel sl) {
            Set<BlockPos> s = ACTIVE.get(sl);
            if (s != null) s.remove(pos);
        }
    }

    public static Map<ServerLevel, Set<BlockPos>> all() { return ACTIVE; }

    public static void clear() { ACTIVE.clear(); }

    private BeaconRegistry() {}
}
package com.gospi.aquadominus.beacon;

public enum BeaconStage {
    /** Маяк спит, ничего не делает. */
    DORMANT,
    /** Нужно принести ресурсы (список в конфиге). */
    RESOURCES,
    /** Нужно вставить артефакт. */
    ARTIFACT,
    /** Головоломка: повторить последовательность красителей. */
    PUZZLE,
    /** Испытание: волны мобов, запускается ключом испытаний. */
    WAVES,
    /** Маяк включён: даёт эффект и испускает частицы. */
    ACTIVE,
    /** Маяк захвачен пиратами Дрейка: временно не работает. */
    CAPTURED;

    public static BeaconStage byOrdinal(int i) {
        BeaconStage[] v = values();
        return i >= 0 && i < v.length ? v[i] : DORMANT;
    }
}
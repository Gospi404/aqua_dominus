package com.gospi.aquadominus.beacon;

/** Четыре маяка. Всё, что можно менять без перекомпиляции, вынесено в конфиг. */
public enum BeaconType {
    NORTH("north_aqua_beacon", 0x2BD9E5),
    SOUTH("south_aqua_beacon", 0xFF7A1F),
    EAST("east_aqua_beacon", 0xB06CFF),
    WEST("west_aqua_beacon", 0xFFF4B0);

    private final String id;
    private final int color;

    BeaconType(String id, int color) {
        this.id = id;
        this.color = color;
    }

    /** Registry name блока. */
    public String id() { return id; }

    /** RGB цвет эффектов. */
    public int color() { return color; }

    /** Имя секции в конфиге: north / south / east / west. */
    public String configName() { return name().toLowerCase(java.util.Locale.ROOT); }
}

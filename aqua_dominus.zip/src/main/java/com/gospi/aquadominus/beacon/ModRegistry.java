package com.gospi.aquadominus.beacon;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

import com.gospi.aquadominus.horn.HornKind;
import com.gospi.aquadominus.horn.SeaHornItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.entity.EntityType;
import com.gospi.aquadominus.drake.DrakeRegistry;
import net.neoforged.neoforge.registries.DeferredItem;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModRegistry {
    public static final String MODID = "aqua_dominus";

    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<BeaconType, DeferredBlock<AquaBeaconBlock>> BEACON_BLOCKS = new EnumMap<>(BeaconType.class);

    static {
        for (BeaconType type : BeaconType.values()) {
            DeferredBlock<AquaBeaconBlock> block = BLOCKS.registerBlock(
                    type.id(), props -> new AquaBeaconBlock(props, type), () -> beaconProperties());
            BEACON_BLOCKS.put(type, block);
            ITEMS.registerSimpleBlockItem(block);
        }
    }

    public static final Map<HornKind, DeferredItem<SeaHornItem>> HORNS = new EnumMap<>(HornKind.class);

    static {
        for (HornKind kind : HornKind.values()) {
            HORNS.put(kind, ITEMS.registerItem(kind.id(), props -> new SeaHornItem(props, kind),
                    () -> new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));
        }
    }

    /** Яйца призыва всех мобов мода. */
    public static final Map<String, DeferredItem<SpawnEggItem>> EGGS = new java.util.LinkedHashMap<>();

    private static void egg(String name, Supplier<? extends EntityType<?>> type) {
        EGGS.put(name, ITEMS.registerItem(name + "_spawn_egg", SpawnEggItem::new,
                () -> new Item.Properties().spawnEgg(type.get())));
    }

    static {
        egg("drake", DrakeRegistry.DRAKE);
        egg("prismy", DrakeRegistry.PRISMY);
        egg("seaper", DrakeRegistry.SEAPER);
        egg("shark", DrakeRegistry.SHARK);
    }

    /** Нельзя сломать (hardness -1), взорвать (огромное сопротивление) и сдвинуть поршнем. */
    private static BlockBehaviour.Properties beaconProperties() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_CYAN)
                .sound(SoundType.AMETHYST)
                .strength(-1.0F, 3_600_000.0F)
                .pushReaction(PushReaction.BLOCK)
                .noLootTable()
                .lightLevel(state -> state.getValue(AquaBeaconBlock.ACTIVE) ? 14 : 0);
    }

    public static final Supplier<BlockEntityType<AquaBeaconBlockEntity>> BEACON_BE = BLOCK_ENTITIES.register(
            "aqua_beacon",
            () -> new BlockEntityType<>(AquaBeaconBlockEntity::new,
                    BEACON_BLOCKS.values().stream().map(Supplier::get).toArray(Block[]::new)));

    public static final Supplier<CreativeModeTab> TAB = TABS.register("beacons", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.aqua_dominus.beacons"))
            .icon(() -> new ItemStack(BEACON_BLOCKS.get(BeaconType.NORTH).get()))
            .displayItems((params, out) -> {
                if (BeaconConfig.CREATIVE_TAB.get().isBlank()) fill(out);
            })
            .build());

    /** Кладёт все предметы мода в творческую вкладку (свою или указанную в конфиге). */
    public static void fill(CreativeModeTab.Output out) {
        for (BeaconType type : BeaconType.values()) {
                    out.accept(BEACON_BLOCKS.get(type).get());
                }
                for (HornKind kind : HornKind.values()) {
                    out.accept(HORNS.get(kind).get());
                }
                for (DeferredItem<SpawnEggItem> egg : EGGS.values()) {
                    out.accept(egg.get());
                }
                // Предметы, созданные в MCreator: кладём во вкладку по ID, если они существуют.
                acceptIfPresent(out, "nether_prism");
                acceptIfPresent(out, "dungeon_mechanism");
    }

    private static void acceptIfPresent(CreativeModeTab.Output out, String path) {
        Identifier id = Identifier.fromNamespaceAndPath(MODID, path);
        if (BuiltInRegistries.ITEM.containsKey(id)) {
            Item item = BuiltInRegistries.ITEM.getValue(id);
            out.accept(item);
        }
    }

    private ModRegistry() {}
}
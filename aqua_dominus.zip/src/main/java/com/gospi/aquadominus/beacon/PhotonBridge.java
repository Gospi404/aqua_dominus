package com.gospi.aquadominus.beacon;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.fml.ModList;

/**
 * Заготовка под Photon (Lowdragmc). Photon рисует эффекты на клиенте из .fx-файлов,
 * поэтому сервер должен отправить клиенту пакет «проиграй FX X в позиции Y».
 * Пока возвращает false, и тогда BeaconFx рисует ванильными частицами.
 *
 * Как подключить, когда у вас будут .fx-файлы и Photon под 26.1:
 *  1. Добавьте photon в build.gradle (compileOnly) и в dependencies мода (type="optional").
 *  2. Создайте payload (CustomPacketPayload) с BlockPos и BeaconType и отправьте его через
 *     PacketDistributor.sendToPlayersTrackingChunk(...).
 *  3. В клиентском обработчике запустите FX по API Photon (класс/метод сверьте с их wiki для вашей версии)
 *     и верните здесь true, чтобы отключить ванильный запасной вариант.
 */
public final class PhotonBridge {
    public static boolean isLoaded() {
        return ModList.get().isLoaded("photon");
    }

    public static boolean tryPlay(ServerLevel level, BlockPos pos, BeaconType type, long gameTime) {
        return false;
    }

    private PhotonBridge() {}
}

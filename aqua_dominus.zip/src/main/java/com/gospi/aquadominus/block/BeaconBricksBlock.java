package com.gospi.aquadominus.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BeaconBricksBlock extends Block {
	public BeaconBricksBlock(BlockBehaviour.Properties properties) {
		super(properties.mapColor(MapColor.STONE).strength(-1, 3600000).instrument(NoteBlockInstrument.BASEDRUM));
	}
}
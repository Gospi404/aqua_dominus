
package com.gospi.aquadominus.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.InsideBlockEffectApplier;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.material.MapColor;

public class BreathableMagmaBlock extends Block {

    public BreathableMagmaBlock(BlockBehaviour.Properties properties) {
        super(properties
                .mapColor(MapColor.COLOR_LIGHT_BLUE)
                .strength(0.55f, 1f)
                .lightLevel(state -> 3)
                .requiresCorrectToolForDrops()
                .postProcess((state, level, pos) -> pos)
                .emissiveRendering((state, level, pos) -> true)
                .instrument(NoteBlockInstrument.BASEDRUM)
                .randomTicks());
    }

    @Override
    public void animateTick(
            BlockState state,
            Level level,
            BlockPos pos,
            RandomSource random
    ) {
        super.animateTick(state, level, pos, random);

        // Проверяем воду непосредственно над основанием.
        if (!level.getFluidState(pos.above()).is(Fluids.WATER)) {
            return;
        }

        // Создаём пузырьки по всей высоте водяного столба.
        for (int y = 1; y <= 32; y++) {
            BlockPos waterPos = pos.above(y);

            if (!level.getFluidState(waterPos).is(Fluids.WATER)) {
                break;
            }

            if (random.nextFloat() < 0.35f) {
                double x = pos.getX() + 0.2
                        + random.nextDouble() * 0.6;
                double z = pos.getZ() + 0.2
                        + random.nextDouble() * 0.6;
                double particleY = waterPos.getY()
                        + random.nextDouble();

                level.addParticle(
                        ParticleTypes.BUBBLE_COLUMN_UP,
                        x,
                        particleY,
                        z,
                        0.0,
                        0.025,
                        0.0
                );
            }
        }
    }

    @Override
    protected void entityInside(
            BlockState state,
            Level level,
            BlockPos pos,
            Entity entity,
            InsideBlockEffectApplier effectApplier,
            boolean isPrecise
    ) {
        super.entityInside(
                state,
                level,
                pos,
                entity,
                effectApplier,
                isPrecise
        );

        if (!level.isClientSide() && entity instanceof Player player) {
            player.setAirSupply(player.getMaxAirSupply());
        }
    }
}

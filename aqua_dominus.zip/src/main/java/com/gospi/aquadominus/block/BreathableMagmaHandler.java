
package com.gospi.aquadominus.block;

import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.Fluids;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = "aqua_dominus")
public class BreathableMagmaHandler {

    private static final Identifier ADVANCEMENT_ID =
            Identifier.fromNamespaceAndPath(
                    "aqua_dominus",
                    "to_take_in_air"
            );

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        Level level = player.level();

        if (level.isClientSide()) {
            return;
        }

        if (!player.isUnderWater()) {
            return;
        }

        BlockPos eyePos = BlockPos.containing(
                player.getX(),
                player.getEyeY(),
                player.getZ()
        );

        for (int y = 0; y <= 32; y++) {
            BlockPos checkPos = eyePos.below(y);

            if (level.getBlockState(checkPos)
                    .getBlock() instanceof BreathableMagmaBlock) {

                // Восстанавливаем кислород.
                player.setAirSupply(player.getMaxAirSupply());

                // Выдаём достижение.
                if (player instanceof ServerPlayer serverPlayer) {
                    var server = serverPlayer.level().getServer();

                    if (server != null) {
                        AdvancementHolder advancement =
                                server.getAdvancements()
                                        .get(ADVANCEMENT_ID);

                        if (advancement != null) {
                            for (String criterion :
                                    advancement.value()
                                            .criteria()
                                            .keySet()) {

                                serverPlayer.getAdvancements()
                                        .award(advancement, criterion);
                            }
                        }
                    }
                }

                return;
            }

            // Колонна должна быть непрерывно заполнена водой.
            if (!level.getFluidState(checkPos).is(Fluids.WATER)) {
                return;
            }
        }
    }
}

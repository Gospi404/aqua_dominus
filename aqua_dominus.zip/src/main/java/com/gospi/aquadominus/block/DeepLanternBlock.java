package com.gospi.aquadominus.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DeepLanternBlock extends Block implements SimpleWaterloggedBlock {
    public static final MapCodec<DeepLanternBlock> CODEC = simpleCodec(DeepLanternBlock::new);
    public static final BooleanProperty HANGING = BlockStateProperties.HANGING;
    public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
    private static final VoxelShape FLOOR = Shapes.or(Block.box(4, 0, 4, 12, 7, 12), Block.box(5, 7, 5, 11, 9, 11));
    private static final VoxelShape HANG = Shapes.or(Block.box(4, 1, 4, 12, 8, 12), Block.box(5, 8, 5, 11, 10, 11));
    
    public DeepLanternBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(HANGING, false).setValue(WATERLOGGED, false));
    }

    @Override protected MapCodec<? extends Block> codec() { return CODEC; }
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(HANGING, WATERLOGGED); }
    @Override protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return s.getValue(HANGING) ? HANG : FLOOR; }
    @Override protected FluidState getFluidState(BlockState s) { return s.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(s); }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        FluidState fluid = ctx.getLevel().getFluidState(ctx.getClickedPos());
        for (Direction d : ctx.getNearestLookingDirections()) {
            if (d.getAxis() != Direction.Axis.Y) continue;
            BlockState s = defaultBlockState().setValue(HANGING, d == Direction.UP)
                    .setValue(WATERLOGGED, fluid.is(net.minecraft.tags.FluidTags.WATER) && fluid.isSource());
            if (s.canSurvive(ctx.getLevel(), ctx.getClickedPos())) return s;
        }
        return null;
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        Direction attach = state.getValue(HANGING) ? Direction.UP : Direction.DOWN;
        return Block.canSupportCenter(level, pos.relative(attach), attach.getOpposite());
    }

    @Override
    protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos,
                                     Direction dir, BlockPos nPos, BlockState nState, RandomSource random) {
        if (state.getValue(WATERLOGGED)) ticks.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
        Direction attach = state.getValue(HANGING) ? Direction.UP : Direction.DOWN;
        return dir == attach && !state.canSurvive(level, pos) ? Blocks.AIR.defaultBlockState()
                : super.updateShape(state, level, ticks, pos, dir, nPos, nState, random);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource r) {
        double y = pos.getY() + (state.getValue(HANGING) ? 0.5 : 0.4);
        if (r.nextInt(3) == 0)
            level.addParticle(ParticleTypes.GLOW, pos.getX() + .3 + r.nextDouble() * .4, y, pos.getZ() + .3 + r.nextDouble() * .4, 0, 0.01, 0);
        if (state.getValue(WATERLOGGED) && r.nextInt(5) == 0)
            level.addParticle(ParticleTypes.BUBBLE, pos.getX() + .5, y + .3, pos.getZ() + .5, 0, 0.08, 0);
    }
}
package com.gospi.aquadominus.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.function.Function;

public class PearlOysterBlock extends Block {
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public PearlOysterBlock(BlockBehaviour.Properties properties) {
		super(properties.mapColor(MapColor.ICE)
				.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.turtle.egg_break")), () -> BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.sniffer_egg.plop")),
						() -> BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.sniffer_egg.hatch")), () -> BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.sniffer_egg.plop")),
						() -> BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("block.sniffer_egg.crack"))))
				.strength(0.55f, 1f).lightLevel(blockstate -> 2).noOcclusion().isRedstoneConductor((bs, br, bp) -> false).instrument(NoteBlockInstrument.BASEDRUM));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(6, 3, 12, 10, 5, 15), box(6, 1, 12, 10, 3, 15), box(2.5, 3, 2, 13.5, 6, 12), box(2.5, 0, 2, 13.5, 3, 12));
				case EAST -> Shapes.or(box(1, 3, 6, 4, 5, 10), box(1, 1, 6, 4, 3, 10), box(4, 3, 2.5, 14, 6, 13.5), box(4, 0, 2.5, 14, 3, 13.5));
				case WEST -> Shapes.or(box(12, 3, 6, 15, 5, 10), box(12, 1, 6, 15, 3, 10), box(2, 3, 2.5, 12, 6, 13.5), box(2, 0, 2.5, 12, 3, 13.5));
				default -> Shapes.or(box(6, 3, 1, 10, 5, 4), box(6, 1, 1, 10, 3, 4), box(2.5, 3, 4, 13.5, 6, 14), box(2.5, 0, 4, 13.5, 3, 14));
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
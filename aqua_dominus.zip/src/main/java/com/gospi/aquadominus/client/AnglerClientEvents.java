package com.gospi.aquadominus.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

/** Регистрирует слой анимированной модели. Лежит вне папок, которые чистит MCreator. */
@EventBusSubscriber(modid = "aqua_dominus", value = Dist.CLIENT)
public final class AnglerClientEvents {
	@SubscribeEvent
	public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(SculkAnglerModel.LAYER_LOCATION, SculkAnglerModel::createBodyLayer);
	}

	private AnglerClientEvents() {}
}
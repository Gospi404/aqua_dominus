package com.gospi.aquadominus.client;

import com.gospi.aquadominus.AquaDominus;
import com.gospi.aquadominus.client.model.Modelgiant_squid;
import com.gospi.aquadominus.registry.ModRegistry;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = AquaDominus.MODID, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(Modelgiant_squid.LAYER_LOCATION, Modelgiant_squid::createBodyLayer);
    }
}
package com.gospi.aquadominus.client;

import com.gospi.aquadominus.client.renderer.SculkanglerRenderState;

import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

/**
 * Модель из Blockbench + иерархия под анимации (геометрия и UV не менялись).
 * rig (центр вращения) -> head(+jaw, sail(+lure)), body, left_fin, right_fin, tail(+tail_fin).
 *
 * Класс назван иначе, чем MCreator-овский Modelsculk_angler, поэтому MCreator его не перезапишет.
 */
public class SculkAnglerModel extends EntityModel<SculkanglerRenderState> {
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(Identifier.fromNamespaceAndPath("aqua_dominus", "sculk_angler_animated"), "main");

	private final ModelPart rig, head, jaw, sail, lure, body, leftFin, rightFin, tail, tailFin;

	public SculkAnglerModel(ModelPart root) {
		super(root);
		this.rig = root.getChild("rig");
		this.head = rig.getChild("head");
		this.jaw = head.getChild("jaw");
		this.sail = head.getChild("sail");
		this.lure = sail.getChild("lure");
		this.body = rig.getChild("body");
		this.leftFin = rig.getChild("left_fin");
		this.rightFin = rig.getChild("right_fin");
		this.tail = rig.getChild("tail");
		this.tailFin = tail.getChild("tail_fin");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition root = meshdefinition.getRoot();

		PartDefinition rig = root.addOrReplaceChild("rig", CubeListBuilder.create(), PartPose.offset(0.0F, 16.0F, 0.0F));

		PartDefinition head = rig.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 50).addBox(-7.0F, -6.875F, -12.0F, 14.0F, 7.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.875F, -2.0F));

		head.addOrReplaceChild("jaw",
				CubeListBuilder.create().texOffs(0, 30).addBox(-8.0F, 0.0F, -13.0F, 16.0F, 7.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.125F, 0.0F));

		PartDefinition sail = head.addOrReplaceChild("sail",
				CubeListBuilder.create().texOffs(52, 0).addBox(0.0F, -10.0F, -16.0F, 0.0F, 10.0F, 16.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -6.875F, 0.0F));

		sail.addOrReplaceChild("lure",
				CubeListBuilder.create().texOffs(68, 53).addBox(-1.5F, -1.5F, -1.5F, 3.0F, 3.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-0.25F, -1.0F, -15.0F));

		rig.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -9.0F, -6.0F, 14.0F, 18.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -1.0F, 4.0F));

		rig.addOrReplaceChild("left_fin",
				CubeListBuilder.create().texOffs(58, 26).addBox(0.0F, 0.0F, -2.5F, 8.0F, 0.0F, 9.0F, new CubeDeformation(0.0F)),
				PartPose.offset(7.0F, 3.0F, 0.5F));
		rig.addOrReplaceChild("right_fin",
				CubeListBuilder.create().texOffs(58, 35).addBox(-8.0F, 0.0F, -2.5F, 8.0F, 0.0F, 9.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-7.0F, 3.0F, 0.5F));

		PartDefinition tail = rig.addOrReplaceChild("tail",
				CubeListBuilder.create().texOffs(68, 44).addBox(-2.0F, -2.25F, 0.0F, 4.0F, 5.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 3.25F, 10.0F));
		tail.addOrReplaceChild("tail_fin",
				CubeListBuilder.create().texOffs(52, 50).addBox(0.0F, -12.25F, -2.0F, 0.0F, 20.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 0.0F, 4.0F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(SculkanglerRenderState s) {
		super.setupAnim(s);

		final float t = s.ageInTicks;
		final float speed = Mth.clamp(s.swimSpeed, 0F, 1F);
		final float lurk = s.lurkAmount;
		final float lunge = s.lungeAmount;
		final float aggro = s.aggroAmount;      // до 1.5 в ярости
		final float land = s.inWater ? 0F : 1F;

		// ---------- ритм плавания (заметный даже в простое) ----------
		float phase = t * (0.30F + speed * 0.7F + lunge * 0.5F + aggro * 0.12F);
		float amp = (0.40F + speed * 0.55F + lunge * 0.7F) * (1F - lurk * 0.8F);

		// ---------- тело ----------
		rig.xRot = Mth.clamp(s.xRot, -55F, 55F) * Mth.DEG_TO_RAD * 0.85F * (1F - land);
		rig.yRot = Mth.sin(phase) * (0.10F + speed * 0.12F) * (1F - lurk * 0.8F);   // S-образный изгиб всего тела
		rig.zRot = Mth.sin(phase * 0.5F) * 0.05F * speed + land * (1.3F + Mth.sin(t * 0.9F) * 0.3F);
		rig.y += Mth.sin(t * 0.09F) * 0.9F * (1F - lurk);
		body.xScale = 1F + Mth.sin(t * 0.12F) * 0.03F;   // "дыхание"
		body.zScale = body.xScale;

		// ---------- хвост (2 сегмента с запаздыванием) ----------
		float tailAmp = amp + land * 0.6F;
		float tailPhase = land > 0F ? t * 1.0F : phase;
		tail.yRot = Mth.sin(tailPhase) * tailAmp;
		tailFin.yRot = Mth.sin(tailPhase - 1.2F) * tailAmp * 1.4F;
		tail.xRot = Mth.cos(tailPhase * 0.5F) * 0.06F;

		// ---------- грудные плавники ----------
		float flap = Mth.sin(t * (0.35F + speed * 0.5F)) * (0.45F + speed * 0.5F);
		leftFin.zRot = 0.25F + flap;
		rightFin.zRot = -0.25F - flap;

		// ---------- пасть ----------
		float idleChomp = (Mth.sin(t * 0.17F) * 0.5F + 0.5F) * 0.12F;
		float open = Mth.clamp(s.jawOpen + idleChomp, 0F, 1F);
		jaw.xRot = open * 1.0F;
		head.xRot = -open * 0.3F - lurk * 0.15F;

		// ---------- парус ----------
		sail.zRot = Mth.sin(t * 0.11F) * 0.15F + Mth.sin(phase) * 0.08F * speed;
		sail.xRot = Mth.lerp(lurk, 0.0F, -0.4F) + aggro * 0.25F + Mth.sin(t * 0.12F) * 0.07F;

		// ---------- приманка (крупнее оригинала, чтобы было видно сквозь тьму) ----------
		lure.xRot = Mth.sin(t * 0.22F) * 0.5F;
		lure.zRot = Mth.cos(t * 0.19F) * 0.5F;
		float pulseSpeed = 0.2F + lurk * 0.25F + aggro * 0.3F;
		float pulseAmp = 0.2F + lurk * 0.4F + aggro * 0.3F;
		float pulse = 1.5F * (1F + (Mth.sin(t * pulseSpeed) * 0.5F + 0.5F) * pulseAmp);
		lure.xScale = pulse;
		lure.yScale = pulse;
		lure.zScale = pulse;
	}
}
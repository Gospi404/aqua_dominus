package com.gospi.aquadominus.client.drake;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.gospi.aquadominus.drake.DrakeRegistry;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = ModRegistry.MODID, value = Dist.CLIENT)
public final class DrakeClient {
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(DrakeRegistry.DRAKE.get(), DrakeRenderer::new);
    }

    private DrakeClient() {}
}

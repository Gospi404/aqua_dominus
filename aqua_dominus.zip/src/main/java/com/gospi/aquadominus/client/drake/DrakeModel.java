package com.gospi.aquadominus.client.drake;

import com.gospi.aquadominus.client.model.Modeldrake_skeleton;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

/**
 * Модель Дрейка: берёт скелет из Blockbench (Modeldrake_skeleton) и добавляет анимации:
 * походка вразвалку, дыхание, боевая стойка, замах саблей, насмешка, прыжок, рёв.
 * Когда нарисуете отдельную модель Дрейка, замените родительский класс.
 */
public class DrakeModel extends Modeldrake_skeleton {

    public DrakeModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state); // поворот головы

        float age = state.ageInTicks;
        float walk = Math.min(state.walkAnimationSpeed, 1.0f);
        float p = state.walkAnimationPos * 0.6662f;

        // ---------- база: дыхание и походка вразвалку ----------
        float breathe = Mth.sin(age * 0.07f);
        body.y = 8.8f - Math.abs(Mth.cos(p)) * 0.8f * walk;
        body.xRot = breathe * 0.015f;
        body.yRot = 0f;
        body.zRot = Mth.sin(p) * 0.06f * walk;

        right_leg.xRot = Mth.cos(p) * 1.2f * walk;
        left_leg.xRot = Mth.cos(p + Mth.PI) * 1.2f * walk;
        bottom_right_leg.xRot = Math.max(0f, Mth.sin(p)) * walk;
        bottom_left_leg.xRot = Math.max(0f, Mth.sin(p + Mth.PI)) * walk;

        right_arm.xRot = Mth.cos(p + Mth.PI) * 0.9f * walk;
        left_arm.xRot = Mth.cos(p) * 0.9f * walk;
        right_arm.zRot = -0.05f - Mth.sin(age * 0.09f) * 0.03f;
        left_arm.zRot = 0.05f + Mth.sin(age * 0.09f) * 0.03f;
        bottom_right_arm.xRot = -0.35f - 0.4f * walk;
        bottom_left_arm.xRot = -0.35f - 0.4f * walk;

        if (!(state instanceof DrakeRenderState d)) return;

        // ---------- боевая стойка: сабля наготове ----------
        if (d.aggressive && d.emote == 0) {
            right_arm.xRot = -0.9f + Mth.sin(age * 0.2f) * 0.05f;
            bottom_right_arm.xRot = -0.8f;
            left_arm.xRot = -0.4f;
            bottom_left_arm.xRot = -0.9f;
            body.xRot += 0.08f;
        }

        // ---------- замах (удар) ----------
        float t = d.attackAnim;
        if (t > 0f) {
            float a = Mth.sin(t * Mth.PI);
            float a2 = Mth.sin((1f - (1f - t) * (1f - t)) * Mth.PI);
            right_arm.xRot = -1.3f - a2 * 1.6f;
            bottom_right_arm.xRot = -0.4f - a * 0.8f;
            left_arm.xRot = -0.7f - a * 1.1f;
            body.yRot = Mth.sin(Mth.sqrt(t) * Mth.TWO_PI) * 0.35f;
            body.xRot += a * 0.15f;
        }

        // ---------- эмоции ----------
        float s = Mth.sin(d.emoteProgress * Mth.PI); // плавно вошёл и вышел
        switch (d.emote) {
            case 1 -> { // насмешка: хохочет, рука вверх, другая на поясе
                head.xRot += -0.5f * s;
                body.xRot += -0.18f * s + Mth.sin(age * 1.6f) * 0.06f * s;
                right_arm.xRot = -2.9f * s;
                right_arm.zRot = -0.3f * s;
                bottom_right_arm.xRot = -0.3f * s;
                left_arm.zRot = 0.6f * s;
                bottom_left_arm.xRot = -1.6f * s;
            }
            case 2 -> { // прыжок: руки вверх, ноги поджаты
                right_arm.xRot = -3.0f * s;
                left_arm.xRot = -3.0f * s;
                bottom_right_arm.xRot = -0.2f * s;
                bottom_left_arm.xRot = -0.2f * s;
                right_leg.xRot = -0.8f * s;
                left_leg.xRot = 0.5f * s;
                bottom_right_leg.xRot = 0.9f * s;
                bottom_left_leg.xRot = 0.7f * s;
                body.xRot += 0.3f * s;
            }
            case 3 -> { // рёв: руки в стороны, голова назад, дрожь
                right_arm.zRot = -1.3f * s;
                left_arm.zRot = 1.3f * s;
                right_arm.xRot = -0.5f * s;
                left_arm.xRot = -0.5f * s;
                head.xRot += -0.6f * s;
                body.xRot += -0.2f * s;
                body.zRot += Mth.sin(age * 2.2f) * 0.06f * s;
            }
            default -> { }
        }
    }
}
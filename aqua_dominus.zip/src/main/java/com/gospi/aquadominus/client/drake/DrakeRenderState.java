package com.gospi.aquadominus.client.drake;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class DrakeRenderState extends LivingEntityRenderState {
    public int emote;
    public float emoteProgress;
    public boolean aggressive;
    /** Прогресс замаха 0..1 (в 26.1 attackTime нет в LivingEntityRenderState). */
    public float attackAnim;
}
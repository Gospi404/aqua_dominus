package com.gospi.aquadominus.client.drake;

import com.gospi.aquadominus.client.model.Modeldrake_skeleton;
import com.gospi.aquadominus.drake.DrakeEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class DrakeRenderer extends MobRenderer<DrakeEntity, DrakeRenderState, Modeldrake_skeleton> {
    // Когда нарисуете отдельную текстуру Дрейка, положите её сюда и поменяйте путь:
    // assets/aqua_dominus/textures/entities/drake_king.png
    private static final Identifier TEXTURE = Identifier.parse("aqua_dominus:textures/entities/drake_skeleton.png");

    public DrakeRenderer(EntityRendererProvider.Context context) {
        super(context, new DrakeModel(context.bakeLayer(Modeldrake_skeleton.LAYER_LOCATION)), 0.8f);
    }

    @Override
    public DrakeRenderState createRenderState() {
        return new DrakeRenderState();
    }

    @Override
    public void extractRenderState(DrakeEntity entity, DrakeRenderState state, float partialTicks) {
        super.extractRenderState(entity, state, partialTicks);
        state.emote = entity.emote;
        state.emoteProgress = entity.emoteLen > 0
                ? Mth.clamp(1f - (entity.emoteTick - partialTicks) / entity.emoteLen, 0f, 1f) : 0f;
        state.aggressive = entity.isAggressive();
        state.attackAnim = entity.getAttackAnim(partialTicks);
    }

    @Override
    protected void scale(DrakeRenderState state, PoseStack poseStack) {
        poseStack.scale(1.35f, 1.35f, 1.35f); // король крупнее своей команды
    }

    @Override
    public Identifier getTextureLocation(DrakeRenderState state) {
        return TEXTURE;
    }
}
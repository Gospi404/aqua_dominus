package com.gospi.aquadominus.client.gui;

import org.joml.Matrix3x2fStack;

import net.minecraft.util.Util;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.ConfirmLinkScreen;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.Minecraft;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Locale;
import java.util.List;
import java.util.Deque;
import java.util.ArrayList;
import java.util.ArrayDeque;

import com.jcraft.jogg.Page;

public class TetropiaGuideBookScreen extends Screen {
	private static final int PAGE_W = 256;
	private static final int PAGE_H = 320;
	private static final int SIDEBAR_W = 140;
	private static final int GAP_W = 14;
	private static final int PAD = 5;
	private static final int CONTENT_W = SIDEBAR_W + GAP_W + PAGE_W;
	private static final int DESIGN_W = CONTENT_W + PAD * 2;
	private static final int DESIGN_H = PAGE_H + PAD * 2;
	private static final int DEFAULT_SIZE = 12;
	private static final int CATEGORY_ROWS = 11;
	private static final boolean HIDE_NEXT_ARROW_AT_CATEGORY_END = false;
	private static final Pattern TAG_PATTERN = Pattern.compile("\\[(/?)(b|i|u|s|obf|size|color|url|page|align)(?:=([^\\]]+))?\\]", Pattern.CASE_INSENSITIVE);
	private static final Category[] CATEGORIES = new Category[]{
			new Category("2eb325ae-bc1e-4332-ab6f-ead4513f9185", "Вступление",
					new Page[]{
							new Page("f03bf68d-aea2-44a3-aba6-43d81de56dce", "Страница 1", true, new Title(String.join("", new String[]{"Страница 1"}), "CENTER", 14, 10, 228, 24, 0, false, "#DDCDAA", 14, 33, 228, 1), new VisualElement[]{
									new VisualElement("TEXT", 18, 48, 220, 224, String.join("", new String[]{
											"Добро пожаловать в [b]Tetropia[/b] - мир, где нет суши, только океаны.\n В первом сезоне вам предстоит выживать среди бескрайних вод, исследовать кастомные структуры и осваивать механики глубин."}),
											"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN",
											"NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
							new Page("b2680dbf-7a4e-4713-ad54-b8ddec25dbe7", "Страница 2", true, new Title(String.join("", new String[]{"Страница 2\n"}), "CENTER", 14, 10, 228, 24, 0, false, "#DDCDAA", 14, 33, 228, 1),
									new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 193, String.join("", new String[]{
											"[align=LEFT][size=12][color=#241B13]Здесь вода - твой дом, а воздух - твоя жизнь. В этом гайде собрано главное: как подготовиться к погружению, как работает водолазный костюм, зачем нужна раковина наутилуса, где найти безопасные источники дыхания и многое другое.[/color][/size][/align]"}),
											"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
											new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
											new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN",
													"NONE")})}),
			new Category("790c240f-7ece-4151-8cfd-d04dbe2d6f45", "Основы", new Page[]{new Page("b3d0fa36-60b3-4d71-bccc-96632a01393b", "Страница 1: Пузыри воздуха", true,
					new Title(String.join("", new String[]{"[align=CENTER]Страница 1: [size=12][color=#38291E]Пузыри воздуха[/color][/size][/align]"}), "CENTER", 14, 10, 228, 24, 0, false, "#DDCDAA", 14, 33, 228, 1),
					new VisualElement[]{new VisualElement("TEXT", 16, 48, 224, 224, String.join("", new String[]{
							"[align=LEFT]Начнём с того, что теперь с глубин будут идти пузыри, с [size=12][color=#241B13]которых можно взять воздух под водой. Источником этих безвредных пузырей - дышащая магма, она абсолютно безопасна для игрока, также нужна в рецептах[/color][/size][/align]"}),
							"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
							new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
							new VisualElement("IMAGE", 96, 240, 56, 56, String.join("", new String[]{""}), "LEFT", "magma", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("6f8ae841-ec37-4f47-97b0-835b1ed92d13", "Страница 2: Раковины с воздухом", true,
							new Title(String.join("", new String[]{"[align=CENTER]Страница 2: Раковины с воздухом[/align]"}), "CENTER", 14, 10, 228, 44, 0, false, "#DDCDAA", 14, 53, 228, 1),
							new VisualElement[]{new VisualElement("TEXT", 16, 53, 224, 220, String.join("",
									new String[]{"Из раковины наутилуса и зубов акулы, Вы сможете сделать на верстаке эту замечательную раковину, с помощью неё, Вы сможете набирать воздух под водой, но будьте осторожны: не каждая раковина вечная"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 96, 240, 54, 58, String.join("", new String[]{""}), "LEFT", "nautilus_shell_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("50f0e791-7e35-4323-9935-c0227b24ca28", "Страница 3: Основы дайвинга", true, new Title(String.join("", new String[]{"Страница 3: Основы дайвинга"}), "CENTER", 14, 10, 228, 24, 0, false, "#DDCDAA", 14, 33, 228, 1),
							new VisualElement[]{
									new VisualElement("TEXT", 18, 48, 220, 129,
											String.join("", new String[]{"Чтобы спуститься на дно, нужно подготовиться. Для этого спресуем медные слитки и соединим их с раковинами с воздухом, и та-да, мы получим гидрокостюм!"}), "LEFT", "",
											new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 176, 192, 40, 40, String.join("", new String[]{""}), "LEFT", "copper_diving_boots_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
											"NONE"),
									new VisualElement("IMAGE", 128, 192, 38, 42, String.join("", new String[]{""}), "LEFT", "copper_diving_leggings_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
											"NONE"),
									new VisualElement("IMAGE", 80, 192, 40, 40, String.join("", new String[]{""}), "LEFT", "copper_diving_chestplate_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
											"NONE"),
									new VisualElement("IMAGE", 32, 192, 38, 42, String.join("", new String[]{""}), "LEFT", "copper_diving_helmet_2", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN",
											"NONE")}),
					new Page("b40987ee-b800-40c3-972c-846e28822427", "Страница 4: Рыбалка 1 ч.", true, new Title(String.join("", new String[]{"Страница 4: Рыбалка 1 ч."}), "CENTER", 14, 10, 228, 24, 0, true, "#DDCDAA", 14, 33, 228, 1),
							new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 220, String.join("", new String[]{
									"В нашей сборке установлены моды Aquaculture, а также Starcatcher. Starcatcher'а гайд у Вас уже есть. По Aquaculture можно сказать, что добавлены новые удочки, новый уровень брони, а также новые виды рыб."}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
					new Page("7329ec1f-ba95-45b9-bc0f-2372305680cc", "Страница 5: Рыбалка 2 ч.", true, new Title(String.join("", new String[]{"Страница 5: Рыбалка 2 ч."}), "CENTER", 14, 10, 228, 24, 0, true, "#DDCDAA", 14, 33, 228, 1),
							new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 220, String.join("", new String[]{
									"[align=LEFT][size=12][color=#38291E]Чтобы улучшить игровой опыт в бескрайней пустыни воды, добавлена вероятность выловить ящики с лутом при рыбалке, каждый тип биома имеет свой ящик. Также теперь механика рыбалки усложненна и имеет вид как в Stardew Valley[/color][/size][/align]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE")}),
					new Page("32a02dcf-73d4-4f40-8e44-72b48334d17a", "Страница 6: Флора и фауна", true, new Title(String.join("", new String[]{"Страница 6: Флора и фауна"}), "CENTER", 14, 10, 228, 24, 0, true, "#DDCDAA", 14, 33, 228, 1),
							new VisualElement[]{
									new VisualElement("TEXT", 24, 128, 208, 152, String.join("", new String[]{"В этом мире есть новенькие!\nНапример устрица, \nу нее есть жемчужина, она нужна для зелья удачи и чтобы украсить вашу броню."}), "LEFT",
											"", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 128, 0, 104, 114, String.join("", new String[]{""}), "LEFT", "pearl_oyster", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 24, 32, 112, 96, String.join("", new String[]{""}), "LEFT", "sculk_angler", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 168, 104, 62, 66, String.join("", new String[]{""}), "LEFT", "pearl", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")}),
					new Page("ec052623-6208-4006-9a7e-8b4456418fcc", "Страница 7: Транспорт", true, new Title(String.join("", new String[]{"Страница 7: Транспорт"}), "CENTER", 14, 10, 228, 24, 0, true, "#DDCDAA", 14, 33, 228, 1),
							new VisualElement[]{new VisualElement("TEXT", 18, 48, 220, 220, String.join("", new String[]{
									"[size=10]В сборке сервера есть моды на стройку кораблей, а также можно сделать батискаф из Immersive Machinery.\nВ авторском моде добавлен глайдер, на него можно наложить новые зачарования, а также базовые - починка и прочность.\nГлайдер можно считать элитрами для морей[/size]"}),
									"LEFT", "", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE"),
									new VisualElement("NAV_PREV", 12, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("NAV_NEXT", 226, 278, 18, 18, String.join("", new String[]{""}), "LEFT", "", new String[]{}, 100, "Button", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE"),
									new VisualElement("IMAGE", 72, 216, 102, 81, String.join("", new String[]{""}), "LEFT", "glider", new String[]{}, 100, "Button", "", "", "CLASSIC", "#8A6846", "#6D5237", "#FFEDC5", "", "SCREEN", "NONE")})})};
	private final List<ClickRegion> clickRegions = new ArrayList<>();
	private int categoryIndex = 0;
	private int pageIndex = 0;
	private int categoryListPage = 0;
	private float uiScale = 1f;
	private int originX = 0;
	private int originY = 0;

	public TetropiaGuideBookScreen() {
		this(net.minecraft.world.InteractionHand.MAIN_HAND);
	}

	public TetropiaGuideBookScreen(net.minecraft.world.InteractionHand hand) {
		super(Component.literal("Tetropia Guide"));
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		// No call to the default Screen render state: this screen owns all its visual strata.
		// In particular, this prevents a menu/background post-process from softening the book.
		clickRegions.clear();
		updateLayout();
		int startX = PAD;
		int pageX = PAD + SIDEBAR_W + GAP_W;
		int pageY = PAD;
		int sideY = PAD;
		fillD(graphics, startX, sideY, startX + SIDEBAR_W, sideY + PAGE_H, 0xEE28231F);
		fillD(graphics, startX + 5, sideY + 5, startX + SIDEBAR_W - 5, sideY + PAGE_H - 5, 0xFF342D27);
		fillD(graphics, pageX - 3, pageY - 3, pageX + PAGE_W + 3, pageY + PAGE_H + 3, 0xFF6C5033);
		fillD(graphics, pageX, pageY, pageX + PAGE_W, pageY + PAGE_H, 0xFFFFF4D6);
		drawCenteredD(graphics, Component.literal("Tetropia Guide"), startX + SIDEBAR_W / 2, sideY + 16, 0xFFFFE5B8);
		renderCategories(graphics, startX + 13, sideY + 42, SIDEBAR_W - 26);
		Page page = currentPage();
		if (page == null) {
			drawCenteredD(graphics, Component.literal("No pages"), pageX + PAGE_W / 2, pageY + 32, 0xFF4B3929);
			return;
		}
		if (page.showTitle)
			renderTitle(graphics, page.titleDesign, pageX, pageY);
		for (VisualElement element : page.elements)
			renderElement(graphics, element, pageX, pageY);
		renderNavigation(graphics, pageX, pageY);
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		// Deliberately no blurBeforeThisStratum(): only dim the world behind the book.
		graphics.fill(0, 0, width, height, 0xB0100D0B);
	}

	private void updateLayout() {
		float availableW = Math.max(1f, width - 6f);
		float availableH = Math.max(1f, height - 6f);
		uiScale = Math.max(0.05f, Math.min(1f, Math.min(availableW / DESIGN_W, availableH / DESIGN_H)));
		originX = Math.max(3, Math.round((width - DESIGN_W * uiScale) / 2f));
		originY = Math.max(3, Math.round((height - DESIGN_H * uiScale) / 2f));
	}

	private int sx(int designX) {
		return originX + Math.round(designX * uiScale);
	}

	private int sy(int designY) {
		return originY + Math.round(designY * uiScale);
	}

	private int sd(int designSize) {
		return Math.max(1, Math.round(designSize * uiScale));
	}

	private void fillD(GuiGraphicsExtractor graphics, int x1, int y1, int x2, int y2, int color) {
		graphics.fill(sx(x1), sy(y1), sx(x2), sy(y2), color);
	}

	private float crispTextScale(float requested) {
		double guiScale = Math.max(1.0, Minecraft.getInstance().getWindow().getGuiScale());
		int physicalScale = Math.max(1, (int) Math.round(Math.max(0.05f, requested) * guiScale));
		return (float) (physicalScale / guiScale);
	}

	private void drawTextD(GuiGraphicsExtractor graphics, Component text, int x, int y, int color) {
		float scale = crispTextScale(uiScale);
		Matrix3x2fStack pose = graphics.pose();
		pose.pushMatrix();
		pose.translate(sx(x), sy(y));
		pose.scale(scale, scale);
		graphics.text(font, text, 0, 0, color, false);
		pose.popMatrix();
	}

	private void drawCenteredD(GuiGraphicsExtractor graphics, Component text, int centerX, int y, int color) {
		float scale = crispTextScale(uiScale);
		Matrix3x2fStack pose = graphics.pose();
		pose.pushMatrix();
		pose.translate(sx(centerX), sy(y));
		pose.scale(scale, scale);
		graphics.text(font, text, -font.width(text) / 2, 0, color, false);
		pose.popMatrix();
	}

	private void addClickRegion(int x, int y, int w, int h, String type, String target) {
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(1, sx(x + w) - rx);
		int rh = Math.max(1, sy(y + h) - ry);
		clickRegions.add(new ClickRegion(rx, ry, rw, rh, type, target));
	}

	private void addScreenClickRegion(int x, int y, int w, int h, String type, String target) {
		clickRegions.add(new ClickRegion(x, y, Math.max(1, w), Math.max(1, h), type, target));
	}

	private void enableDesignScissor(GuiGraphicsExtractor graphics, int x, int y, int w, int h) {
		int x1 = sx(x);
		int y1 = sy(y);
		int x2 = sx(x + w);
		int y2 = sy(y + h);
		graphics.enableScissor(x1, y1, Math.max(x1 + 1, x2), Math.max(y1 + 1, y2));
	}

	private void renderCategories(GuiGraphicsExtractor graphics, int x, int y, int w) {
		int pageCount = Math.max(1, (CATEGORIES.length + CATEGORY_ROWS - 1) / CATEGORY_ROWS);
		categoryListPage = Math.max(0, Math.min(categoryListPage, pageCount - 1));
		int first = categoryListPage * CATEGORY_ROWS;
		int cy = y;
		for (int i = first; i < Math.min(CATEGORIES.length, first + CATEGORY_ROWS); i++) {
			Category category = CATEGORIES[i];
			boolean selected = i == categoryIndex;
			fillD(graphics, x - 4, cy - 4, x + w + 4, cy + 15, selected ? 0xFF5C4A3A : 0x00101010);
			drawTextD(graphics, Component.literal(category.name), x, cy, selected ? 0xFFFFE8B8 : 0xFFD7C4A5);
			addClickRegion(x - 4, cy - 4, w + 8, 19, "category", category.id);
			cy += 23;
		}
		if (pageCount > 1) {
			int pagerY = y + CATEGORY_ROWS * 23 + 3;
			if (categoryListPage > 0) {
				drawCenteredD(graphics, Component.literal("<"), x + 8, pagerY + 3, 0xFFFFE8B8);
				addClickRegion(x - 4, pagerY, 26, 18, "category_list", "prev");
			}
			drawCenteredD(graphics, Component.literal((categoryListPage + 1) + " / " + pageCount), x + w / 2, pagerY + 3, 0xFFD7C4A5);
			if (categoryListPage + 1 < pageCount) {
				drawCenteredD(graphics, Component.literal(">"), x + w - 8, pagerY + 3, 0xFFFFE8B8);
				addClickRegion(x + w - 22, pagerY, 26, 18, "category_list", "next");
			}
		}
	}

	private void changeCategoryListPage(int delta) {
		int pageCount = Math.max(1, (CATEGORIES.length + CATEGORY_ROWS - 1) / CATEGORY_ROWS);
		categoryListPage = Math.max(0, Math.min(categoryListPage + delta, pageCount - 1));
	}

	private void renderTitle(GuiGraphicsExtractor graphics, Title title, int pageX, int pageY) {
		int x = pageX + title.x;
		int y = pageY + title.y;
		enableDesignScissor(graphics, x, y, title.width, title.height);
		boolean rotated = title.rotation != 0;
		renderRichTextBlock(graphics, title.content, x, y, rotated ? title.height : title.width, rotated ? title.width : title.height, title.align, title.rotation);
		graphics.disableScissor();
		if (title.barVisible)
			fillD(graphics, pageX + title.barX, pageY + title.barY, pageX + title.barX + title.barWidth, pageY + title.barY + title.barHeight, parseHexColor(title.barColor, 0xFFDDCDAA));
	}

	private void renderElement(GuiGraphicsExtractor graphics, VisualElement element, int pageX, int pageY) {
		int x = pageX + element.x;
		int y = pageY + element.y;
		int w = Math.max(1, element.width);
		int h = Math.max(1, element.height);
		switch (element.type) {
			case "TEXT" -> {
				enableDesignScissor(graphics, x, y, w, h);
				renderRichTextBlock(graphics, element.content, x, y, w, h, element.align);
				graphics.disableScissor();
			}
			case "IMAGE" -> renderImage(graphics, element.mediaName, x, y, w, h);
			case "GIF" -> renderImage(graphics, currentFrame(element), x, y, w, h);
			case "BUTTON" -> {
				renderButton(graphics, element, x, y, w, h);
				addClickRegion(x, y, w, h, element.targetPageId.isBlank() ? "category" : "page", element.targetPageId.isBlank() ? element.targetCategoryId : element.targetPageId);
			}
			case "NAV_PREV" -> {
				if (canAdvance(-1)) {
					renderNavigationArrow(graphics, element, x, y, w, h, false);
					addClickRegion(x, y, w, h, "nav", "prev");
				}
			}
			case "NAV_NEXT" -> {
				if (canAdvance(1)) {
					renderNavigationArrow(graphics, element, x, y, w, h, true);
					addClickRegion(x, y, w, h, "nav", "next");
				}
			}
		}
	}

	private void renderButton(GuiGraphicsExtractor graphics, VisualElement element, int x, int y, int w, int h) {
		int bg = parseHexColor(element.buttonBackgroundColor, 0xFF8A6846);
		int border = parseHexColor(element.buttonBorderColor, 0xFF6D5237);
		int textColor = parseHexColor(element.buttonTextColor, 0xFFFFEDC5);
		boolean hasImage = element.buttonImageName != null && !element.buttonImageName.isBlank();
		boolean backgroundImage = hasImage && ("BACKGROUND".equals(element.buttonImageMode) || "IMAGE".equals(element.buttonStyle));
		if (backgroundImage)
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x, y, w, h);
		switch (element.buttonStyle) {
			case "FLAT" -> {
				if (!backgroundImage)
					fillD(graphics, x, y, x + w, y + h, bg);
				drawButtonBorder(graphics, x, y, w, h, border, 1);
			}
			case "OUTLINE" -> drawButtonBorder(graphics, x, y, w, h, border, 2);
			case "TRANSPARENT" -> {
			}
			case "IMAGE" -> {
				if (!backgroundImage)
					fillD(graphics, x, y, x + w, y + h, bg);
				drawButtonBorder(graphics, x, y, w, h, border, 1);
			}
			default -> {
				if (!backgroundImage) {
					fillD(graphics, x, y, x + w, y + h, border);
					if (w > 4 && h > 4)
						fillD(graphics, x + 2, y + 2, x + w - 2, y + h - 2, bg);
				} else {
					drawButtonBorder(graphics, x, y, w, h, border, 1);
				}
			}
		}
		int textLeft = x + 4;
		int textRight = x + w - 4;
		if (hasImage && "ICON_LEFT".equals(element.buttonImageMode)) {
			int icon = Math.max(4, Math.min(h - 6, Math.min(24, w / 3)));
			int iy = y + Math.max(2, (h - icon) / 2);
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x + 4, iy, icon, icon);
			textLeft += icon + 4;
		}
		Component label = Component.literal(element.label == null ? "Button" : element.label);
		int available = Math.max(1, textRight - textLeft);
		float labelScale = crispTextScale(uiScale);
		int logicalLabelWidth = Math.max(1, Math.round(font.width(label) * labelScale / Math.max(0.05f, uiScale)));
		int center = textLeft + available / 2;
		if (logicalLabelWidth > available)
			center = textLeft + logicalLabelWidth / 2;
		drawCenteredD(graphics, label, center, y + Math.max(2, (h - 9) / 2), textColor);
	}

	private void drawButtonBorder(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int color, int thickness) {
		for (int i = 0; i < thickness; i++) {
			fillD(graphics, x + i, y + i, x + w - i, y + i + 1, color);
			fillD(graphics, x + i, y + h - i - 1, x + w - i, y + h - i, color);
			fillD(graphics, x + i, y + i, x + i + 1, y + h - i, color);
			fillD(graphics, x + w - i - 1, y + i, x + w - i, y + h - i, color);
		}
	}

	private static int parseHexColor(String value, int fallback) {
		try {
			if (value != null && value.matches("#[0-9a-fA-F]{6}"))
				return 0xFF000000 | Integer.parseInt(value.substring(1), 16);
		} catch (Exception ignored) {
		}
		return fallback;
	}

	private void renderImage(GuiGraphicsExtractor graphics, String name, int x, int y, int w, int h) {
		renderResourceImage(graphics, name, "SCREEN", x, y, w, h);
	}

	private String currentFrame(VisualElement element) {
		if (element.frames.length == 0)
			return "";
		long frame = System.currentTimeMillis() / Math.max(20, element.frameDelay);
		return element.frames[(int) (frame % element.frames.length)];
	}

	private static String textureResource(String name, String typeName) {
		if (name == null || name.isBlank())
			return null;
		String namespace = "aqua_dominus";
		String pathName = name.trim().replace('\\', '/');
		int colon = pathName.indexOf(':');
		if (colon >= 0) {
			namespace = pathName.substring(0, colon);
			pathName = pathName.substring(colon + 1);
		}
		if (pathName.isBlank() || pathName.startsWith("/"))
			return null;
		String folder = switch (typeName == null ? "SCREEN" : typeName) {
			case "ITEM" -> "item";
			case "BLOCK" -> "block";
			default -> "screens";
		};
		if (!pathName.startsWith("textures/")) {
			if (pathName.startsWith("item/") || pathName.startsWith("block/") || pathName.startsWith("screens/")) {
				pathName = "textures/" + pathName;
			} else {
				pathName = "textures/" + folder + "/" + pathName;
			}
		}
		if (!pathName.endsWith(".png"))
			pathName += ".png";
		if (!namespace.matches("[a-z0-9_.-]+") || !pathName.matches("[a-z0-9/._-]+"))
			return null;
		for (String segment : pathName.split("/", -1)) {
			if (segment.isEmpty() || ".".equals(segment) || "..".equals(segment))
				return null;
		}
		return namespace + ":" + pathName;
	}

	private void renderResourceImage(GuiGraphicsExtractor graphics, String name, String typeName, int x, int y, int w, int h) {
		String resource = textureResource(name, typeName);
		if (resource == null)
			return;
		int colon = resource.indexOf(':');
		Identifier texture = Identifier.fromNamespaceAndPath(resource.substring(0, colon), resource.substring(colon + 1));
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(1, sx(x + w) - rx);
		int rh = Math.max(1, sy(y + h) - ry);
		graphics.blit(RenderPipelines.GUI_TEXTURED, texture, rx, ry, 0, 0, rw, rh, rw, rh);
	}

	private void renderNavigation(GuiGraphicsExtractor graphics, int pageX, int pageY) {
		Page page = currentPage();
		if (page != null) {
			// Compatibility fallback for books saved before v2.5.0. Once the element is
			// re-saved in MCreator, NAV_PREV / NAV_NEXT become normal configurable elements.
			if (canAdvance(-1) && !hasNavigationElement(page, "NAV_PREV")) {
				VisualElement fallback = defaultNavigationElement(false);
				renderNavigationArrow(graphics, fallback, pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, false);
				addClickRegion(pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, "nav", "prev");
			}
			if (canAdvance(1) && !hasNavigationElement(page, "NAV_NEXT")) {
				VisualElement fallback = defaultNavigationElement(true);
				renderNavigationArrow(graphics, fallback, pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, true);
				addClickRegion(pageX + fallback.x, pageY + fallback.y, fallback.width, fallback.height, "nav", "next");
			}
		}
		drawCenteredD(graphics, Component.literal((pageIndex + 1) + " / " + CATEGORIES[categoryIndex].pages.length), pageX + PAGE_W / 2, pageY + PAGE_H - 14, 0xFF806B52);
	}

	private boolean hasNavigationElement(Page page, String type) {
		for (VisualElement element : page.elements)
			if (type.equals(element.type))
				return true;
		return false;
	}

	private VisualElement defaultNavigationElement(boolean next) {
		return new VisualElement(next ? "NAV_NEXT" : "NAV_PREV", next ? 226 : 12, 278, 18, 18, "", "LEFT", "", new String[0], 100, "", "", "", "TRANSPARENT", "#FFF4D6", "#6D5237", "#6A5842", "", "SCREEN", "NONE");
	}

	private void renderNavigationArrow(GuiGraphicsExtractor graphics, VisualElement element, int x, int y, int w, int h, boolean right) {
		int bg = parseHexColor(element.buttonBackgroundColor, 0xFFFFF4D6);
		int border = parseHexColor(element.buttonBorderColor, 0xFF6D5237);
		int icon = parseHexColor(element.buttonTextColor, 0xFF6A5842);
		boolean hasImage = element.buttonImageName != null && !element.buttonImageName.isBlank();
		if ("IMAGE".equals(element.buttonStyle) && hasImage) {
			renderResourceImage(graphics, element.buttonImageName, element.buttonImageType, x, y, w, h);
			return;
		}
		switch (element.buttonStyle) {
			case "CLASSIC" -> {
				fillD(graphics, x, y, x + w, y + h, border);
				if (w > 4 && h > 4)
					fillD(graphics, x + 2, y + 2, x + w - 2, y + h - 2, bg);
			}
			case "FLAT" -> fillD(graphics, x, y, x + w, y + h, bg);
			case "OUTLINE" -> drawButtonBorder(graphics, x, y, w, h, border, 1);
			default -> {
			}
		}
		String glyphStyle = switch (element.align) {
			case "CENTER" -> "TRIANGLE";
			case "RIGHT" -> "DOUBLE";
			default -> "CHEVRON";
		};
		paintNavigationGlyphD(graphics, x, y, w, h, right, glyphStyle, icon);
	}

	/**
	 * Navigation glyphs are rasterized directly in final GUI pixels.
	 * This keeps the arrow proportions identical when the window becomes small:
	 * the logical rectangle is converted once, then the glyph is drawn inside
	 * that exact screen-space rectangle.
	 */
	private void paintNavigationGlyphD(GuiGraphicsExtractor graphics, int x, int y, int w, int h, boolean right, String style, int color) {
		int rx = sx(x);
		int ry = sy(y);
		int rw = Math.max(3, sx(x + w) - rx);
		int rh = Math.max(3, sy(y + h) - ry);
		int cx = rx + rw / 2;
		int cy = ry + rh / 2;
		int radius = Math.max(2, Math.min(rw, rh) / 3);
		int thickness = Math.max(1, Math.min(rw, rh) / 9);
		if ("TRIANGLE".equals(style)) {
			int diameter = radius * 2;
			for (int step = 0; step <= diameter; step++) {
				int px = right ? cx - radius + step : cx + radius - step;
				int half = Math.max(0, radius - step / 2);
				graphics.fill(px, cy - half, px + thickness, cy + half + 1, color);
			}
			return;
		}
		paintChevronStrokeScreen(graphics, cx, cy, radius, thickness, right, color, 0);
		if ("DOUBLE".equals(style)) {
			int offset = Math.max(2, radius / 2 + 1);
			paintChevronStrokeScreen(graphics, cx, cy, radius, thickness, right, color, right ? -offset : offset);
		}
	}

	private void paintChevronStrokeScreen(GuiGraphicsExtractor graphics, int cx, int cy, int radius, int thickness, boolean right, int color, int offset) {
		for (int i = 0; i <= radius; i++) {
			int px = (right ? cx - radius / 2 + i : cx + radius / 2 - i) + offset;
			graphics.fill(px, cy - radius + i, px + thickness, cy - radius + i + thickness, color);
			graphics.fill(px, cy + radius - i, px + thickness, cy + radius - i + thickness, color);
		}
	}

	private boolean canAdvance(int delta) {
		if (CATEGORIES.length == 0)
			return false;
		if (delta > 0 && HIDE_NEXT_ARROW_AT_CATEGORY_END && categoryIndex >= 0 && categoryIndex < CATEGORIES.length && pageIndex >= CATEGORIES[categoryIndex].pages.length - 1)
			return false;
		int c = categoryIndex;
		int p = pageIndex + delta;
		if (delta > 0) {
			while (c < CATEGORIES.length && p >= CATEGORIES[c].pages.length) {
				c++;
				p = 0;
			}
			return c < CATEGORIES.length;
		} else {
			while (c >= 0 && p < 0) {
				c--;
				if (c >= 0)
					p = CATEGORIES[c].pages.length - 1;
			}
			return c >= 0;
		}
	}

	private void renderRichTextBlock(GuiGraphicsExtractor graphics, String markup, int x, int y, int width, int height, String align) {
		renderRichTextBlock(graphics, markup, x, y, width, height, align, 0);
	}

	private void renderRichTextBlock(GuiGraphicsExtractor graphics, String markup, int x, int y, int width, int height, String align, int rotation) {
		// Wrapping uses logical book coordinates, while glyph placement uses a
		// screen-pixel pen. This avoids cumulative rounding when uiScale < 1:
		// two neighboring glyphs can never collapse onto the same GUI pixels.
		List<Glyph> glyphs = buildGlyphs(markup == null ? "" : markup);
		List<Line> lines = wrapGlyphs(glyphs, Math.max(1, width));
		int cy = y;
		for (Line current : lines) {
			if (cy >= y + height)
				break;
			int offset = 0;
			String lineAlignment = current.align == null ? align : current.align;
			if ("CENTER".equals(lineAlignment))
				offset = Math.max(0, (width - current.width) / 2);
			else if ("RIGHT".equals(lineAlignment))
				offset = Math.max(0, width - current.width);
			int screenCx = sx(x + offset);
			int screenCy = sy(cy);
			if (rotation < 0) {
				screenCx = sx(x + cy - y);
				screenCy = sy(y + width - offset);
			} else if (rotation > 0) {
				screenCx = sx(x + height - (cy - y));
				screenCy = sy(y + offset);
			}
			for (Glyph glyph : current.glyphs) {
				if (cy + glyph.height > y + height)
					break;
				float screenScale = crispTextScale(glyph.scale * uiScale);
				Matrix3x2fStack pose = graphics.pose();
				pose.pushMatrix();
				pose.translate(screenCx, screenCy);
				if (rotation != 0)
					pose.rotate((float) Math.toRadians(rotation));
				pose.scale(screenScale, screenScale);
				graphics.text(font, glyph.component, 0, 0, 0xFF38291E, false);
				pose.popMatrix();
				int screenAdvance = glyphScreenAdvance(glyph.component, glyph.scale);
				int screenHeight = glyphScreenHeight(glyph.scale);
				if (glyph.actionType != null && !glyph.raw.isBlank()) {
					if (rotation < 0)
						addScreenClickRegion(screenCx, screenCy - screenAdvance, screenHeight, screenAdvance, glyph.actionType, glyph.actionTarget);
					else if (rotation > 0)
						addScreenClickRegion(screenCx - screenHeight, screenCy, screenHeight, screenAdvance, glyph.actionType, glyph.actionTarget);
					else
						addScreenClickRegion(screenCx, screenCy, screenAdvance, screenHeight, glyph.actionType, glyph.actionTarget);
				}
				if (rotation < 0)
					screenCy -= screenAdvance;
				else if (rotation > 0)
					screenCy += screenAdvance;
				else
					screenCx += screenAdvance;
			}
			cy += Math.max(10, current.height);
		}
	}

	private int glyphScreenAdvance(Component component, float designScale) {
		float screenScale = crispTextScale(designScale * uiScale);
		int advance = Math.max(1, (int) Math.ceil(font.width(component) * screenScale));
		// A one-pixel breathing space at reduced layout scales prevents glyph
		// edge pixels from touching after raster quantization.
		if (uiScale < 0.999f)
			advance += 1;
		return advance;
	}

	private int glyphScreenHeight(float designScale) {
		float screenScale = crispTextScale(designScale * uiScale);
		return Math.max(1, (int) Math.ceil(9 * screenScale) + (uiScale < 0.999f ? 1 : 0));
	}

	private List<Line> wrapGlyphs(List<Glyph> glyphs, int maxWidth) {
		List<Line> lines = new ArrayList<>();
		Line current = new Line();
		String paragraphAlign = null;
		boolean paragraphStart = true;
		int i = 0;
		while (i < glyphs.size()) {
			Glyph glyph = glyphs.get(i);
			if (paragraphStart && !glyph.newline) {
				paragraphAlign = glyph.align;
				paragraphStart = false;
			}
			if (glyph.newline) {
				current.align = paragraphAlign;
				lines.add(current);
				current = new Line();
				paragraphStart = true;
				paragraphAlign = null;
				i++;
				continue;
			}
			if (glyph.raw.isBlank()) {
				// Do not carry leading spaces to a freshly wrapped line.
				if (!current.glyphs.isEmpty()) {
					if (current.width + glyph.width > maxWidth) {
						current.align = paragraphAlign;
						lines.add(current);
						current = new Line();
					} else {
						current.add(glyph);
					}
				}
				i++;
				continue;
			}
			// Gather one word. It is placed as a unit whenever it fits; very long
			// words are hard-wrapped character by character so text can never escape
			// the configured text-zone width.
			List<Glyph> word = new ArrayList<>();
			int wordWidth = 0;
			int j = i;
			while (j < glyphs.size()) {
				Glyph next = glyphs.get(j);
				if (next.newline || next.raw.isBlank())
					break;
				word.add(next);
				wordWidth += next.width;
				j++;
			}
			if (!current.glyphs.isEmpty() && current.width + wordWidth > maxWidth) {
				current.align = paragraphAlign;
				lines.add(current);
				current = new Line();
			}
			if (wordWidth <= maxWidth) {
				for (Glyph part : word)
					current.add(part);
			} else {
				for (Glyph part : word) {
					if (!current.glyphs.isEmpty() && current.width + part.width > maxWidth) {
						current.align = paragraphAlign;
						lines.add(current);
						current = new Line();
					}
					current.add(part);
				}
			}
			i = j;
		}
		current.align = paragraphAlign;
		lines.add(current);
		return lines;
	}

	private List<Glyph> buildGlyphs(String markup) {
		List<Glyph> result = new ArrayList<>();
		List<RichToken> tokens = parse(markup);
		for (RichToken token : tokens) {
			State state = token.state;
			float designScale = Math.max(0.05f, state.size / 9.0f);
			for (int i = 0; i < token.text.length();) {
				int ch = token.text.codePointAt(i);
				i += Character.charCount(ch);
				if (ch == '\r')
					continue;
				if (ch == '\n') {
					result.add(new Glyph("", Component.empty(), 1f, 0, 10, true, null, null, null));
					continue;
				}
				String raw = new String(Character.toChars(ch));
				Component component = styledComponent(raw, state);
				// crispTextScale() may quantize the requested scale to a whole
				// physical-pixel multiple. In a small window that quantized scale
				// can be slightly larger than designScale * uiScale. Compute the
				// logical advance from the *actual* render scale so the next glyph
				// can never start before the previous one has finished.
				int screenAdvance = glyphScreenAdvance(component, designScale);
				int screenHeight = glyphScreenHeight(designScale);
				int gw = Math.max(1, (int) Math.ceil(screenAdvance / Math.max(0.05f, uiScale)));
				int gh = Math.max(1, (int) Math.ceil(screenHeight / Math.max(0.05f, uiScale)));
				result.add(new Glyph(raw, component, designScale, gw, gh, false, state.actionType, state.actionTarget, state.align));
			}
		}
		return result;
	}

	private Component styledComponent(String text, State state) {
		Style style = Style.EMPTY.withBold(state.bold).withItalic(state.italic).withUnderlined(state.underline || state.actionType != null).withStrikethrough(state.strike).withObfuscated(state.obfuscated);
		if (state.color != null)
			style = style.withColor(state.color);
		else if (state.actionType != null)
			style = style.withColor(0x2F62C9);
		return Component.literal(text).withStyle(style);
	}

	private static List<RichToken> parse(String markup) {
		List<RichToken> tokens = new ArrayList<>();
		Deque<StateFrame> stack = new ArrayDeque<>();
		State state = new State();
		Matcher matcher = TAG_PATTERN.matcher(markup);
		int last = 0;
		while (matcher.find()) {
			if (matcher.start() > last)
				tokens.add(new RichToken(markup.substring(last, matcher.start()), state.copy()));
			boolean closing = !matcher.group(1).isEmpty();
			String tag = matcher.group(2).toLowerCase(Locale.ROOT);
			String arg = matcher.group(3);
			if (closing) {
				boolean hasMatchingOpening = false;
				for (StateFrame frame : stack) {
					if (frame.tag.equals(tag)) {
						hasMatchingOpening = true;
						break;
					}
				}
				if (hasMatchingOpening) {
					while (!stack.isEmpty()) {
						StateFrame frame = stack.pop();
						state = frame.previous;
						if (frame.tag.equals(tag))
							break;
					}
				}
			} else {
				stack.push(new StateFrame(tag, state.copy()));
				switch (tag) {
					case "b" -> state.bold = true;
					case "i" -> state.italic = true;
					case "u" -> state.underline = true;
					case "s" -> state.strike = true;
					case "obf" -> state.obfuscated = true;
					case "align" -> state.align = arg != null && List.of("LEFT", "CENTER", "RIGHT").contains(arg.toUpperCase(Locale.ROOT)) ? arg.toUpperCase(Locale.ROOT) : "LEFT";
					case "size" -> state.size = safeInt(arg, DEFAULT_SIZE, 6, 48);
					case "color" -> state.color = parseColor(arg);
					case "url" -> {
						state.actionType = "url";
						state.actionTarget = arg == null ? "" : arg;
					}
					case "page" -> {
						state.actionType = "page";
						state.actionTarget = arg == null ? "" : arg;
					}
				}
			}
			last = matcher.end();
		}
		if (last < markup.length())
			tokens.add(new RichToken(markup.substring(last), state.copy()));
		return tokens;
	}

	private static Integer parseColor(String color) {
		try {
			if (color != null && color.matches("#[0-9a-fA-F]{6}"))
				return Integer.parseInt(color.substring(1), 16);
		} catch (Exception ignored) {
		}
		return null;
	}

	private static int safeInt(String value, int fallback, int min, int max) {
		try {
			return Math.max(min, Math.min(max, Integer.parseInt(value)));
		} catch (Exception ignored) {
			return fallback;
		}
	}

	private Page currentPage() {
		if (CATEGORIES.length == 0)
			return null;
		categoryIndex = Math.max(0, Math.min(categoryIndex, CATEGORIES.length - 1));
		Category category = CATEGORIES[categoryIndex];
		if (category.pages.length == 0)
			return null;
		pageIndex = Math.max(0, Math.min(pageIndex, category.pages.length - 1));
		return category.pages[pageIndex];
	}

	private void selectCategoryById(String id) {
		for (int i = 0; i < CATEGORIES.length; i++) {
			if (CATEGORIES[i].id.equals(id)) {
				categoryIndex = i;
				categoryListPage = i / CATEGORY_ROWS;
				pageIndex = 0;
				return;
			}
		}
	}

	private void selectPageById(String id) {
		for (int c = 0; c < CATEGORIES.length; c++) {
			for (int p = 0; p < CATEGORIES[c].pages.length; p++) {
				if (CATEGORIES[c].pages[p].id.equals(id)) {
					categoryIndex = c;
					categoryListPage = c / CATEGORY_ROWS;
					pageIndex = p;
					return;
				}
			}
		}
	}

	private void advancePage(int delta) {
		if (!canAdvance(delta))
			return;
		int c = categoryIndex;
		int p = pageIndex + delta;
		if (delta > 0) {
			while (c < CATEGORIES.length && p >= CATEGORIES[c].pages.length) {
				c++;
				p = 0;
			}
			if (c >= CATEGORIES.length)
				return;
		} else {
			while (c >= 0 && p < 0) {
				c--;
				if (c >= 0)
					p = CATEGORIES[c].pages.length - 1;
			}
			if (c < 0)
				return;
		}
		categoryIndex = c;
		categoryListPage = c / CATEGORY_ROWS;
		pageIndex = p;
	}

	/**
	 * External links always require explicit confirmation. The link is marked as
	 * untrusted so Minecraft displays its standard security warning and the URL
	 * before the browser is opened.
	 */
	private void openExternalLinkWithWarning(String url) {
		Minecraft minecraft = Minecraft.getInstance();
		minecraft.setScreen(new ConfirmLinkScreen(confirmed -> {
			if (confirmed)
				Util.getPlatform().openUri(url);
			minecraft.setScreen(this);
		}, url, false));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		double mouseX = event.x();
		double mouseY = event.y();
		if (event.button() == 0) {
			for (int i = clickRegions.size() - 1; i >= 0; i--) {
				ClickRegion region = clickRegions.get(i);
				if (!region.contains(mouseX, mouseY))
					continue;
				switch (region.type) {
					case "category" -> selectCategoryById(region.target);
					case "category_list" -> changeCategoryListPage("next".equals(region.target) ? 1 : -1);
					case "nav" -> advancePage("next".equals(region.target) ? 1 : -1);
					case "page" -> selectPageById(region.target);
					case "url" -> {
						if (region.target.startsWith("https://") || region.target.startsWith("http://")) {
							openExternalLinkWithWarning(region.target);
						}
					}
				}
				return true;
			}
		}
		return super.mouseClicked(event, doubleClick);
	}

	private record Category(String id, String name, Page[] pages) {
	}

	private record Page(String id, String title, boolean showTitle, Title titleDesign, VisualElement[] elements) {
	}

	private record Title(String content, String align, int x, int y, int width, int height, int rotation, boolean barVisible, String barColor, int barX, int barY, int barWidth, int barHeight) {
	}

	private record VisualElement(String type, int x, int y, int width, int height, String content, String align, String mediaName, String[] frames, int frameDelay, String label, String targetCategoryId, String targetPageId, String buttonStyle,
			String buttonBackgroundColor, String buttonBorderColor, String buttonTextColor, String buttonImageName, String buttonImageType, String buttonImageMode) {
	}

	private record StateFrame(String tag, State previous) {
	}

	private record RichToken(String text, State state) {
	}

	private record Glyph(String raw, Component component, float scale, int width, int height, boolean newline, String actionType, String actionTarget, String align) {
		static Glyph newLineGlyph() {
			return new Glyph("", Component.empty(), 1f, 0, 10, true, null, null, null);
		}
	}

	private record ClickRegion(int x, int y, int width, int height, String type, String target) {
		boolean contains(double mx, double my) {
			return mx >= x && mx < x + width && my >= y && my < y + height;
		}
	}

	private static final class Line {
		final List<Glyph> glyphs = new ArrayList<>();
		int width;
		int height = 0;
		String align;

		void add(Glyph glyph) {
			if (glyphs.isEmpty())
				align = glyph.align;
			glyphs.add(glyph);
			width += glyph.width;
			height = Math.max(height, glyph.height);
		}
	}

	private static final class State {
		boolean bold;
		boolean italic;
		boolean underline;
		boolean strike;
		boolean obfuscated;
		int size = DEFAULT_SIZE;
		Integer color;
		String actionType;
		String actionTarget;
		String align;

		State copy() {
			State copy = new State();
			copy.bold = bold;
			copy.italic = italic;
			copy.underline = underline;
			copy.strike = strike;
			copy.obfuscated = obfuscated;
			copy.size = size;
			copy.color = color;
			copy.actionType = actionType;
			copy.actionTarget = actionTarget;
			copy.align = align;
			return copy;
		}
	}
}
package com.gospi.aquadominus.client.model;

import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

// Made with Blockbench 5.2.2
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelgiant_squid extends EntityModel<LivingEntityRenderState> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(Identifier.fromNamespaceAndPath("aqua_dominus", "modelgiant_squid"), "main");
	public final ModelPart body;
	public final ModelPart left_eye;
	public final ModelPart right_eye;
	public final ModelPart left_front_leg;
	public final ModelPart big;
	public final ModelPart middle;
	public final ModelPart small;
	public final ModelPart left_middle_front_leg;
	public final ModelPart big2;
	public final ModelPart middle2;
	public final ModelPart small2;
	public final ModelPart left_middle_back_leg;
	public final ModelPart big3;
	public final ModelPart middle3;
	public final ModelPart small3;
	public final ModelPart left_back_leg;
	public final ModelPart big4;
	public final ModelPart middle4;
	public final ModelPart small4;
	public final ModelPart right_front_leg;
	public final ModelPart big5;
	public final ModelPart middle5;
	public final ModelPart small5;
	public final ModelPart right_middle_front_leg;
	public final ModelPart big6;
	public final ModelPart middle6;
	public final ModelPart small6;
	public final ModelPart right_middle_back_leg;
	public final ModelPart big7;
	public final ModelPart middle7;
	public final ModelPart small7;
	public final ModelPart right_back_leg;
	public final ModelPart big8;
	public final ModelPart middle8;
	public final ModelPart small8;

	public Modelgiant_squid(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.left_eye = this.body.getChild("left_eye");
		this.right_eye = this.body.getChild("right_eye");
		this.left_front_leg = this.body.getChild("left_front_leg");
		this.big = this.left_front_leg.getChild("big");
		this.middle = this.left_front_leg.getChild("middle");
		this.small = this.left_front_leg.getChild("small");
		this.left_middle_front_leg = this.body.getChild("left_middle_front_leg");
		this.big2 = this.left_middle_front_leg.getChild("big2");
		this.middle2 = this.left_middle_front_leg.getChild("middle2");
		this.small2 = this.left_middle_front_leg.getChild("small2");
		this.left_middle_back_leg = this.body.getChild("left_middle_back_leg");
		this.big3 = this.left_middle_back_leg.getChild("big3");
		this.middle3 = this.left_middle_back_leg.getChild("middle3");
		this.small3 = this.left_middle_back_leg.getChild("small3");
		this.left_back_leg = this.body.getChild("left_back_leg");
		this.big4 = this.left_back_leg.getChild("big4");
		this.middle4 = this.left_back_leg.getChild("middle4");
		this.small4 = this.left_back_leg.getChild("small4");
		this.right_front_leg = this.body.getChild("right_front_leg");
		this.big5 = this.right_front_leg.getChild("big5");
		this.middle5 = this.right_front_leg.getChild("middle5");
		this.small5 = this.right_front_leg.getChild("small5");
		this.right_middle_front_leg = this.body.getChild("right_middle_front_leg");
		this.big6 = this.right_middle_front_leg.getChild("big6");
		this.middle6 = this.right_middle_front_leg.getChild("middle6");
		this.small6 = this.right_middle_front_leg.getChild("small6");
		this.right_middle_back_leg = this.body.getChild("right_middle_back_leg");
		this.big7 = this.right_middle_back_leg.getChild("big7");
		this.middle7 = this.right_middle_back_leg.getChild("middle7");
		this.small7 = this.right_middle_back_leg.getChild("small7");
		this.right_back_leg = this.body.getChild("right_back_leg");
		this.big8 = this.right_back_leg.getChild("big8");
		this.middle8 = this.right_back_leg.getChild("middle8");
		this.small8 = this.right_back_leg.getChild("small8");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition body = partdefinition.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 0).addBox(-7.0F, -32.0F, -6.0F, 14.0F, 32.0F, 12.0F, new CubeDeformation(0.0F)).texOffs(53, 0).addBox(-3.9F, -42.0F, -4.0F, 8.0F, 10.0F, 8.0F, new CubeDeformation(0.0F)).texOffs(0, 45)
						.addBox(0.0F, -56.0F, -1.0F, 17.0F, 24.0F, 0.0F, new CubeDeformation(0.0F)).texOffs(0, 45).mirror().addBox(-17.0F, -56.0F, -1.0F, 17.0F, 24.0F, 0.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(43, 35)
						.addBox(-5.0F, 0.0F, -5.0F, 10.0F, 14.0F, 10.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 10.0F, 0.0F));
		PartDefinition left_eye = body.addOrReplaceChild("left_eye", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -2.5F, -2.5F, 0.0F, 5.0F, 5.0F, new CubeDeformation(0.0F)), PartPose.offset(7.1F, -7.5F, 1.5F));
		PartDefinition right_eye = body.addOrReplaceChild("right_eye", CubeListBuilder.create().texOffs(0, 0).mirror().addBox(0.0F, -2.5F, -2.5F, 0.0F, 5.0F, 5.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(-7.1F, -7.5F, 1.5F));
		PartDefinition left_front_leg = body.addOrReplaceChild("left_front_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(3.0F, 8.1667F, -4.9167F, 0.0F, -0.3927F, 0.0F));
		PartDefinition big = left_front_leg.addOrReplaceChild("big", CubeListBuilder.create().texOffs(54, 60).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle = left_front_leg.addOrReplaceChild("middle", CubeListBuilder.create().texOffs(38, 60).addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small = left_front_leg.addOrReplaceChild("small",
				CubeListBuilder.create().texOffs(41, 77).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(57, 79).addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition left_middle_front_leg = body.addOrReplaceChild("left_middle_front_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(6.0F, 8.1667F, -2.9167F, 0.0F, -1.309F, 0.0F));
		PartDefinition big2 = left_middle_front_leg.addOrReplaceChild("big2", CubeListBuilder.create().texOffs(54, 60).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle2 = left_middle_front_leg.addOrReplaceChild("middle2", CubeListBuilder.create().texOffs(38, 60).addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small2 = left_middle_front_leg.addOrReplaceChild("small2",
				CubeListBuilder.create().texOffs(41, 77).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(57, 79).addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition left_middle_back_leg = body.addOrReplaceChild("left_middle_back_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(6.0F, 8.1667F, 3.0833F, 0.0F, -1.8326F, 0.0F));
		PartDefinition big3 = left_middle_back_leg.addOrReplaceChild("big3", CubeListBuilder.create().texOffs(54, 60).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle3 = left_middle_back_leg.addOrReplaceChild("middle3", CubeListBuilder.create().texOffs(38, 60).addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small3 = left_middle_back_leg.addOrReplaceChild("small3",
				CubeListBuilder.create().texOffs(41, 77).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(57, 79).addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition left_back_leg = body.addOrReplaceChild("left_back_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(3.0F, 8.1667F, 5.0833F, 0.0F, -2.7489F, 0.0F));
		PartDefinition big4 = left_back_leg.addOrReplaceChild("big4", CubeListBuilder.create().texOffs(54, 60).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle4 = left_back_leg.addOrReplaceChild("middle4", CubeListBuilder.create().texOffs(38, 60).addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small4 = left_back_leg.addOrReplaceChild("small4",
				CubeListBuilder.create().texOffs(41, 77).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(57, 79).addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition right_front_leg = body.addOrReplaceChild("right_front_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-3.0F, 8.1667F, -4.9167F, 0.0F, 0.3927F, 0.0F));
		PartDefinition big5 = right_front_leg.addOrReplaceChild("big5", CubeListBuilder.create().texOffs(54, 60).mirror().addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle5 = right_front_leg.addOrReplaceChild("middle5", CubeListBuilder.create().texOffs(38, 60).mirror().addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small5 = right_front_leg.addOrReplaceChild("small5", CubeListBuilder.create().texOffs(41, 77).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(57, 79).mirror()
				.addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition right_middle_front_leg = body.addOrReplaceChild("right_middle_front_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-6.0F, 8.1667F, -2.9167F, 0.0F, 1.309F, 0.0F));
		PartDefinition big6 = right_middle_front_leg.addOrReplaceChild("big6", CubeListBuilder.create().texOffs(54, 60).mirror().addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle6 = right_middle_front_leg.addOrReplaceChild("middle6", CubeListBuilder.create().texOffs(38, 60).mirror().addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small6 = right_middle_front_leg.addOrReplaceChild("small6", CubeListBuilder.create().texOffs(41, 77).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(57, 79).mirror()
				.addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition right_middle_back_leg = body.addOrReplaceChild("right_middle_back_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-6.0F, 8.1667F, 3.0833F, 0.0F, 1.8326F, 0.0F));
		PartDefinition big7 = right_middle_back_leg.addOrReplaceChild("big7", CubeListBuilder.create().texOffs(54, 60).mirror().addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle7 = right_middle_back_leg.addOrReplaceChild("middle7", CubeListBuilder.create().texOffs(38, 60).mirror().addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small7 = right_middle_back_leg.addOrReplaceChild("small7", CubeListBuilder.create().texOffs(41, 77).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(57, 79).mirror()
				.addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 26.8333F, 0.1667F));
		PartDefinition right_back_leg = body.addOrReplaceChild("right_back_leg", CubeListBuilder.create(), PartPose.offsetAndRotation(-3.0F, 8.1667F, 5.0833F, 0.0F, 2.7489F, 0.0F));
		PartDefinition big8 = right_back_leg.addOrReplaceChild("big8", CubeListBuilder.create().texOffs(54, 60).mirror().addBox(-3.0F, -1.0F, -1.5F, 6.0F, 14.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 0.8333F, -0.0833F));
		PartDefinition middle8 = right_back_leg.addOrReplaceChild("middle8", CubeListBuilder.create().texOffs(38, 60).mirror().addBox(-2.0F, -0.5F, -1.5F, 4.0F, 13.0F, 3.0F, new CubeDeformation(0.0F)).mirror(false),
				PartPose.offset(0.0F, 14.3333F, -0.0833F));
		PartDefinition small8 = right_back_leg.addOrReplaceChild("small8", CubeListBuilder.create().texOffs(41, 77).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 15.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false).texOffs(57, 79).mirror()
				.addBox(-2.0F, 15.0F, -1.0F, 4.0F, 4.0F, 2.0F, new CubeDeformation(0.0F)).mirror(false), PartPose.offset(0.0F, 26.8333F, 0.1667F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	public void setupAnim(LivingEntityRenderState state) {
		float limbSwing = state.walkAnimationPos;
		float limbSwingAmount = state.walkAnimationSpeed;
		float ageInTicks = state.ageInTicks;
		float netHeadYaw = state.yRot;
		float headPitch = state.xRot;

	}

}
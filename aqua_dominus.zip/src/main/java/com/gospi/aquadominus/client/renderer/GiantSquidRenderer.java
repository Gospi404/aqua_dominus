package com.gospi.aquadominus.client.renderer;

import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import com.gospi.aquadominus.entity.GiantSquidEntity;
import com.gospi.aquadominus.client.mob.GiantSquidModel;
import com.gospi.aquadominus.client.mob.GiantSquidPose;
import com.gospi.aquadominus.client.mob.GiantSquidRenderState;
import com.gospi.aquadominus.client.model.Modelgiant_squid;

public class GiantSquidRenderer extends MobRenderer<GiantSquidEntity, GiantSquidRenderState, GiantSquidModel> {
	private final Identifier entityTexture = Identifier.parse("aqua_dominus:textures/entities/giant_squid.png");

	public GiantSquidRenderer(EntityRendererProvider.Context context) {
		super(context, new GiantSquidModel(context.bakeLayer(Modelgiant_squid.LAYER_LOCATION)), 1.2f);
	}

	@Override
	public GiantSquidRenderState createRenderState() {
		return new GiantSquidRenderState();
	}

	@Override
	public void extractRenderState(GiantSquidEntity entity, GiantSquidRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		GiantSquidPose.fill(entity, state, partialTicks);
	}

	@Override
	public Identifier getTextureLocation(GiantSquidRenderState state) {
		return entityTexture;
	}
}
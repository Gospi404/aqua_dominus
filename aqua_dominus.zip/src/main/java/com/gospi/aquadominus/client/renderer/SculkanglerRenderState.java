package com.gospi.aquadominus.client.renderer;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

/** Данные для анимации модели (заполняются в SculkanglerRenderer#extractRenderState). */
public class SculkanglerRenderState extends LivingEntityRenderState {
	public float swimSpeed;   // 0..1
	public float jawOpen;     // 0..1
	public float lurkAmount;  // 0..1 (засада)
	public float lungeAmount; // 0..1 (рывок)
	public float aggroAmount; // 0..1.5 (есть цель / ярость)
	public boolean inWater;
}
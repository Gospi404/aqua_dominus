package com.gospi.aquadominus.client.renderer;

import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.layers.LivingEntityEmissiveLayer;
import net.minecraft.client.renderer.rendertype.RenderTypes;

import com.gospi.aquadominus.entity.SculkanglerEntity;
import com.gospi.aquadominus.client.SculkAnglerModel;

public class SculkanglerRenderer extends MobRenderer<SculkanglerEntity, SculkanglerRenderState, SculkAnglerModel> {
	private static final Identifier TEXTURE = Identifier.parse("aqua_dominus:textures/entities/sculk_angler.png");
	/** Маска свечения: рисуется поверх без учёта освещения, поэтому видна даже сквозь Darkness. */
	private static final Identifier GLOW_TEXTURE = Identifier.parse("aqua_dominus:textures/entities/sculk_angler_glow.png");

	public SculkanglerRenderer(EntityRendererProvider.Context context) {
		super(context, new SculkAnglerModel(context.bakeLayer(SculkAnglerModel.LAYER_LOCATION)), 0.5f);
		// Эмиссивный слой (как глаза медного голема). Яркость пульсирует вместе с приманкой.
		this.addLayer(new LivingEntityEmissiveLayer<>(this,
				state -> GLOW_TEXTURE,
				(state, partial) -> Mth.clamp(0.75F + 0.25F * Mth.sin(state.ageInTicks * (0.2F + state.lurkAmount * 0.25F + state.aggroAmount * 0.3F)), 0F, 1F),
				new SculkAnglerModel(context.bakeLayer(SculkAnglerModel.LAYER_LOCATION)),
				RenderTypes::eyes,
				false));
	}

	@Override
	public SculkanglerRenderState createRenderState() {
		return new SculkanglerRenderState();
	}

	@Override
	public void extractRenderState(SculkanglerEntity entity, SculkanglerRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		state.swimSpeed = Mth.clamp((float) entity.getDeltaMovement().length() * 2.0F, 0F, 1F);
		state.jawOpen = Mth.lerp(partialTicks, entity.jawOpenO, entity.jawOpen);
		state.lurkAmount = Mth.lerp(partialTicks, entity.lurkO, entity.lurk);
		state.lungeAmount = Mth.lerp(partialTicks, entity.lungeO, entity.lunge);
		state.aggroAmount = Mth.lerp(partialTicks, entity.aggroO, entity.aggro);
		state.inWater = entity.isInWater();
	}

	@Override
	public Identifier getTextureLocation(SculkanglerRenderState state) {
		return TEXTURE;
	}
}
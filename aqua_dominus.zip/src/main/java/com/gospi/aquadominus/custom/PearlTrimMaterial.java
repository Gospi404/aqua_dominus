package com.gospi.aquadominus.custom;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.core.component.DataComponents;

public final class PearlTrimMaterial {

    private static final ResourceKey<Item> PEARL_ITEM =
            ResourceKey.create(
                    Registries.ITEM,
                    Identifier.fromNamespaceAndPath(
                            "aqua_dominus", "pearl"
                    )
            );

    private static final ResourceKey<?> PEARL_MATERIAL =
            ResourceKey.create(
                    Registries.TRIM_MATERIAL,
                    Identifier.fromNamespaceAndPath(
                            "aqua_dominus", "pearl"
                    )
            );

    private PearlTrimMaterial() {
    }

    public static void register() {
        BuiltInRegistries.DATA_COMPONENT_INITIALIZERS.add(
                PEARL_ITEM,
                (components, registries, key) ->
                        components.set(
                                DataComponents.PROVIDES_TRIM_MATERIAL,
                                registries.getOrThrow(
                                        (ResourceKey) PEARL_MATERIAL
                                )
                        )
        );
    }
}


package com.gospi.aquadominus.custom;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.trim.TrimMaterial;
import net.minecraft.core.component.DataComponents;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;

@EventBusSubscriber(modid = "aqua_dominus")
public final class PearlTrimMaterialEvents {

    private static final ResourceKey<Item> PEARL_ITEM =
            ResourceKey.create(
                    Registries.ITEM,
                    Identifier.fromNamespaceAndPath("aqua_dominus", "pearl")
            );

    private static final ResourceKey<TrimMaterial> PEARL_MATERIAL =
            ResourceKey.create(
                    Registries.TRIM_MATERIAL,
                    Identifier.fromNamespaceAndPath("aqua_dominus", "pearl")
            );

    private PearlTrimMaterialEvents() {
    }

    @SubscribeEvent
    public static void modifyDefaultComponents(ModifyDefaultComponentsEvent event) {

        event.modifyMatching(
                (item, components) ->
                        item.builtInRegistryHolder().is(PEARL_ITEM),

                (components, registries, item) ->
                        components.set(
                                DataComponents.PROVIDES_TRIM_MATERIAL,
                                registries.getOrThrow(PEARL_MATERIAL)
                        )
        );
    }
}

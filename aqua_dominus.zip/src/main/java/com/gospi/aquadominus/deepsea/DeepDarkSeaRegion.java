package com.gospi.aquadominus.deepsea;

import com.mojang.datafixers.util.Pair;

import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;

import terrablender.api.Region;
import terrablender.api.RegionType;

import java.util.function.Consumer;

/**
 * Биом deep_dark_sea лежит ПОД океаном: только у дна и в толще породы под глубокими
 * (обычными, холодными и замёрзшими) океанами. Вода выше остаётся ванильным океаном.
 *
 * Как это работает: у каждой точки биома есть параметр depth (0 = поверхность, выше воды < 0,
 * под землёй > 0). Мы добавляем свою точку с depth от DEPTH_MIN и глубже. Ванильный океан с
 * его depth = 0 выигрывает там, где depth < DEPTH_MIN / 2, т.е. примерно выше 4 блоков над дном.
 * Параметр weirdness ограничен, поэтому биом идёт ПАТЧАМИ, а не сплошным покровом.
 */
public class DeepDarkSeaRegion extends Region {
	/** Чем ближе к 0, тем тоньше слой воды над дном, принадлежащий биому. Для ~4 блоков: -0.06. */
	private static final float DEPTH_MIN = -0.06F;
	/** Размер/частота патчей: шире диапазон = больше биома. Полный диапазон: -1.0 .. 1.0 */
	private static final float WEIRDNESS_MIN = -0.35F;
	private static final float WEIRDNESS_MAX = 0.35F;

	public DeepDarkSeaRegion(int weight) {
		super(Identifier.fromNamespaceAndPath(DeepSeaBiomes.MOD_ID, "deep_dark_sea_region"), RegionType.OVERWORLD, weight);
	}

	@Override
	public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
		// ванильные точки без замен
		this.addModifiedVanillaOverworldBiomes(mapper, builder -> {});

		Climate.Parameter full = Climate.Parameter.span(-1.0F, 1.0F);
		Climate.Parameter temperature = Climate.Parameter.span(-1.0F, 0.2F);        // ледяные, холодные и умеренные
		Climate.Parameter continentalness = Climate.Parameter.span(-1.05F, -0.455F); // глубокий океан
		Climate.Parameter depth = Climate.Parameter.span(DEPTH_MIN, 1.0F);
		Climate.Parameter weirdness = Climate.Parameter.span(WEIRDNESS_MIN, WEIRDNESS_MAX);

		mapper.accept(Pair.of(
				Climate.parameters(temperature, full, continentalness, full, depth, weirdness, 0.0F),
				DeepSeaBiomes.DEEP_DARK_SEA));
	}
}
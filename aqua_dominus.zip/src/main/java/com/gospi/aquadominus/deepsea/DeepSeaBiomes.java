package com.gospi.aquadominus.deepsea;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;

public final class DeepSeaBiomes {
	public static final String MOD_ID = "aqua_dominus";

	/** Описан в data/aqua_dominus/worldgen/biome/deep_dark_sea.json */
	public static final ResourceKey<Biome> DEEP_DARK_SEA = ResourceKey.create(Registries.BIOME, Identifier.fromNamespaceAndPath(MOD_ID, "deep_dark_sea"));

	private DeepSeaBiomes() {}
}

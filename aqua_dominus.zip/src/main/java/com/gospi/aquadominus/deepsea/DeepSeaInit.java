package com.gospi.aquadominus.deepsea;

import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;

import terrablender.api.Regions;
import terrablender.api.SurfaceRuleManager;

/** Самостоятельная регистрация (не трогает файлы, генерируемые MCreator). */
@EventBusSubscriber(modid = DeepSeaBiomes.MOD_ID)
public final class DeepSeaInit {
	@SubscribeEvent
	public static void commonSetup(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			Regions.register(new DeepDarkSeaRegion(2)); // вес региона: больше = чаще
			SurfaceRuleManager.addSurfaceRules(SurfaceRuleManager.RuleCategory.OVERWORLD, DeepSeaBiomes.MOD_ID, DeepSeaSurfaceRules.makeRules());
		});
	}

	private DeepSeaInit() {}
}

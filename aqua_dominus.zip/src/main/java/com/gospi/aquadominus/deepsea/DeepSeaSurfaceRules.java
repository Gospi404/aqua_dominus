package com.gospi.aquadominus.deepsea;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Noises;
import net.minecraft.world.level.levelgen.SurfaceRules;

/**
 * Дно deep_dark_sea: sculk лежит ПАТЧАМИ (по шуму), вокруг патча - кайма из сланца,
 * на остальном дне работают ванильные правила (гравий/песок и т.д.).
 */
public final class DeepSeaSurfaceRules {
	/** Порог шума для sculk-патчей. Больше = патчей меньше (диапазон шума примерно -1..1). */
	private static final double PATCH_MIN = 0.35D;
	/** Кайма вокруг патча. */
	private static final double RIM_MIN = 0.22D;

	private static final SurfaceRules.RuleSource SCULK = SurfaceRules.state(Blocks.SCULK.defaultBlockState());
	private static final SurfaceRules.RuleSource DEEPSLATE = SurfaceRules.state(Blocks.DEEPSLATE.defaultBlockState());
	private static final SurfaceRules.RuleSource COBBLED = SurfaceRules.state(Blocks.COBBLED_DEEPSLATE.defaultBlockState());

	public static SurfaceRules.RuleSource makeRules() {
		SurfaceRules.ConditionSource patch = SurfaceRules.noiseCondition(Noises.SURFACE, PATCH_MIN, 10.0D);
		SurfaceRules.ConditionSource rim = SurfaceRules.noiseCondition(Noises.SURFACE, RIM_MIN, PATCH_MIN);

		return SurfaceRules.ifTrue(SurfaceRules.isBiome(DeepSeaBiomes.DEEP_DARK_SEA),
				SurfaceRules.sequence(
						SurfaceRules.ifTrue(patch, SurfaceRules.sequence(
								SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR, SCULK),
								SurfaceRules.ifTrue(SurfaceRules.UNDER_FLOOR, DEEPSLATE))),
						SurfaceRules.ifTrue(rim, SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR, COBBLED))));
	}

	private DeepSeaSurfaceRules() {}
}
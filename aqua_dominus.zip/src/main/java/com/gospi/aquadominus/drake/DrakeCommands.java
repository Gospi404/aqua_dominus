package com.gospi.aquadominus.drake;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /drake spawn|despawn|tp|goto|stop|attack|emote|crew|locate|rep|raid
 * Доступ: операторы (gamemaster).
 */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class DrakeCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("drake")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))

                .then(Commands.literal("spawn")
                        .executes(c -> spawn(c, here(c)))
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                .executes(c -> spawn(c, BlockPosArgument.getBlockPos(c, "pos")))))
                .then(Commands.literal("despawn").executes(DrakeCommands::despawn))
                .then(Commands.literal("locate").executes(DrakeCommands::locate))
                .then(Commands.literal("tp")
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                .executes(c -> tp(c, BlockPosArgument.getBlockPos(c, "pos")))))
                .then(Commands.literal("goto")
                        .then(Commands.argument("pos", BlockPosArgument.blockPos())
                                .executes(c -> goTo(c, BlockPosArgument.getBlockPos(c, "pos")))))
                .then(Commands.literal("stop").executes(DrakeCommands::stop))
                .then(Commands.literal("attack")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> attack(c, EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("emote")
                        .then(Commands.literal("taunt").executes(c -> emote(c, 1)))
                        .then(Commands.literal("leap").executes(c -> emote(c, 2)))
                        .then(Commands.literal("roar").executes(c -> emote(c, 3))))
                .then(Commands.literal("crew")
                        .then(Commands.argument("count", IntegerArgumentType.integer(1, 40))
                                .executes(c -> crew(c, IntegerArgumentType.getInteger(c, "count")))))

                .then(Commands.literal("rep")
                        .then(Commands.literal("get")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> repGet(c, EntityArgument.getPlayer(c, "player")))))
                        .then(Commands.literal("add")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("amount", IntegerArgumentType.integer(-2000, 2000))
                                                .executes(c -> repAdd(c, EntityArgument.getPlayer(c, "player"),
                                                        IntegerArgumentType.getInteger(c, "amount"))))))
                        .then(Commands.literal("set")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .then(Commands.argument("value", IntegerArgumentType.integer(-1000, 1000))
                                                .executes(c -> repSet(c, EntityArgument.getPlayer(c, "player"),
                                                        IntegerArgumentType.getInteger(c, "value")))))))

                .then(scenesNode())
                .then(Commands.literal("raid")
                        .then(Commands.literal("start")
                                .executes(c -> raidStart(c, null))
                                .then(Commands.argument("beacon", BlockPosArgument.blockPos())
                                        .executes(c -> raidStart(c, BlockPosArgument.getBlockPos(c, "beacon")))))
                        .then(Commands.literal("stop").executes(DrakeCommands::raidStop))
                        .then(Commands.literal("status").executes(c -> {
                            c.getSource().sendSuccess(() -> Component.literal(DrakeRaids.status()), false);
                            return Command.SINGLE_SUCCESS;
                        }))));
    }

    private static BlockPos here(CommandContext<CommandSourceStack> c) {
        return BlockPos.containing(c.getSource().getPosition());
    }

    private static int fail(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendFailure(Component.literal(msg));
        return 0;
    }

    private static int ok(CommandContext<CommandSourceStack> c, String msg) {
        c.getSource().sendSuccess(() -> Component.literal(msg), true);
        return Command.SINGLE_SUCCESS;
    }

    private static DrakeEntity drake(CommandContext<CommandSourceStack> c) {
        return DrakeRaids.findDrake(c.getSource().getServer());
    }

    // ---------- управление ----------

    private static int spawn(CommandContext<CommandSourceStack> c, BlockPos pos) {
        if (drake(c) != null) return fail(c, "Дрейк уже существует (/drake locate, /drake despawn)");
        ServerLevel sl = c.getSource().getLevel();
        DrakeEntity d = DrakeRegistry.DRAKE.get().spawn(sl, pos, EntitySpawnReason.COMMAND);
        if (d == null) return fail(c, "Не удалось создать Дрейка");
        d.roar(sl);
        return ok(c, "Капитан Дрейк высадился в " + pos.toShortString());
    }

    private static int despawn(CommandContext<CommandSourceStack> c) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        d.vanish((ServerLevel) d.level());
        return ok(c, "Дрейк скрылся в дыму");
    }

    private static int locate(CommandContext<CommandSourceStack> c) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        return ok(c, "Дрейк: " + d.blockPosition().toShortString() + " (" + d.level().dimension().identifier() + "), здоровье "
                + (int) d.getHealth() + "/" + (int) d.getMaxHealth() + (d.hasLoot() ? ", несёт добычу" : ""));
    }

    private static int tp(CommandContext<CommandSourceStack> c, BlockPos pos) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        if (d.level() != c.getSource().getLevel()) return fail(c, "Дрейк в другом измерении");
        d.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        return ok(c, "Дрейк перемещён в " + pos.toShortString());
    }

    private static int goTo(CommandContext<CommandSourceStack> c, BlockPos pos) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        d.setAnchor(pos);
        return ok(c, "Дрейк идёт к " + pos.toShortString() + " и будет там стоять (/drake stop отменяет)");
    }

    private static int stop(CommandContext<CommandSourceStack> c) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        d.setAnchor(null);
        d.setTarget(null);
        d.getNavigation().stop();
        return ok(c, "Дрейк успокоился");
    }

    private static int attack(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        d.setTarget(p);
        return ok(c, "Дрейк атакует " + p.getName().getString());
    }

    private static int emote(CommandContext<CommandSourceStack> c, int type) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        ServerLevel sl = (ServerLevel) d.level();
        switch (type) {
            case 1 -> d.taunt(sl);
            case 2 -> d.leapEmote(sl);
            default -> d.roar(sl);
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int crew(CommandContext<CommandSourceStack> c, int count) {
        DrakeEntity d = drake(c);
        if (d == null) return fail(c, "Дрейка нет в мире");
        int n = DrakeRaids.spawnCrew((ServerLevel) d.level(), d.blockPosition(), count, null).size();
        return ok(c, "Призвано скелетов команды: " + n + (n == 0 ? " (нет сущности aqua_dominus:drake_skeleton?)" : ""));
    }

    // ---------- репутация ----------

    private static int repGet(CommandContext<CommandSourceStack> c, ServerPlayer p) {
        int rep = DrakeReputation.get(c.getSource().getServer(), p.getUUID());
        return ok(c, p.getName().getString() + ": репутация " + rep + " (" + DrakeReputation.attitude(rep) + ")");
    }

    private static int repAdd(CommandContext<CommandSourceStack> c, ServerPlayer p, int amount) {
        int rep = DrakeReputation.add(c.getSource().getServer(), p.getUUID(), amount);
        return ok(c, p.getName().getString() + ": репутация " + rep);
    }

    private static int repSet(CommandContext<CommandSourceStack> c, ServerPlayer p, int value) {
        int rep = DrakeReputation.set(c.getSource().getServer(), p.getUUID(), value);
        return ok(c, p.getName().getString() + ": репутация " + rep);
    }

    // ---------- сцены ----------

    private static LiteralArgumentBuilder<CommandSourceStack> scenesNode() {
        return Commands.literal("scenes")
                .executes(DrakeCommands::scenesList)
                .then(Commands.literal("list").executes(DrakeCommands::scenesList))
                .then(Commands.literal("play")
                        .then(Commands.argument("name", StringArgumentType.word())
                                .suggests((ctx, b) -> SharedSuggestionProvider.suggest(
                                        DrakeScenes.list(ctx.getSource().getServer()), b))
                                .executes(c -> {
                                    String err = DrakeScenes.play(c.getSource().getServer(),
                                            StringArgumentType.getString(c, "name"), c.getSource().getPlayer());
                                    return err == null ? ok(c, "Сцена запущена") : fail(c, err);
                                })))
                .then(Commands.literal("stop").executes(c -> {
                    DrakeScenes.stop(c.getSource().getServer(), "Сцена остановлена");
                    return ok(c, "Сцена остановлена");
                }));
    }

    private static int scenesList(CommandContext<CommandSourceStack> c) {
        var names = DrakeScenes.list(c.getSource().getServer());
        String where = DrakeScenes.dir(c.getSource().getServer()).toString();
        if (names.isEmpty()) return ok(c, "Сцен нет. Положите .json в " + where);
        return ok(c, "Сцены (" + names.size() + "): " + String.join(", ", names) + "\nЗапуск: /drake scenes play <имя>. Папка: " + where);
    }

    // ---------- рейды ----------

    private static int raidStart(CommandContext<CommandSourceStack> c, BlockPos beacon) {
        ServerLevel sl = c.getSource().getLevel();
        if (beacon == null) {
            BlockPos best = null;
            double bd = Double.MAX_VALUE;
            var set = com.gospi.aquadominus.beacon.BeaconRegistry.all().get(sl);
            if (set != null) {
                for (BlockPos p : set) {
                    double d = p.distSqr(here(c));
                    if (d < bd) { bd = d; best = p; }
                }
            }
            if (best == null) return fail(c, "В этом измерении нет включённых загруженных маяков");
            beacon = best;
        }
        String err = DrakeRaids.start(sl, beacon);
        return err == null ? ok(c, "Рейд Дрейка на маяк " + beacon.toShortString() + " начался") : fail(c, err);
    }

    private static int raidStop(CommandContext<CommandSourceStack> c) {
        DrakeRaids.stop(c.getSource().getServer());
        return ok(c, "Рейд остановлен");
    }

    private DrakeCommands() {}
}
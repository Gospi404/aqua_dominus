package com.gospi.aquadominus.drake;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gospi.aquadominus.beacon.BeaconConfig;
import com.gospi.aquadominus.beacon.BeaconType;
import com.gospi.aquadominus.horn.HornConfig;

import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.ModConfigSpec;

/** config/aqua_dominus-drake.toml */
public final class DrakeConfig {
    public static final ModConfigSpec SPEC;

    // Отношение Дрейка к игрокам (репутация от -1000 до 1000)
    public static final ModConfigSpec.IntValue HOSTILE_THRESHOLD;
    public static final ModConfigSpec.IntValue FRIENDLY_THRESHOLD;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> BRIBES;

    // Бой
    public static final ModConfigSpec.DoubleValue STEAL_CHANCE;
    public static final ModConfigSpec.BooleanValue STEAL_ARTIFACTS;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> STEAL_ITEMS;
    public static final ModConfigSpec.IntValue RUM_COUNT;
    public static final ModConfigSpec.IntValue RUM_HEALTH_PERCENT;
    public static final ModConfigSpec.IntValue CREW_MAX;
    public static final ModConfigSpec.IntValue CREW_CALL_COUNT;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> CREW_TYPES;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> DEATH_LOOT;

    // Рейды
    public static final ModConfigSpec.BooleanValue AUTO_RAIDS;
    public static final ModConfigSpec.IntValue RAID_INTERVAL_MINUTES;
    public static final ModConfigSpec.IntValue RAID_WARNING_SECONDS;
    public static final ModConfigSpec.IntValue RAID_CAPTURE_SECONDS;
    public static final ModConfigSpec.IntValue CAPTURED_MINUTES;
    public static final ModConfigSpec.IntValue RAID_CREW_BASE;
    public static final ModConfigSpec.IntValue RAID_CREW_PER_PLAYER;
    public static final ModConfigSpec.IntValue DEFEAT_REP_PENALTY;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Репутация: как Дрейк относится к игроку (-1000..1000)").push("reputation");
        HOSTILE_THRESHOLD = b.comment("Ниже этого значения Дрейк нападает на игрока при виде")
                .defineInRange("hostileThreshold", -300, -1000, 0);
        FRIENDLY_THRESHOLD = b.comment("Выше этого значения Дрейк не нападает, делится слухами о рейдах и маяки с такими игроками не трогает")
                .defineInRange("friendlyThreshold", 300, 0, 1000);
        BRIBES = b.comment("Взятки: предмет=очков репутации за штуку (ПКМ по Дрейку предметом)")
                .defineListAllowEmpty("bribes", List.of("minecraft:gold_ingot=2", "minecraft:emerald=5", "minecraft:diamond=15"),
                        () -> "minecraft:gold_ingot=1", o -> o instanceof String s && s.contains("="));
        b.pop();

        b.comment("Бой").push("combat");
        STEAL_CHANCE = b.comment("Шанс украсть предмет при попадании по игроку").defineInRange("stealChance", 0.25, 0.0, 1.0);
        STEAL_ARTIFACTS = b.comment("Красть артефакты маяков (приоритетно). Вор светится и убегает; при смерти выпадает всё украденное")
                .define("stealArtifacts", true);
        STEAL_ITEMS = b.comment("Ценности, которые Дрейк ворует")
                .defineListAllowEmpty("stealItems", List.of("minecraft:gold_ingot", "minecraft:gold_block", "minecraft:emerald",
                        "minecraft:diamond", "minecraft:netherite_ingot"), () -> "minecraft:gold_ingot", o -> o instanceof String);
        RUM_COUNT = b.comment("Сколько раз Дрейк «пьёт ром» (лечится и отступает при низком здоровье)")
                .defineInRange("rumCount", 2, 0, 10);
        RUM_HEALTH_PERCENT = b.comment("Порог здоровья в % для рома").defineInRange("rumHealthPercent", 30, 5, 90);
        CREW_MAX = b.comment("Максимум живых скелетов команды, вызванных самим Дрейком").defineInRange("crewMax", 8, 0, 40);
        CREW_CALL_COUNT = b.comment("Сколько скелетов зовёт за раз").defineInRange("crewCallCount", 3, 1, 20);
        CREW_TYPES = b.comment("Команда Дрейка: id;вес (вес 0 отключает). Можно добавить aqua_dominus:drake_skeleton;3")
                .defineListAllowEmpty("crewTypes", List.of("minecraft:skeleton;6", "minecraft:drowned;4"),
                        () -> "minecraft:skeleton;1", o -> o instanceof String s && s.split(";").length == 2);
        DEATH_LOOT = b.comment("Добыча с Дрейка (дополнительно к украденному)")
                .defineListAllowEmpty("deathLoot", List.of("minecraft:gold_ingot=32", "minecraft:emerald=16", "minecraft:diamond=8"),
                        () -> "minecraft:gold_ingot=1", o -> o instanceof String s && s.contains("="));
        b.pop();

        b.comment("Рейды Дрейка на включённые маяки").push("raids");
        AUTO_RAIDS = b.comment("Рейды сами по таймеру (иначе только командой /drake raid start)").define("autoRaids", false);
        RAID_INTERVAL_MINUTES = b.defineInRange("intervalMinutes", 45, 1, 10080);
        RAID_WARNING_SECONDS = b.comment("Сколько секунд до высадки после предупреждения").defineInRange("warningSeconds", 60, 5, 600);
        RAID_CAPTURE_SECONDS = b.comment("Сколько секунд пираты должны удерживать маяк без игроков, чтобы захватить его")
                .defineInRange("captureSeconds", 120, 10, 1800);
        CAPTURED_MINUTES = b.comment("На сколько минут захваченный маяк отключается").defineInRange("capturedMinutes", 15, 1, 1440);
        RAID_CREW_BASE = b.defineInRange("crewBase", 6, 1, 60);
        RAID_CREW_PER_PLAYER = b.comment("Прибавка команды за каждого игрока рядом с маяком сверх первого")
                .defineInRange("crewPerExtraPlayer", 3, 0, 30);
        DEFEAT_REP_PENALTY = b.comment("Штраф к репутации игрокам, отбившим рейд").defineInRange("defeatRepPenalty", 25, 0, 500);
        b.pop();

        SPEC = b.build();
    }

    /** Предмет из строки "id" или "id=число". */
    private static Set<Item> items(List<? extends String> raw) {
        Set<Item> out = new HashSet<>();
        for (String s : raw) BeaconConfig.item(s.split("=")[0].trim()).ifPresent(out::add);
        return out;
    }

    public record CrewType(net.minecraft.world.entity.EntityType<?> type, int weight) {}

    public static List<CrewType> crewTypes() {
        List<CrewType> out = new java.util.ArrayList<>();
        for (String s : CREW_TYPES.get()) {
            String[] p = s.split(";");
            net.minecraft.resources.Identifier id = net.minecraft.resources.Identifier.tryParse(p[0].trim());
            if (id == null || !net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.containsKey(id)) continue;
            try {
                int w = Integer.parseInt(p[1].trim());
                if (w > 0) out.add(new CrewType(net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getValue(id), w));
            } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    public static Set<Item> stealItems() { return items(STEAL_ITEMS.get()); }

    /** Артефакты всех четырёх маяков из конфига маяков. */
    public static Set<Item> artifactItems() {
        Set<Item> out = new HashSet<>();
        for (BeaconType t : BeaconType.values()) {
            BeaconConfig.item(BeaconConfig.SECTIONS.get(t).artifact().get()).ifPresent(out::add);
        }
        return out;
    }

    public static Map<Item, Integer> bribeValues() {
        Map<Item, Integer> out = new HashMap<>();
        for (BeaconConfig.ItemReq r : HornConfig.items(BRIBES.get())) out.put(r.item(), r.count());
        return out;
    }

    public static List<BeaconConfig.ItemReq> deathLoot() { return HornConfig.items(DEATH_LOOT.get()); }

    private DrakeConfig() {}
}
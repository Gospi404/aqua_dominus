package com.gospi.aquadominus.drake;

import java.util.Map;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Разговор с Дрейком (ПКМ). Он всегда уходит от ответа, зачем ему артефакты. */
public final class DrakeDialogue {
    public static final int EVASIVE = 6, HOSTILE = 4, FRIENDLY = 4, BRIBE = 3;

    public static void interact(ServerLevel sl, DrakeEntity drake, ServerPlayer p, ItemStack held) {
        // 1. Взятка
        Map<Item, Integer> bribes = DrakeConfig.bribeValues();
        if (!held.isEmpty() && bribes.containsKey(held.getItem())) {
            int count = held.getCount();
            int gain = bribes.get(held.getItem()) * count;
            held.shrink(count);
            int rep = DrakeReputation.add(sl.getServer(), p.getUUID(), gain);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, drake.getX(), drake.getY() + 2, drake.getZ(), 15, 0.4, 0.4, 0.4, 0.02);
            drake.say(sl, "drake.bribe." + (1 + drake.getRandom().nextInt(BRIBE)));
            p.sendSystemMessage(Component.translatable("drake.rep_changed", "+" + gain, rep));
            drake.taunt(sl);
            return;
        }

        // 2. Реплика по отношению
        switch (DrakeReputation.attitude(sl.getServer(), p.getUUID())) {
            case HOSTILE -> {
                drake.say(sl, "drake.hostile." + (1 + drake.getRandom().nextInt(HOSTILE)));
                drake.setTarget(p);
            }
            case FRIENDLY -> {
                if (drake.getRandom().nextBoolean()) {
                    long min = DrakeRaids.minutesToNextRaid(sl.getServer());
                    if (min == 0) drake.say(sl, "drake.intel_now");
                    else if (min > 0) drake.say(sl, "drake.intel", min);
                    else drake.say(sl, "drake.intel_none");
                } else {
                    drake.say(sl, "drake.friendly." + (1 + drake.getRandom().nextInt(FRIENDLY)));
                }
            }
            default -> {
                drake.say(sl, "drake.evasive." + (1 + drake.getRandom().nextInt(EVASIVE)));
                if (drake.getRandom().nextInt(4) == 0) drake.taunt(sl);
            }
        }
    }

    private DrakeDialogue() {}
}

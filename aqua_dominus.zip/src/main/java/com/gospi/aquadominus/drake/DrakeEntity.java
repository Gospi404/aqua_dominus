package com.gospi.aquadominus.drake;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.gospi.aquadominus.beacon.BeaconConfig;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Капитан Дрейк: жадный король пиратов.
 * Умеет: прыжок на цель, вызов команды скелетов, воровство ценностей/артефактов с побегом,
 * «ром» (лечение и отступление при низком здоровье). Отношение к игрокам зависит от репутации.
 */
public class DrakeEntity extends Monster {
    public static final int EMOTE_TAUNT = 1, EMOTE_LEAP = 2, EMOTE_ROAR = 3;
    // Свои ID событий сущности, подальше от ванильных (у ванили заняты числа до ~80)
    private static final byte EVT_TAUNT = 100, EVT_LEAP = 101, EVT_ROAR = 102;

    // Клиентская анимация (не синхронизируется, запускается событием сущности)
    public int emote, emoteTick, emoteLen;

    private final List<ItemStack> loot = new ArrayList<>();
    private final List<UUID> crew = new ArrayList<>();
    private int fleeTicks, leapCooldown, crewCooldown, tauntCooldown;
    private int rumsLeft = -1;
    private BlockPos anchor;
    private boolean inScene;

    public DrakeEntity(EntityType<DrakeEntity> type, Level level) {
        super(type, level);
        this.xpReward = 1000;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300)
                .add(Attributes.MOVEMENT_SPEED, 0.28)
                .add(Attributes.ATTACK_DAMAGE, 9)
                .add(Attributes.ARMOR, 10)
                .add(Attributes.FOLLOW_RANGE, 32)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.STEP_HEIGHT, 1.0)
                .add(Attributes.WATER_MOVEMENT_EFFICIENCY, 1.0);
    }

    // ================= ИИ =================

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FleeGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, false) {
            @Override public boolean canUse() { return !DrakeEntity.this.inScene && super.canUse(); }
        });
        this.goalSelector.addGoal(3, new GuardAnchorGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8) {
            @Override public boolean canUse() { return !DrakeEntity.this.inScene && super.canUse(); }
        });
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0f) {
            @Override public boolean canUse() { return !DrakeEntity.this.inScene && super.canUse(); }
        });
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this) {
            @Override public boolean canUse() { return !DrakeEntity.this.inScene && super.canUse(); }
        });
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    /** Убегает от угрозы, пока fleeTicks > 0. */
    private static final class FleeGoal extends Goal {
        private final DrakeEntity drake;

        FleeGoal(DrakeEntity drake) {
            this.drake = drake;
            setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override public boolean canUse() { return drake.fleeTicks > 0; }
        @Override public boolean canContinueToUse() { return drake.fleeTicks > 0; }

        @Override
        public void tick() {
            if (drake.tickCount % 10 != 0) return;
            LivingEntity threat = drake.getTarget() != null ? drake.getTarget() : drake.getLastHurtByMob();
            if (threat == null) return;
            Vec3 away = drake.position().subtract(threat.position()).normalize().scale(14);
            Vec3 to = drake.position().add(away);
            drake.getNavigation().moveTo(to.x, to.y, to.z, 1.45);
        }
    }

    /** Если задана точка (рейд, /drake goto): без цели идёт к ней. */
    private static final class GuardAnchorGoal extends Goal {
        private final DrakeEntity drake;

        GuardAnchorGoal(DrakeEntity drake) {
            this.drake = drake;
            setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        private boolean far() {
            return drake.anchor != null && !drake.inScene && drake.getTarget() == null
                    && drake.distanceToSqr(drake.anchor.getX() + 0.5, drake.anchor.getY(), drake.anchor.getZ() + 0.5) > 9;
        }

        @Override public boolean canUse() { return far(); }
        @Override public boolean canContinueToUse() { return far(); }

        @Override
        public void start() {
            walkToAnchor();
        }

        @Override
        public void tick() {
            if (drake.tickCount % 10 == 0) walkToAnchor();
        }

        private void walkToAnchor() {
            drake.walkToward(new Vec3(drake.anchor.getX() + 0.5, drake.anchor.getY(), drake.anchor.getZ() + 0.5), 1.0);
        }
    }

    /**
     * Идёт к точке. Далёкая цель берётся шагами по 24 блока: поиск пути у моба ограничен
     * дальностью слежения, и на большие расстояния он просто стоял бы на месте.
     */
    public void walkToward(Vec3 dest, double speed) {
        Vec3 d = dest.subtract(position());
        double len = d.length();
        Vec3 step = len > 24 ? position().add(d.normalize().scale(24)) : dest;
        getNavigation().moveTo(step.x, step.y, step.z, speed);
    }

    public void setAnchor(BlockPos pos) { this.anchor = pos == null ? null : pos.immutable(); }
    public BlockPos getAnchor() { return anchor; }

    /** Во время сцены Дрейка нельзя бить и подкупать, он не атакует и не ходит сам. */
    public boolean isInScene() { return inScene; }
    public void setInScene(boolean value) { this.inScene = value; }

    // ================= Тик =================

    @Override
    public void tick() {
        super.tick();
        if (emoteTick > 0 && --emoteTick == 0) emote = 0;
        if (!level().isClientSide() && level() instanceof ServerLevel sl) serverTick(sl);
    }

    private void serverTick(ServerLevel sl) {
        if (rumsLeft < 0) rumsLeft = DrakeConfig.RUM_COUNT.get();
        if (fleeTicks > 0) fleeTicks--;
        if (leapCooldown > 0) leapCooldown--;
        if (crewCooldown > 0) crewCooldown--;
        if (tauntCooldown > 0) tauntCooldown--;

        if (inScene) {
            if (getTarget() != null) setTarget(null);
            fleeTicks = 0;
            return;
        }
        if (tickCount % 20 == 0) retarget(sl);

        // Водный мир: Дрейк ходит по дну и сам всплывает/ныряет к цели или к точке сбора
        if (isInWater()) {
            LivingEntity tt = getTarget();
            double dy = tt != null ? tt.getY() - getY() : (anchor != null ? anchor.getY() - getY() : 0);
            if (Math.abs(dy) > 0.8) {
                Vec3 dm = getDeltaMovement();
                setDeltaMovement(dm.x, Mth.clamp(dy * 0.05, -0.08, 0.12), dm.z);
            }
        }

        LivingEntity t = getTarget();
        if (t != null && t.isAlive() && fleeTicks <= 0) {
            double d = distanceToSqr(t);
            if (leapCooldown <= 0 && d > 25 && d < 225 && onGround()) leap(sl, t);
            if (crewCooldown <= 0 && getHealth() < getMaxHealth() * 0.6f) callCrew(sl);
            if (tauntCooldown <= 0 && this.random.nextInt(300) == 0) taunt(sl);
        }
    }

    /** Нападает на игроков с плохой репутацией, не трогает друзей. */
    private void retarget(ServerLevel sl) {
        LivingEntity cur = getTarget();
        if (cur instanceof ServerPlayer sp && getLastHurtByMob() != sp
                && DrakeReputation.attitude(sl.getServer(), sp.getUUID()) == DrakeReputation.Attitude.FRIENDLY) {
            setTarget(null);
            cur = null;
        }
        if (cur != null) return;
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(16),
                pp -> pp.isAlive() && !pp.isCreative() && !pp.isSpectator())) {
            if (DrakeReputation.attitude(sl.getServer(), p.getUUID()) == DrakeReputation.Attitude.HOSTILE && hasLineOfSight(p)) {
                setTarget(p);
                say(sl, "drake.hostile." + (1 + this.random.nextInt(DrakeDialogue.HOSTILE)));
                return;
            }
        }
    }

    // ================= Способности =================

    private void leap(ServerLevel sl, LivingEntity t) {
        Vec3 dir = t.position().subtract(position()).normalize();
        setDeltaMovement(dir.x * 1.1, 0.55, dir.z * 1.1);
        leapCooldown = 120;
        emote(sl, EVT_LEAP);
        sl.playSound(null, blockPosition(), SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.HOSTILE, 1.5f, 0.6f);
    }

    public void taunt(ServerLevel sl) {
        tauntCooldown = 400;
        emote(sl, EVT_TAUNT);
    }

    public void roar(ServerLevel sl) { emote(sl, EVT_ROAR); }

    public void leapEmote(ServerLevel sl) { emote(sl, EVT_LEAP); }

    private void emote(ServerLevel sl, byte event) {
        handleEntityEvent(event);
        sl.broadcastEntityEvent(this, event);
    }

    @Override
    public void handleEntityEvent(byte id) {
        switch (id) {
            case EVT_TAUNT -> startEmote(EMOTE_TAUNT, 50);
            case EVT_LEAP -> startEmote(EMOTE_LEAP, 20);
            case EVT_ROAR -> startEmote(EMOTE_ROAR, 60);
            default -> super.handleEntityEvent(id);
        }
    }

    private void startEmote(int type, int len) {
        this.emote = type;
        this.emoteLen = len;
        this.emoteTick = len;
    }

    private void callCrew(ServerLevel sl) {
        crew.removeIf(id -> {
            Entity e = sl.getEntity(id);
            return e == null || !e.isAlive();
        });
        crewCooldown = 600;
        int n = Math.min(Math.max(0, DrakeConfig.CREW_MAX.get() - crew.size()), DrakeConfig.CREW_CALL_COUNT.get());
        if (n <= 0) return;
        ServerPlayer tp = getTarget() instanceof ServerPlayer p ? p : null;
        crew.addAll(DrakeRaids.spawnCrew(sl, blockPosition(), n, tp));
        roar(sl);
        say(sl, "drake.crew");
    }

    /** «Ром»: при низком здоровье лечится и отступает. */
    private void checkRum(ServerLevel sl) {
        if (rumsLeft <= 0 || getHealth() >= getMaxHealth() * DrakeConfig.RUM_HEALTH_PERCENT.get() / 100f) return;
        rumsLeft--;
        heal(getMaxHealth() * 0.35f);
        fleeTicks = 120;
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1.5, getZ(), 25, 0.5, 0.6, 0.5, 0.05);
        sl.playSound(null, blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.HOSTILE, 1.5f, 1.4f);
        say(sl, "drake.rum");
    }

    // ================= Бой и воровство =================

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (inScene && !source.is(DamageTypes.GENERIC_KILL) && !source.is(DamageTypes.FELL_OUT_OF_WORLD)) return false;
        if (source.is(DamageTypes.DROWN)) return false;
        boolean r = super.hurtServer(level, source, amount);
        if (r && source.getEntity() instanceof ServerPlayer p) {
            DrakeReputation.add(level.getServer(), p.getUUID(), -2);
        }
        if (r && isAlive()) checkRum(level);
        return r;
    }

    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean hit = super.doHurtTarget(level, target);
        if (hit && target instanceof ServerPlayer p && this.random.nextFloat() < DrakeConfig.STEAL_CHANCE.get()) {
            if (stealFrom(p)) {
                fleeTicks = 160;
                addEffect(new MobEffectInstance(MobEffects.SPEED, 200, 2, false, true));
                addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * 180, 0, false, false)); // вор виден издалека
                level.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 30, 0.4, 0.8, 0.4, 0.03);
                say(level, "drake.steal");
            }
        }
        return hit;
    }

    private boolean stealFrom(ServerPlayer p) {
        int slot = -1;
        boolean art = false;
        if (DrakeConfig.STEAL_ARTIFACTS.get()) {
            Set<Item> artifacts = DrakeConfig.artifactItems();
            for (int i = 0; i < 36 && slot < 0; i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (!s.isEmpty() && artifacts.contains(s.getItem())) { slot = i; art = true; }
            }
        }
        if (slot < 0) {
            Set<Item> valuables = DrakeConfig.stealItems();
            for (int i = 0; i < 36 && slot < 0; i++) {
                ItemStack s = p.getInventory().getItem(i);
                if (!s.isEmpty() && valuables.contains(s.getItem())) slot = i;
            }
        }
        if (slot < 0) return false;
        ItemStack s = p.getInventory().getItem(slot);
        loot.add(s.split(art ? 1 : Math.min(s.getCount(), 16)));
        return true;
    }

    public boolean hasLoot() { return !loot.isEmpty(); }

    /** Бросает всё украденное на землю. */
    public void dropLoot(ServerLevel sl) {
        for (ItemStack s : loot) Block.popResource(sl, blockPosition(), s);
        loot.clear();
    }

    /** Исчезает в дыму (с добычей он выбрасывает её на землю). */
    public void vanish(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, getX(), getY() + 1, getZ(), 50, 0.5, 1.0, 0.5, 0.05);
        sl.playSound(null, blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.HOSTILE, 1.5f, 0.8f);
        dropLoot(sl);
        discard();
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            dropLoot(sl);
            for (BeaconConfig.ItemReq r : DrakeConfig.deathLoot()) {
                Block.popResource(sl, blockPosition(), new ItemStack(r.item(), r.count()));
            }
            say(sl, "drake.death");
            say(sl, "Я еще... вернусь...");
        }
    }

    // ================= Общение =================

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide()) return InteractionResult.SUCCESS;
        if (hand != InteractionHand.MAIN_HAND || !(player instanceof ServerPlayer sp) || !(level() instanceof ServerLevel sl)) {
            return InteractionResult.PASS;
        }
        if (inScene) {
            sp.sendSystemMessage(Component.translatable("drake.busy"));
            return InteractionResult.SUCCESS_SERVER;
        }
        DrakeDialogue.interact(sl, this, sp, sp.getItemInHand(hand));
        return InteractionResult.SUCCESS_SERVER;
    }

    /** Реплика Дрейка всем игрокам рядом. */
    public void say(ServerLevel sl, String key, Object... args) {
        Component line = Component.translatable("drake.say", Component.translatable(key, args));
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(32))) {
            p.sendSystemMessage(line);
        }
    }

    // ================= Звуки =================

    private static SoundEvent sound(String id) {
        return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse(id));
    }

    @Override public SoundEvent getAmbientSound() { return sound("entity.wither_skeleton.ambient"); }
    @Override public SoundEvent getHurtSound(DamageSource ds) { return sound("entity.wither_skeleton.hurt"); }
    @Override public SoundEvent getDeathSound() { return sound("entity.wither_skeleton.death"); }

    @Override
    public void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(sound("entity.wither_skeleton.step"), 0.2f, 0.8f);
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    /** Пират-скелет не тонет и его не сносит течением. */
    @Override
    public boolean isPushedByFluid() { return false; }

    @Override
    public boolean canBreatheUnderwater() { return true; }

    // ================= Сохранение =================

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        if (!loot.isEmpty()) out.store("loot", ItemStack.CODEC.listOf(), loot);
        if (anchor != null) out.store("anchor", BlockPos.CODEC, anchor);
        out.putInt("rums_left", rumsLeft);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        loot.clear();
        in.read("loot", ItemStack.CODEC.listOf()).ifPresent(loot::addAll);
        anchor = in.read("anchor", BlockPos.CODEC).orElse(null);
        rumsLeft = in.getIntOr("rums_left", -1);
    }
}
package com.gospi.aquadominus.drake;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.gospi.aquadominus.beacon.AquaBeaconBlockEntity;
import com.gospi.aquadominus.beacon.BeaconRegistry;
import com.gospi.aquadominus.beacon.ModRegistry;
import com.gospi.aquadominus.horn.SeaEvents;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.entity.EntityTypeTest;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Рейды Дрейка. Предупреждение -> высадка Дрейка и команды -> захват маяка.
 * Пока пираты рядом с маяком и игроков рядом нет, шкала захвата растёт. Игроки рядом её снижают.
 * Шкала заполнилась: маяк отключается на время (DrakeConfig.CAPTURED_MINUTES), пираты уходят.
 * Дрейк убит: рейд отбит, участники получают штраф к репутации.
 */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class DrakeRaids {
    private enum Phase { WARNING, ACTIVE }
    private enum Result { CAPTURED, DEFEATED, ABANDONED }

    private static final class Raid {
        final ServerLevel level;
        final BlockPos beacon;
        Phase phase = Phase.WARNING;
        int warnLeft;
        int capture;
        int emptySeconds;
        final ServerBossEvent bar;
        UUID drake;
        final List<UUID> crew = new ArrayList<>();

        Raid(ServerLevel level, BlockPos beacon) {
            this.level = level;
            this.beacon = beacon;
            this.warnLeft = DrakeConfig.RAID_WARNING_SECONDS.get();
            this.bar = new ServerBossEvent(UUID.randomUUID(), Component.translatable("drake.raid.bar_warning"),
                    BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.NOTCHED_10);
        }
    }

    private static Raid current;
    private static long nextAuto = -1;

    // ================= Управление =================

    public static boolean isRaidActive() { return current != null; }

    public static String status() {
        if (current == null) return "Рейда нет";
        return current.phase == Phase.WARNING
                ? "Предупреждение, высадка через " + current.warnLeft + " с, маяк " + current.beacon.toShortString()
                : "Идёт рейд на маяк " + current.beacon.toShortString() + ", захват " + current.capture + "/"
                        + DrakeConfig.RAID_CAPTURE_SECONDS.get() + " с";
    }

    /** Возвращает null при успехе или текст ошибки. */
    public static String start(ServerLevel sl, BlockPos beacon) {
        if (current != null) return "Рейд уже идёт";
        if (DrakeScenes.isActive()) return "Сейчас идёт сцена Дрейка";
        if (!(sl.getBlockEntity(beacon) instanceof AquaBeaconBlockEntity be) || !be.isActiveStage()) {
            return "В этой точке нет включённого аква-маяка";
        }
        DrakeEntity existing = findDrake(sl.getServer());
        if (existing != null && existing.level() != sl) return "Дрейк сейчас в другом измерении";

        Raid r = new Raid(sl, beacon);
        current = r;
        broadcast(sl.getServer(), Component.translatable("drake.raid.warning", beacon.getX(), beacon.getY(), beacon.getZ(),
                r.warnLeft));
        sl.playSound(null, beacon, SoundEvents.TRIAL_SPAWNER_OPEN_SHUTTER, SoundSource.HOSTILE, 3f, 0.5f);
        return null;
    }

    /** Останавливает рейд и убирает пиратов. */
    public static void stop(MinecraftServer server) {
        if (current != null) end(server, current, Result.ABANDONED);
    }

    public static long minutesToNextRaid(MinecraftServer server) {
        if (current != null) return 0;
        if (!DrakeConfig.AUTO_RAIDS.get() || nextAuto < 0) return -1;
        return Math.max(1, (nextAuto - server.overworld().getGameTime()) / 1200);
    }

    public static DrakeEntity findDrake(MinecraftServer server) {
        for (ServerLevel l : server.getAllLevels()) {
            List<? extends DrakeEntity> list = l.getEntities(EntityTypeTest.forClass(DrakeEntity.class), d -> d.isAlive());
            if (!list.isEmpty()) return list.get(0);
        }
        return null;
    }

    // ================= Тик =================

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post e) {
        MinecraftServer server = e.getServer();
        if (server.getTickCount() % 20 != 0) return;
        if (current == null) {
            autoRaid(server);
            return;
        }
        tickRaid(server, current);
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        if (current != null) current.bar.removeAllPlayers();
        current = null;
        nextAuto = -1;
        BeaconRegistry.clear();
    }

    private static void autoRaid(MinecraftServer server) {
        if (!DrakeConfig.AUTO_RAIDS.get()) return;
        long now = server.overworld().getGameTime();
        if (nextAuto < 0) {
            nextAuto = now + DrakeConfig.RAID_INTERVAL_MINUTES.get() * 1200L;
            return;
        }
        if (now < nextAuto || server.getPlayerList().getPlayers().isEmpty()) return;

        List<Object[]> options = new ArrayList<>();
        for (Map.Entry<ServerLevel, Set<BlockPos>> en : BeaconRegistry.all().entrySet()) {
            for (BlockPos p : en.getValue()) {
                List<ServerPlayer> near = SeaEvents.nearby(en.getKey(), p, 64);
                boolean allFriends = !near.isEmpty() && near.stream().allMatch(
                        pl -> DrakeReputation.attitude(server, pl.getUUID()) == DrakeReputation.Attitude.FRIENDLY);
                if (!allFriends) options.add(new Object[] {en.getKey(), p});
            }
        }
        if (options.isEmpty()) {
            nextAuto = now + 6000;
            return;
        }
        Object[] pick = options.get(server.overworld().getRandom().nextInt(options.size()));
        start((ServerLevel) pick[0], (BlockPos) pick[1]);
        nextAuto = now + DrakeConfig.RAID_INTERVAL_MINUTES.get() * 1200L;
    }

    private static void tickRaid(MinecraftServer server, Raid r) {
        ServerLevel sl = r.level;
        List<ServerPlayer> players = SeaEvents.nearby(sl, r.beacon, 128);
        for (ServerPlayer p : players) r.bar.addPlayer(p);
        for (ServerPlayer p : new ArrayList<>(r.bar.getPlayers())) if (!players.contains(p)) r.bar.removePlayer(p);

        // маяк пропал или уже не активен
        if (!(sl.getBlockEntity(r.beacon) instanceof AquaBeaconBlockEntity be) || !be.isActiveStage()) {
            end(server, r, Result.ABANDONED);
            return;
        }

        if (r.phase == Phase.WARNING) {
            r.warnLeft--;
            r.bar.setProgress(Mth.clamp(1f - r.warnLeft / (float) DrakeConfig.RAID_WARNING_SECONDS.get(), 0f, 1f));
            if (r.warnLeft == 10) {
                broadcast(server, Component.translatable("drake.raid.warning10", r.beacon.getX(), r.beacon.getY(), r.beacon.getZ()));
            }
            if (r.warnLeft <= 0) landRaiders(sl, r);
            return;
        }

        // --- ACTIVE ---
        if (players.isEmpty()) {
            if (++r.emptySeconds >= 120) {
                end(server, r, Result.ABANDONED);
                return;
            }
        } else {
            r.emptySeconds = 0;
        }

        Entity de = sl.getEntity(r.drake);
        boolean drakeAlive = de instanceof DrakeEntity dd && dd.isAlive();
        r.crew.removeIf(id -> {
            Entity e = sl.getEntity(id);
            return e == null || !e.isAlive();
        });

        // команда идёт к маяку и нападает на игроков рядом
        double bx = r.beacon.getX() + 0.5, by = r.beacon.getY(), bz = r.beacon.getZ() + 0.5;
        int raidersNear = drakeAlive && de.distanceToSqr(bx, by, bz) < 64 ? 1 : 0;
        for (UUID id : r.crew) {
            Entity e = sl.getEntity(id);
            if (e instanceof Mob m) {
                ServerPlayer target = null;
                double best = 14 * 14;
                for (ServerPlayer p : players) {
                    if (p.isCreative() || p.isSpectator()) continue;
                    double d = p.distanceToSqr(m);
                    if (d < best) { best = d; target = p; }
                }
                if (target != null) m.setTarget(target);
                else if (m.getTarget() == null) m.getNavigation().moveTo(bx, by, bz, 1.1);
                if (m.distanceToSqr(bx, by, bz) < 64) raidersNear++;
            }
        }

        int playersNear = 0;
        for (ServerPlayer p : players) if (!p.isCreative() && !p.isSpectator() && p.distanceToSqr(bx, by, bz) < 64) playersNear++;

        if (playersNear > 0) r.capture = Math.max(0, r.capture - 2);
        else if (raidersNear > 0) r.capture++;

        int total = DrakeConfig.RAID_CAPTURE_SECONDS.get();
        r.bar.setProgress(Mth.clamp(r.capture / (float) total, 0f, 1f));
        sl.sendParticles(ParticleTypes.LARGE_SMOKE, bx, by + 1.5, bz, 3, 0.4, 0.5, 0.4, 0.01);

        if (r.capture >= total) {
            be.capture(sl, DrakeConfig.CAPTURED_MINUTES.get() * 60);
            end(server, r, Result.CAPTURED);
        } else if (!drakeAlive) {
            end(server, r, Result.DEFEATED);
        }
    }

    private static void landRaiders(ServerLevel sl, Raid r) {
        r.phase = Phase.ACTIVE;
        r.bar.setColor(BossEvent.BossBarColor.RED);
        r.bar.setName(Component.translatable("drake.raid.bar"));
        r.bar.setProgress(0f);

        int n = Math.max(1, SeaEvents.nearby(sl, r.beacon, 64).size());
        BlockPos spot = findSpot(sl, r.beacon, 9, 13);

        DrakeEntity drake = findDrake(sl.getServer());
        if (drake != null) {
            drake.setPos(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
        } else {
            drake = DrakeRegistry.DRAKE.get().spawn(sl, spot, EntitySpawnReason.TRIGGERED);
        }
        if (drake == null) {
            end(sl.getServer(), r, Result.ABANDONED);
            return;
        }
        r.drake = drake.getUUID();
        drake.setAnchor(r.beacon);
        drake.roar(sl);
        drake.say(sl, "drake.raid.start");

        int crew = DrakeConfig.RAID_CREW_BASE.get() + DrakeConfig.RAID_CREW_PER_PLAYER.get() * (n - 1);
        r.crew.addAll(spawnCrew(sl, r.beacon, crew, null));
        sl.playSound(null, r.beacon, SoundEvents.TRIAL_SPAWNER_SPAWN_MOB, SoundSource.HOSTILE, 3f, 0.6f);
    }

    private static void end(MinecraftServer server, Raid r, Result result) {
        ServerLevel sl = r.level;
        r.bar.removeAllPlayers();
        current = null;

        for (UUID id : r.crew) {
            Entity e = sl.getEntity(id);
            if (e != null) {
                sl.sendParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1, e.getZ(), 15, 0.3, 0.5, 0.3, 0.03);
                e.discard();
            }
        }
        Entity de = r.drake == null ? null : sl.getEntity(r.drake);
        if (de instanceof DrakeEntity d) {
            d.setAnchor(null);
            if (result == Result.CAPTURED || result == Result.ABANDONED) d.vanish(sl);
        }

        switch (result) {
            case CAPTURED -> broadcast(server, Component.translatable("drake.raid.captured", r.beacon.getX(), r.beacon.getY(),
                    r.beacon.getZ(), DrakeConfig.CAPTURED_MINUTES.get()));
            case DEFEATED -> {
                broadcast(server, Component.translatable("drake.raid.defeated"));
                for (ServerPlayer p : SeaEvents.nearby(sl, r.beacon, 64)) {
                    DrakeReputation.add(server, p.getUUID(), -DrakeConfig.DEFEAT_REP_PENALTY.get());
                }
            }
            case ABANDONED -> { }
        }
    }

    // ================= Спавн =================

    /** Спавнит команду Дрейка из DrakeConfig.crewTypes (ванильные скелеты и утопленники). Возвращает UUID. */
    public static List<UUID> spawnCrew(ServerLevel sl, BlockPos center, int count, ServerPlayer target) {
        List<UUID> out = new ArrayList<>();
        List<DrakeConfig.CrewType> pool = DrakeConfig.crewTypes();
        if (pool.isEmpty()) return out;
        int total = pool.stream().mapToInt(DrakeConfig.CrewType::weight).sum();
        RandomSource rnd = sl.getRandom();
        for (int i = 0; i < count; i++) {
            int roll = rnd.nextInt(total);
            EntityType<?> type = pool.get(0).type();
            for (DrakeConfig.CrewType c : pool) {
                roll -= c.weight();
                if (roll < 0) { type = c.type(); break; }
            }
            BlockPos spot = findSpot(sl, center, 3, 8);
            Entity e = type.spawn(sl, spot, EntitySpawnReason.TRIGGERED);
            if (e == null) continue;
            if (e instanceof Mob m) {
                m.setPersistenceRequired();
                // водный мир: пираты не тонут и не горят на солнце
                m.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 20 * 60 * 60, 0, false, false));
                m.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 20 * 60 * 60, 0, false, false));
                if (target != null) m.setTarget(target);
            }
            sl.sendParticles(ParticleTypes.LARGE_SMOKE, spot.getX() + 0.5, spot.getY() + 1, spot.getZ() + 0.5, 8, 0.3, 0.5, 0.3, 0.02);
            out.add(e.getUUID());
        }
        return out;
    }

    /**
     * Ищет место высадки на расстоянии minR..maxR от center. Идёт сверху вниз через воздух и воду
     * до первого твёрдого блока, так что работает и на суше, и на дне океана.
     */
    public static BlockPos findSpot(ServerLevel sl, BlockPos center, int minR, int maxR) {
        RandomSource r = sl.getRandom();
        for (int attempt = 0; attempt < 16; attempt++) {
            double a = r.nextDouble() * Math.PI * 2;
            double d = minR + r.nextDouble() * Math.max(1, maxR - minR);
            int x = center.getX() + (int) (Math.cos(a) * d);
            int z = center.getZ() + (int) (Math.sin(a) * d);
            for (int dy = 4; dy >= -24; dy--) {
                BlockPos p = new BlockPos(x, center.getY() + dy, z);
                if (passable(sl, p) && passable(sl, p.above()) && !passable(sl, p.below())) {
                    return p;
                }
            }
        }
        return center.above();
    }

    private static boolean passable(ServerLevel sl, BlockPos p) {
        return sl.getBlockState(p).getCollisionShape(sl, p).isEmpty();
    }

    private static void broadcast(MinecraftServer server, Component msg) {
        server.getPlayerList().broadcastSystemMessage(msg, false);
    }

    private DrakeRaids() {}
}
package com.gospi.aquadominus.drake;

import java.util.function.Supplier;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.gospi.aquadominus.mob.PrismyEntity;
import com.gospi.aquadominus.mob.SeaperEntity;
import com.gospi.aquadominus.mob.SharkEntity;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredRegister;

@EventBusSubscriber(modid = ModRegistry.MODID)
public final class DrakeRegistry {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ModRegistry.MODID);

    public static final Supplier<EntityType<DrakeEntity>> DRAKE = ENTITIES.register("drake",
            id -> EntityType.Builder.of(DrakeEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 2.4f)
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, id)));

    // ---- водные мобы ----
    public static final Supplier<EntityType<PrismyEntity>> PRISMY = ENTITIES.register("prismy",
            id -> EntityType.Builder.of(PrismyEntity::new, MobCategory.WATER_CREATURE)
                    .sized(0.5f, 0.5f).clientTrackingRange(8)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, id)));

    public static final Supplier<EntityType<SeaperEntity>> SEAPER = ENTITIES.register("seaper",
            id -> EntityType.Builder.of(SeaperEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 0.9f).clientTrackingRange(8)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, id)));

    public static final Supplier<EntityType<SharkEntity>> SHARK = ENTITIES.register("shark",
            id -> EntityType.Builder.of(SharkEntity::new, MobCategory.WATER_CREATURE)
                    .sized(1.9f, 1.2f).clientTrackingRange(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, id)));

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(DRAKE.get(), DrakeEntity.createAttributes().build());
        event.put(PRISMY.get(), PrismyEntity.createAttributes().build());
        event.put(SEAPER.get(), SeaperEntity.createAttributes().build());
        event.put(SHARK.get(), SharkEntity.createAttributes().build());
    }

    private DrakeRegistry() {}
}
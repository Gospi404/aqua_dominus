package com.gospi.aquadominus.drake;

import java.util.UUID;

import com.gospi.aquadominus.beacon.ModRegistry;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Mth;

/**
 * Репутация игрока у Дрейка: -1000 (враг) .. +1000 (союзник). Хранится в command storage
 * aqua_dominus:drake (смотреть: /data get storage aqua_dominus:drake).
 */
public final class DrakeReputation {
    public enum Attitude { HOSTILE, NEUTRAL, FRIENDLY }

    private static final Identifier KEY = Identifier.fromNamespaceAndPath(ModRegistry.MODID, "drake");

    public static int get(MinecraftServer server, UUID id) {
        CompoundTag rep = server.getCommandStorage().get(KEY).getCompoundOrEmpty("rep");
        return rep.getIntOr(id.toString(), 0);
    }

    public static int set(MinecraftServer server, UUID id, int value) {
        var storage = server.getCommandStorage();
        CompoundTag tag = storage.get(KEY);
        CompoundTag rep = tag.getCompoundOrEmpty("rep");
        int v = Mth.clamp(value, -1000, 1000);
        rep.putInt(id.toString(), v);
        tag.put("rep", rep);
        storage.set(KEY, tag);
        return v;
    }

    public static int add(MinecraftServer server, UUID id, int delta) {
        return set(server, id, get(server, id) + delta);
    }

    public static Attitude attitude(int rep) {
        if (rep <= DrakeConfig.HOSTILE_THRESHOLD.get()) return Attitude.HOSTILE;
        if (rep >= DrakeConfig.FRIENDLY_THRESHOLD.get()) return Attitude.FRIENDLY;
        return Attitude.NEUTRAL;
    }

    public static Attitude attitude(MinecraftServer server, UUID id) {
        return attitude(get(server, id));
    }

    private DrakeReputation() {}
}

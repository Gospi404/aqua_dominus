package com.gospi.aquadominus.drake;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Сцены Дрейка из JSON-файлов в папке мира: <мир>/drake_scenes/имя.json
 * (также подхватываются файлы scene*.json прямо в папке мира).
 *
 * Формат: {"steps": [ {...}, {...} ]}. Шаг выполняется по порядку; в одном шаге можно сочетать ключи:
 *   "say": "текст"            реплика (& = цветовой код, "key:ключ.перевода" для перевода)
 *   "anim": "taunt|roar|leap|attack"
 *   "face": "player" | "north|south|east|west" | [x,y,z]      куда смотреть
 *   "walk": [x,y,z]           идти в точку (ждёт, пока дойдёт)
 *   "walk_rel": [dx,dy,dz]    идти на смещение от текущей позиции
 *   "walk_dir": "north", "blocks": 5    идти в сторону света на N блоков
 *   "walk_to_player": true    подойти к игроку; "speed": 1.0 множитель скорости
 *   "tp": [x,y,z]             мгновенно переместиться
 *   "command": "say привет"   выполнить команду от имени сервера
 *   "spawn_crew": 3           призвать команду
 *   "vanish": true            скрыться в дыму и закончить сцену
 *   "wait": тики или "wait_s": секунды   пауза после шага (для "say" по умолчанию по длине текста)
 * Во время сцены Дрейка нельзя бить и подкупать.
 */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class DrakeScenes {

    private static final class Run {
        final ServerLevel level;
        final UUID drake;
        final UUID starter;
        final JsonArray steps;
        int index;
        int waitTicks;
        int pendingWait;
        Vec3 dest;
        double speed = 1.0;
        double arrive = 2.25;
        int walkTicks;
        Vec3 faceTarget;
        boolean facePlayer;

        Run(ServerLevel level, UUID drake, UUID starter, JsonArray steps) {
            this.level = level;
            this.drake = drake;
            this.starter = starter;
            this.steps = steps;
        }
    }

    private static Run current;

    public static boolean isActive() { return current != null; }

    // ================= Файлы =================

    public static Path dir(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("drake_scenes");
    }

    private static final String EXAMPLE = """
            {
              "name": "Пример сцены",
              "steps": [
                { "face": "player", "say": "Ха! Ещё один искатель сокровищ.", "anim": "taunt" },
                { "say": "Следуй за мной, если хватит духу.", "walk_dir": "north", "blocks": 6 },
                { "face": "south", "say": "&6Артефакты? &rСам не знаю, зачем они мне. Но они блестят!", "anim": "roar" },
                { "walk_to_player": true, "say": "Давай не будем ссориться." },
                { "anim": "attack", "wait_s": 2 }
              ]
            }
            """;

    /** Имена сцен. При первом вызове создаёт папку и пример example.json. */
    public static List<String> list(MinecraftServer server) {
        Path dir = dir(server);
        Set<String> names = new LinkedHashSet<>();
        try {
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
                Files.writeString(dir.resolve("example.json"), EXAMPLE);
            }
            try (var s = Files.list(dir)) {
                s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5)).sorted().forEach(names::add);
            }
            try (var s = Files.list(server.getWorldPath(LevelResource.ROOT))) {
                s.map(p -> p.getFileName().toString()).filter(n -> n.startsWith("scene") && n.endsWith(".json"))
                        .map(n -> n.substring(0, n.length() - 5)).sorted().forEach(names::add);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return new ArrayList<>(names);
    }

    private static Path find(MinecraftServer server, String name) {
        if (name.contains("/") || name.contains("\\") || name.contains("..")) return null;
        Path p = dir(server).resolve(name + ".json");
        if (Files.exists(p)) return p;
        Path root = server.getWorldPath(LevelResource.ROOT).resolve(name + ".json");
        if (name.startsWith("scene") && Files.exists(root)) return root;
        return null;
    }

    // ================= Запуск и остановка =================

    /** Возвращает null при успехе или текст ошибки. */
    public static String play(MinecraftServer server, String name, ServerPlayer starter) {
        if (name.endsWith(".json")) name = name.substring(0, name.length() - 5);
        if (current != null) return "Сцена уже идёт (/drake scenes stop)";
        if (DrakeRaids.isRaidActive()) return "Идёт рейд, сцена невозможна";
        DrakeEntity d = DrakeRaids.findDrake(server);
        if (d == null) return "Дрейка нет в мире (/drake spawn)";
        Path p = find(server, name);
        if (p == null) return "Сцена не найдена: " + name + " (список: /drake scenes)";

        JsonArray steps;
        try {
            steps = JsonParser.parseString(Files.readString(p)).getAsJsonObject().getAsJsonArray("steps");
        } catch (Exception ex) {
            return "Ошибка в файле " + p.getFileName() + ": " + ex.getMessage();
        }
        if (steps == null || steps.isEmpty()) return "В сцене нет шагов (steps)";

        current = new Run((ServerLevel) d.level(), d.getUUID(), starter == null ? null : starter.getUUID(), steps);
        d.setInScene(true);
        d.setAnchor(null);
        d.setTarget(null);
        d.getNavigation().stop();
        return null;
    }

    public static void stop(MinecraftServer server, String message) {
        Run r = current;
        if (r == null) return;
        current = null;
        if (r.level.getEntity(r.drake) instanceof DrakeEntity d) {
            d.setInScene(false);
            d.getNavigation().stop();
        }
        if (message != null && r.starter != null) {
            ServerPlayer p = server.getPlayerList().getPlayer(r.starter);
            if (p != null) p.sendSystemMessage(Component.literal(message));
        }
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        current = null;
    }

    // ================= Выполнение =================

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post e) {
        Run r = current;
        if (r == null) return;
        MinecraftServer server = e.getServer();

        if (!(r.level.getEntity(r.drake) instanceof DrakeEntity d) || !d.isAlive()) {
            stop(server, "Дрейк исчез, сцена прервана");
            return;
        }

        // идёт к точке
        if (r.dest != null) {
            if (++r.walkTicks % 10 == 1) d.walkToward(r.dest, r.speed);
            double dx = d.getX() - r.dest.x, dz = d.getZ() - r.dest.z;
            if (dx * dx + dz * dz < r.arrive || r.walkTicks > 20 * 40) {
                r.dest = null;
                d.getNavigation().stop();
                r.waitTicks = r.pendingWait;
            }
            return;
        }

        // смотрит на игрока или на точку, пока ждёт
        if (r.facePlayer) {
            ServerPlayer p = targetPlayer(server, r, d);
            if (p != null) d.getLookControl().setLookAt(p);
        } else if (r.faceTarget != null) {
            d.getLookControl().setLookAt(r.faceTarget.x, r.faceTarget.y, r.faceTarget.z);
        }

        if (r.waitTicks > 0) {
            r.waitTicks--;
            return;
        }
        if (r.index >= r.steps.size()) {
            stop(server, "Сцена закончена");
            return;
        }

        JsonElement el = r.steps.get(r.index++);
        if (!el.isJsonObject()) return;
        try {
            exec(server, r, d, el.getAsJsonObject());
        } catch (RuntimeException ex) {
            stop(server, "Ошибка в шаге " + r.index + ": " + ex.getMessage());
        }
    }

    private static void exec(MinecraftServer server, Run r, DrakeEntity d, JsonObject o) {
        ServerLevel sl = r.level;

        if (o.has("tp")) {
            Vec3 v = vec(o.get("tp"));
            d.setPos(v.x, v.y, v.z);
            d.getNavigation().stop();
        }
        if (o.has("face")) face(server, r, d, o.get("face"));
        if (o.has("anim")) anim(sl, d, o.get("anim").getAsString());
        if (o.has("say")) say(server, r, d, o.get("say").getAsString());
        if (o.has("command")) {
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                    o.get("command").getAsString());
        }
        if (o.has("spawn_crew")) DrakeRaids.spawnCrew(sl, d.blockPosition(), o.get("spawn_crew").getAsInt(), null);
        if (o.has("vanish") && o.get("vanish").getAsBoolean()) {
            d.setInScene(false);
            d.vanish(sl);
            stop(server, "Дрейк скрылся, сцена закончена");
            return;
        }

        int wait;
        if (o.has("wait")) wait = o.get("wait").getAsInt();
        else if (o.has("wait_s")) wait = (int) (o.get("wait_s").getAsDouble() * 20);
        else if (o.has("say")) wait = Mth.clamp(o.get("say").getAsString().length() * 2, 40, 220);
        else wait = 0;
        r.pendingWait = wait;

        Vec3 dest = null;
        double arrive = 2.25;
        if (o.has("walk")) {
            dest = vec(o.get("walk"));
        } else if (o.has("walk_rel")) {
            dest = d.position().add(vec(o.get("walk_rel")));
        } else if (o.has("walk_dir")) {
            double blocks = o.has("blocks") ? o.get("blocks").getAsDouble() : 3;
            dest = d.position().add(direction(o.get("walk_dir").getAsString()).scale(blocks));
        } else if (o.has("walk_to_player") && o.get("walk_to_player").getAsBoolean()) {
            ServerPlayer p = targetPlayer(server, r, d);
            if (p != null) {
                dest = p.position();
                arrive = 6.25;
            }
        }

        if (dest != null) {
            r.dest = dest;
            r.arrive = arrive;
            r.speed = o.has("speed") ? o.get("speed").getAsDouble() : 1.0;
            r.walkTicks = 0;
            d.walkToward(dest, r.speed);
        } else {
            r.waitTicks = wait;
        }
    }

    // ================= Действия =================

    private static void anim(ServerLevel sl, DrakeEntity d, String name) {
        switch (name.toLowerCase(java.util.Locale.ROOT)) {
            case "taunt" -> d.taunt(sl);
            case "roar" -> d.roar(sl);
            case "leap" -> d.leapEmote(sl);
            case "attack" -> d.swing(InteractionHand.MAIN_HAND);
            default -> throw new IllegalArgumentException("неизвестная анимация '" + name + "'");
        }
    }

    private static void say(MinecraftServer server, Run r, DrakeEntity d, String text) {
        Component body = text.startsWith("key:")
                ? Component.translatable(text.substring(4))
                : Component.literal(text.replace('&', '\u00a7'));
        Component line = Component.translatable("drake.say", body);
        Set<ServerPlayer> audience = new LinkedHashSet<>(r.level.getEntitiesOfClass(ServerPlayer.class,
                d.getBoundingBox().inflate(48)));
        if (r.starter != null) {
            ServerPlayer s = server.getPlayerList().getPlayer(r.starter);
            if (s != null) audience.add(s);
        }
        for (ServerPlayer p : audience) p.sendSystemMessage(line);
    }

    private static void face(MinecraftServer server, Run r, DrakeEntity d, JsonElement el) {
        r.facePlayer = false;
        r.faceTarget = null;
        if (el.isJsonArray()) {
            r.faceTarget = vec(el);
            snapFace(d, r.faceTarget);
        } else {
            String s = el.getAsString();
            if (s.equalsIgnoreCase("player")) {
                r.facePlayer = true;
                ServerPlayer p = targetPlayer(server, r, d);
                if (p != null) snapFace(d, p.position());
            } else {
                Vec3 dir = direction(s);
                snapFace(d, d.position().add(dir));
            }
        }
    }

    /** Мгновенно поворачивает Дрейка лицом к точке. */
    private static void snapFace(DrakeEntity d, Vec3 target) {
        double dx = target.x - d.getX(), dz = target.z - d.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        d.setYRot(yaw);
        d.setYHeadRot(yaw);
        d.setYBodyRot(yaw);
    }

    private static ServerPlayer targetPlayer(MinecraftServer server, Run r, DrakeEntity d) {
        if (r.starter != null) {
            ServerPlayer s = server.getPlayerList().getPlayer(r.starter);
            if (s != null && s.level() == d.level()) return s;
        }
        Entity near = r.level.getNearestPlayer(d, 48);
        return near instanceof ServerPlayer sp ? sp : null;
    }

    // ================= Разбор значений =================

    private static Vec3 vec(JsonElement el) {
        JsonArray a = el.getAsJsonArray();
        if (a.size() != 3) throw new IllegalArgumentException("нужно три числа [x, y, z]");
        return new Vec3(a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble());
    }

    private static Vec3 direction(String s) {
        return switch (s.toLowerCase(java.util.Locale.ROOT)) {
            case "north" -> new Vec3(0, 0, -1);
            case "south" -> new Vec3(0, 0, 1);
            case "west" -> new Vec3(-1, 0, 0);
            case "east" -> new Vec3(1, 0, 0);
            default -> throw new IllegalArgumentException("направление '" + s + "' (north, south, east, west)");
        };
    }

    private DrakeScenes() {}
}
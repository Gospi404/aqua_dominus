package com.gospi.aquadominus.effect;

import com.gospi.aquadominus.registry.ModRegistry;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class WeightedEffect extends MobEffect {
    public WeightedEffect() {
        super(MobEffectCategory.HARMFUL, 0x4A4A55);
        // Прыжок = 0
        addAttributeModifier(Attributes.JUMP_STRENGTH, ModRegistry.id("weighted_jump"), -1.0,
                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        // Тяжёлая поступь
        addAttributeModifier(Attributes.MOVEMENT_SPEED, ModRegistry.id("weighted_speed"), -0.25,
                AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        // Больше гравитации (база 0.08)
        addAttributeModifier(Attributes.GRAVITY, ModRegistry.id("weighted_gravity"), 0.06,
                AttributeModifier.Operation.ADD_VALUE);
    }
}
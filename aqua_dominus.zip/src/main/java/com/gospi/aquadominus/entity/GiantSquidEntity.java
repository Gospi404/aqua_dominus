package com.gospi.aquadominus.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.phys.Vec3;

import com.gospi.aquadominus.init.AquaDominusModEntities;

/**
 * Гигантский кальмар: мини-босс. Особые атаки: удар щупальцами (SLAM), захват и сдавливание (GRAB),
 * чернильное облако (INK), рывок-таран (JET). Ниже 50% здоровья впадает в ярость.
 * Анимации и положение щупалец считает клиентская часть (client/mob/GiantSquidPose).
 */
public class GiantSquidEntity extends Monster {
	// типы анимаций (клиентская часть читает animType/animTick/animLen)
	public static final int A_NONE = 0, A_SLAM = 1, A_GRAB = 2, A_INK = 3, A_JET = 4;
	// ID событий сущности: байт, максимум 127; 116..122 не пересекаются с остальными мобами мода
	private static final byte EVT_SLAM = 116, EVT_GRAB_ON = 117, EVT_GRAB_OFF = 118, EVT_INK = 119, EVT_JET = 120, EVT_ENRAGE = 121, EVT_GRAB_REACH = 122;

	// ---- клиентская анимация (синхронизируется событиями сущности) ----
	public int animType, animTick, animLen;
	public boolean grabbing, enraged;
	public float smoothSpeed, smoothPitch, smoothTilt;
	/** Кэш обхода блоков щупальцами (клиент): 8 щупалец x 3 сегмента x 3 числа. */
	public final float[] tentacleAvoid = new float[72];
	public int poseTick = -1;

	// ---- логика (сервер) ----
	private int attack = A_NONE, attackTick, cooldown = 60, inkCooldown = 200;
	private UUID grabbed;
	private int grabTicks;
	private float grabBreakDamage;
	private Vec3 jetDir = Vec3.ZERO;
	private final List<UUID> jetHit = new ArrayList<>();
	private final ServerBossEvent bossEvent;

	public GiantSquidEntity(EntityType<GiantSquidEntity> type, Level world) {
		super(type, world);
		xpReward = 200;
		setNoAi(false);
		setPersistenceRequired();
		this.bossEvent = new ServerBossEvent(UUID.randomUUID(), net.minecraft.network.chat.Component.translatable(type.getDescriptionId()),
				BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10);
		this.setPathfindingMalus(PathType.WATER, 0);
		this.moveControl = new MoveControl(this) {
			@Override
			public void tick() {
				if (GiantSquidEntity.this.isInWater())
					GiantSquidEntity.this.setDeltaMovement(GiantSquidEntity.this.getDeltaMovement().add(0, 0.005, 0));
				if (this.operation == MoveControl.Operation.MOVE_TO && !GiantSquidEntity.this.getNavigation().isDone()) {
					double dx = this.wantedX - GiantSquidEntity.this.getX();
					double dy = this.wantedY - GiantSquidEntity.this.getY();
					double dz = this.wantedZ - GiantSquidEntity.this.getZ();
					float f = (float) (Mth.atan2(dz, dx) * (double) (180 / Math.PI)) - 90;
					float f1 = (float) (this.speedModifier * GiantSquidEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
					GiantSquidEntity.this.setYRot(this.rotlerp(GiantSquidEntity.this.getYRot(), f, 10));
					GiantSquidEntity.this.yBodyRot = GiantSquidEntity.this.getYRot();
					GiantSquidEntity.this.yHeadRot = GiantSquidEntity.this.getYRot();
					if (GiantSquidEntity.this.isInWater()) {
						GiantSquidEntity.this.setSpeed((float) GiantSquidEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
						float f2 = -(float) (Mth.atan2(dy, (float) Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI));
						f2 = Mth.clamp(Mth.wrapDegrees(f2), -85, 85);
						GiantSquidEntity.this.setXRot(this.rotlerp(GiantSquidEntity.this.getXRot(), f2, 5));
						float f3 = Mth.cos(GiantSquidEntity.this.getXRot() * (float) (Math.PI / 180.0));
						GiantSquidEntity.this.setZza(f3 * f1);
						GiantSquidEntity.this.setYya((float) (f1 * dy));
					} else {
						GiantSquidEntity.this.setSpeed(f1 * 0.05F);
					}
				} else {
					GiantSquidEntity.this.setSpeed(0);
					GiantSquidEntity.this.setYya(0);
					GiantSquidEntity.this.setZza(0);
				}
			}
		};
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new WaterBoundPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false) {
			@Override
			protected boolean canPerformAttack(LivingEntity entity) {
				// во время особых атак и захвата обычный укус отключён
				return GiantSquidEntity.this.attack == A_NONE && !GiantSquidEntity.this.grabbing
						&& this.isTimeToAttack() && this.mob.distanceToSqr(entity) < (this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth()) && this.mob.getSensing().hasLineOfSight(entity);
			}
		});
		this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
		this.goalSelector.addGoal(3, new RandomSwimmingGoal(this, 1, 40));
		this.targetSelector.addGoal(4, new NearestAttackableTargetGoal(this, Player.class, false, false));
	}

	// ================= Тик =================

	@Override
	public void tick() {
		super.tick();
		if (animTick > 0) animTick--;
		if (level() instanceof ServerLevel sl && !level().isClientSide()) serverTick(sl);
		else clientTick();
	}

	private void clientTick() {
		Vec3 v = getDeltaMovement();
		double h = Math.hypot(v.x, v.z);
		smoothSpeed = Mth.lerp(0.15f, smoothSpeed, (float) Mth.clamp(v.length() / 0.22, 0, 1));
		if (v.lengthSqr() > 1.0E-4) smoothPitch = Mth.lerp(0.15f, smoothPitch, (float) Math.atan2(v.y, h));
		float want;
		if (animTick > 0 && animType == A_JET) want = 1f;
		else if (grabbing || animTick > 0) want = 0f;
		else want = smoothSpeed;
		smoothTilt = Mth.lerp(0.12f, smoothTilt, want);
	}

	private void serverTick(ServerLevel sl) {
		bossEvent.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0f, 1f));
		if (!enraged && getHealth() < getMaxHealth() * 0.5f) {
			enraged = true;
			bossEvent.setColor(BossEvent.BossBarColor.RED);
			sl.broadcastEntityEvent(this, EVT_ENRAGE);
			playSound(sound("entity.ravager.roar"), 2.5f, 0.6f);
			inkCooldown = 0; // сразу может пустить чернила
		}
		if (cooldown > 0) cooldown--;
		if (inkCooldown > 0) inkCooldown--;

		tickGrab(sl);
		LivingEntity t = getTarget();
		switch (attack) {
			case A_NONE -> chooseAttack(sl, t);
			case A_SLAM -> tickSlam(sl);
			case A_GRAB -> tickGrabReach(sl, t);
			case A_INK -> tickInk(sl, t);
			case A_JET -> tickJet(sl, t);
			default -> attack = A_NONE;
		}
	}

	private float dmg() { return enraged ? 1.3f : 1.0f; }

	private static SoundEvent sound(String id) {
		return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse(id));
	}

	// ================= Выбор атаки =================

	private void chooseAttack(ServerLevel sl, LivingEntity t) {
		if (cooldown > 0 || grabbing || t == null || !t.isAlive()) return;
		double dist = Math.sqrt(distanceToSqr(t));
		int roll = this.random.nextInt(10);

		if (inkCooldown <= 0 && getHealth() < getMaxHealth() * 0.8f && this.random.nextInt(4) == 0) {
			start(sl, A_INK, 30, EVT_INK);
		} else if (dist < 6.5) {
			if (roll < 6 || !canGrab(t)) start(sl, A_SLAM, 40, EVT_SLAM);
			else start(sl, A_GRAB, 25, EVT_GRAB_REACH);
		} else if (dist < 22 && roll < 7) {
			start(sl, A_JET, 40, EVT_JET);
		}
	}

	private void start(ServerLevel sl, int type, int len, byte event) {
		attack = type;
		attackTick = 0;
		animType = type;
		animLen = len;
		animTick = len;
		jetHit.clear();
		sl.broadcastEntityEvent(this, event);
		getNavigation().stop();
	}

	private void finish(int cooldownTicks) {
		attack = A_NONE;
		cooldown = (int) (cooldownTicks * (enraged ? 0.6f : 1f));
	}

	// ================= Удар щупальцами =================

	private void tickSlam(ServerLevel sl) {
		attackTick++;
		getNavigation().stop();
		setDeltaMovement(getDeltaMovement().scale(0.5));
		if (attackTick == 22) {
			float power = 10f * dmg();
			for (LivingEntity e : victims(sl, 6.5, 3.5)) {
				e.hurtServer(sl, sl.damageSources().mobAttack(this), power);
				e.knockback(1.4, getX() - e.getX(), getZ() - e.getZ());
				e.setDeltaMovement(e.getDeltaMovement().add(0, 0.45, 0));
				e.hurtMarked = true;
			}
			for (int i = 0; i < 28; i++) {
				double a = i * Math.PI * 2 / 28;
				sl.sendParticles(ParticleTypes.BUBBLE_POP, getX() + Math.cos(a) * 5, getY() - 0.5, getZ() + Math.sin(a) * 5, 3, 0.3, 0.3, 0.3, 0.1);
			}
			sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() - 0.5, getZ(), 3, 1.5, 0.3, 1.5, 0);
			playSound(sound("entity.generic.explode"), 1.5f, 0.6f);
		}
		if (attackTick >= 40) finish(80);
	}

	private List<LivingEntity> victims(ServerLevel sl, double r, double h) {
		return sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(r, h, r), x -> x != this && x.isAlive()
				&& !(x instanceof GiantSquidEntity) && !(x instanceof ServerPlayer p && (p.isCreative() || p.isSpectator())));
	}

	// ================= Захват и сдавливание =================

	private boolean canGrab(LivingEntity v) {
		return !grabbing && v.getBbHeight() < 3.5f && v.isInWater()
				&& !(v instanceof ServerPlayer p && (p.isCreative() || p.isSpectator()));
	}

	private Vec3 holdPoint() {
		double yaw = Math.toRadians(yBodyRot);
		return position().add(-Math.sin(yaw) * 1.5, 0.3, Math.cos(yaw) * 1.5);
	}

	private void tickGrabReach(ServerLevel sl, LivingEntity t) {
		attackTick++;
		getNavigation().stop();
		if (attackTick == 12) {
			if (t != null && t.isAlive() && distanceToSqr(t) < 36 && canGrab(t)) {
				grabbed = t.getUUID();
				grabbing = true;
				grabTicks = 100;
				grabBreakDamage = 0;
				sl.broadcastEntityEvent(this, EVT_GRAB_ON);
				playSound(sound("entity.squid.squirt"), 1.5f, 0.5f);
			}
		}
		if (attackTick >= 25) finish(grabbing ? 20 : 40);
	}

	private void tickGrab(ServerLevel sl) {
		if (!grabbing) return;
		Entity v = grabbed == null ? null : sl.getEntity(grabbed);
		if (!(v instanceof LivingEntity victim) || !victim.isAlive() || --grabTicks <= 0) {
			releaseGrab(sl);
			return;
		}
		Vec3 center = victim.position().add(0, victim.getBbHeight() * 0.5, 0);
		victim.setDeltaMovement(holdPoint().subtract(center).scale(0.4));
		victim.hurtMarked = true;
		if (tickCount % 20 == 0) {
			victim.hurtServer(sl, sl.damageSources().mobAttack(this), 3f * dmg());
			victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 40, 2, false, false));
			sl.sendParticles(ParticleTypes.BUBBLE, victim.getX(), victim.getY() + 1, victim.getZ(), 10, 0.3, 0.4, 0.3, 0.05);
		}
	}

	private void releaseGrab(ServerLevel sl) {
		grabbing = false;
		grabbed = null;
		cooldown = Math.max(cooldown, 60);
		sl.broadcastEntityEvent(this, EVT_GRAB_OFF);
	}

	/** Жертва может вырваться, если нанесёт достаточно урона. */
	@Override
	public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
		boolean r = super.hurtServer(level, source, amount);
		if (r && grabbing && grabbed != null && source.getEntity() != null && source.getEntity().getUUID().equals(grabbed)) {
			grabBreakDamage += amount;
			if (grabBreakDamage >= 12f) releaseGrab(level);
		}
		return r;
	}

	// ================= Чернила =================

	private void tickInk(ServerLevel sl, LivingEntity t) {
		attackTick++;
		getNavigation().stop();
		if (attackTick == 8) {
			sl.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 0.5, getZ(), 220, 3.5, 2.0, 3.5, 0.12);
			playSound(sound("entity.squid.squirt"), 2.5f, 0.5f);
			for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(12), x -> x.isAlive() && !x.isCreative() && !x.isSpectator())) {
				p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 120, 0, false, true));
				p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 80, 0, false, true));
			}
			// отплывает назад-вверх
			Vec3 away = t != null ? position().subtract(t.position()).normalize() : Vec3.ZERO;
			setDeltaMovement(away.x * 0.9, 0.35, away.z * 0.9);
			inkCooldown = 500;
		}
		if (attackTick >= 30) finish(40);
	}

	// ================= Рывок-таран =================

	private void tickJet(ServerLevel sl, LivingEntity t) {
		attackTick++;
		if (attackTick < 16) {                       // накапливает силу, смотрит на цель
			getNavigation().stop();
			setDeltaMovement(getDeltaMovement().scale(0.6));
			if (t != null) getLookControl().setLookAt(t);
			if (attackTick == 15 && t != null) jetDir = t.getEyePosition().subtract(position()).normalize();
		} else if (attackTick < 31) {                // рывок
			if (attackTick == 16) playSound(sound("entity.dolphin.jump"), 2.0f, 0.5f);
			setDeltaMovement(jetDir.scale(1.1));
			float yaw = (float) (Mth.atan2(jetDir.x, jetDir.z) * (180.0 / Math.PI));
			setYRot(-yaw);
			yBodyRot = -yaw;
			yHeadRot = -yaw;
			sl.sendParticles(ParticleTypes.BUBBLE, getX(), getY() + 1, getZ(), 6, 0.6, 0.6, 0.6, 0.02);
			for (LivingEntity e : victims(sl, 1.0, 1.0)) {
				if (jetHit.contains(e.getUUID())) continue;
				jetHit.add(e.getUUID());
				e.hurtServer(sl, sl.damageSources().mobAttack(this), 12f * dmg());
				e.knockback(1.8, getX() - e.getX(), getZ() - e.getZ());
				e.hurtMarked = true;
			}
		}
		if (attackTick >= 40) finish(100);
	}

	// ================= Клиент: события =================

	@Override
	public void handleEntityEvent(byte id) {
		switch (id) {
			case EVT_SLAM -> startAnim(A_SLAM, 40);
			case EVT_GRAB_REACH -> startAnim(A_GRAB, 25);
			case EVT_INK -> startAnim(A_INK, 30);
			case EVT_JET -> startAnim(A_JET, 40);
			case EVT_GRAB_ON -> grabbing = true;
			case EVT_GRAB_OFF -> grabbing = false;
			case EVT_ENRAGE -> enraged = true;
			default -> super.handleEntityEvent(id);
		}
	}

	private void startAnim(int type, int len) {
		animType = type;
		animLen = len;
		animTick = len;
	}

	// ================= Босс-бар =================

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		bossEvent.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		bossEvent.removePlayer(player);
	}

	// ================= Прочее (из MCreator) =================

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.squid.ambient"));
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.squid.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.squid.death"));
	}

	@Override
	public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		return false;
	}

	@Override
	public boolean canBreatheUnderwater() {
		return !this.canDrownInFluidType(NeoForgeMod.WATER_TYPE.value());
	}

	@Override
	public boolean isPushedByFluid() {
		return false;
	}

	@Override
	public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason reason) {
		return this.level().dimension() == Level.OVERWORLD ? super.checkSpawnRules(level, reason) : true;
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
		event.register(AquaDominusModEntities.GIANT_SQUID.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (entityType, world, reason, pos, random) -> world.getDifficulty() != Difficulty.PEACEFUL
				&& (EntitySpawnReason.ignoresLightRequirements(reason) || Monster.isDarkEnoughToSpawn(world, pos, random)) && Mob.checkMobSpawnRules(entityType, world, reason, pos, random), RegisterSpawnPlacementsEvent.Operation.REPLACE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.4);
		builder = builder.add(Attributes.MAX_HEALTH, 200);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 4);
		builder = builder.add(Attributes.FOLLOW_RANGE, 24);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		builder = builder.add(NeoForgeMod.SWIM_SPEED, 0.4);
		return builder;
	}
}
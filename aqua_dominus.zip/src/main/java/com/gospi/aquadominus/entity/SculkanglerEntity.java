package com.gospi.aquadominus.entity;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.*;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.Difficulty;
import net.minecraft.util.Mth;
import net.minecraft.tags.FluidTags;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import java.util.EnumSet;

import com.gospi.aquadominus.init.AquaDominusModEntities;

public class SculkanglerEntity extends Monster {

	// ======================= НАСТРОЙКИ (крутите под вкус) =======================
	/** Множитель скорости плавания. Было: движение шло через SWIM_SPEED=0.23, т.е. вода душила скорость в 4 раза. */
	private static final float SWIM_SCALE = 1.4F;
	/** Радиус "тьмы": игроки В ВОДЕ ближе этого расстояния получают Darkness. */
	private static final double DARKNESS_RADIUS = 18.0D;
	private static final int LUNGE_ANIM_TICKS = 14;
	// ============================================================================

	private static final EntityDataAccessor<Boolean> DATA_LURKING = SynchedEntityData.defineId(SculkanglerEntity.class, EntityDataSerializers.BOOLEAN);
	private static final byte EVENT_LUNGE = 4;
	private static final byte EVENT_BITE = 5;

	private int lungeCooldown;
	private int lungeGlide;       // тики "скольжения" после рывка: движок не гасит импульс
	private int retreatTicks;     // тики отскока после укуса (hit & run)
	private Vec3 retreatDir = Vec3.ZERO;
	private Vec3 steerBias = Vec3.ZERO; // боковое смещение для кружения вокруг цели
	private int clientLungeTicks;
	private int clientBiteTicks;

	// сглаженные значения для рендера (клиент)
	public float jawOpen, jawOpenO;
	public float lurk, lurkO;
	public float lunge, lungeO;
	public float aggro, aggroO;

	public SculkanglerEntity(EntityType<SculkanglerEntity> type, Level world) {
		super(type, world);
		xpReward = 6;
		setNoAi(false);
		this.setPathfindingMalus(PathType.WATER, 0);
		this.moveControl = new MoveControl(this) {
			@Override
			public void tick() {
				final SculkanglerEntity self = SculkanglerEntity.this;
				if (self.isInWater())
					self.setDeltaMovement(self.getDeltaMovement().add(0, 0.005, 0));

				double attr = self.getAttributeValue(Attributes.MOVEMENT_SPEED);
				double cruise = this.speedModifier * attr * SWIM_SCALE * (self.isEnraged() ? 1.3D : 1.0D);

				// --- отскок после укуса: быстро уплываем назад, мордой к цели ---
				if (self.retreatTicks > 0 && self.isInWater()) {
					Vec3 v = self.getDeltaMovement();
					Vec3 desired = self.retreatDir.scale(Math.max(cruise, attr * SWIM_SCALE) * 0.9D);
					self.setDeltaMovement(v.add(desired.subtract(v).scale(0.5D)));
					self.setZza(0);
					self.setYya(0);
					return;
				}

				if (this.operation == MoveControl.Operation.MOVE_TO && !self.getNavigation().isDone()) {
					double dx = this.wantedX - self.getX();
					double dy = this.wantedY - self.getY();
					double dz = this.wantedZ - self.getZ();
					double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
					float f = (float) (Mth.atan2(dz, dx) * (double) (180 / Math.PI)) - 90;
					float f1 = (float) (this.speedModifier * attr);
					self.setYRot(this.rotlerp(self.getYRot(), f, 18));
					self.yBodyRot = self.getYRot();
					self.yHeadRot = self.getYRot();
					if (self.isInWater()) {
						self.setSpeed((float) attr);
						float f2 = -(float) (Mth.atan2(dy, (float) Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI));
						f2 = Mth.clamp(Mth.wrapDegrees(f2), -85, 85);
						self.setXRot(this.rotlerp(self.getXRot(), f2, 8));
						if (dist > 1.0E-4D && self.lungeGlide <= 0) {
							// Собственное рулёжное движение: плавно тянем скорость к желаемой.
							Vec3 desired = new Vec3(dx / dist, dy / dist, dz / dist).scale(cruise).add(self.steerBias);
							Vec3 v = self.getDeltaMovement();
							self.setDeltaMovement(v.add(desired.subtract(v).scale(0.5D)));
						}
						self.setZza(0);
						self.setYya(0);
					} else {
						self.setSpeed(f1 * 0.05F);
					}
				} else {
					self.setSpeed(0);
					self.setYya(0);
					self.setZza(0);
				}
			}
		};
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new WaterBoundPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(0, new LurkGoal(this));
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false) {
			@Override
			protected boolean canPerformAttack(LivingEntity entity) {
				return this.isTimeToAttack() && this.mob.distanceToSqr(entity) < (this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth()) && this.mob.getSensing().hasLineOfSight(entity);
			}
		});
		this.targetSelector.addGoal(2, new HurtByTargetGoal(this));
		// патруль стал живее: чаще выбирает новую точку и плывёт бодрее
		this.goalSelector.addGoal(3, new RandomSwimmingGoal(this, 0.6, 20));
		this.targetSelector.addGoal(4, new NearestAttackableTargetGoal(this, Player.class, false, false));
	}

	// ========================== состояние и синхронизация ==========================

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_LURKING, false);
	}

	public boolean isLurking() {
		return this.entityData.get(DATA_LURKING);
	}

	public void setLurking(boolean value) {
		this.entityData.set(DATA_LURKING, value);
	}

	/** Ярость: меньше половины здоровья - быстрее, чаще рывки, ярче свет. */
	public boolean isEnraged() {
		return this.getHealth() < this.getMaxHealth() * 0.5F;
	}

	boolean isNearSeaFloor() {
		BlockPos p = this.blockPosition();
		for (int i = 1; i <= 3; i++) {
			if (!this.level().getFluidState(p.below(i)).is(FluidTags.WATER))
				return true;
		}
		return false;
	}

	// ================================ поведение ================================

	@Override
	public void aiStep() {
		if (!this.level().isClientSide()) {
			if (this.lungeCooldown > 0)
				this.lungeCooldown--;
			if (this.lungeGlide > 0)
				this.lungeGlide--;
			if (this.retreatTicks > 0)
				this.retreatTicks--;

			this.steerBias = Vec3.ZERO;
			this.lureChime();
			this.tryLunge();
			this.glideToTarget();
			this.circleTarget();
			this.applyDarknessAura();
		}
		super.aiStep();
	}

	/** В засаде приманка тихо "звенит" низким колокольчиком - зовёт жертву. */
	private void lureChime() {
		if (this.isLurking() && this.tickCount % 50 == 0)
			this.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.6F, 0.5F + this.random.nextFloat() * 0.1F);
	}

	/** Рывок с распахнутой пастью. Дальность до ~14 блоков, перезарядка короче в ярости. */
	private void tryLunge() {
		LivingEntity target = this.getTarget();
		if (target == null || !target.isAlive() || this.lungeCooldown > 0 || !this.isInWater() || this.isLurking())
			return;
		double distSqr = this.distanceToSqr(target);
		if (distSqr > 9.0D && distSqr < 196.0D && this.hasLineOfSight(target)) {
			Vec3 dir = target.getEyePosition().subtract(this.position()).normalize();
			this.setDeltaMovement(this.getDeltaMovement().add(dir.scale(0.95D)));
			this.lungeGlide = 8;
			this.retreatTicks = 0;
			this.lungeCooldown = (this.isEnraged() ? 22 : 38) + this.random.nextInt(14);
			this.level().broadcastEntityEvent(this, EVENT_LUNGE);
			this.playSound(SoundEvents.GUARDIAN_ATTACK, 1.0F, 0.6F + this.random.nextFloat() * 0.2F);
		}
	}

	/** Во время рывка слегка подруливаем на жертву. */
	private void glideToTarget() {
		LivingEntity target = this.getTarget();
		if (this.lungeGlide > 0 && target != null && this.isInWater()) {
			Vec3 dir = target.getEyePosition().subtract(this.position()).normalize();
			this.setDeltaMovement(this.getDeltaMovement().add(dir.scale(0.08D)));
		}
	}

	/** Между рывками кружит вокруг жертвы, постоянно меняя сторону. */
	private void circleTarget() {
		LivingEntity target = this.getTarget();
		if (target == null || !this.isInWater() || this.isLurking() || this.lungeGlide > 0)
			return;
		double d = this.distanceToSqr(target);
		if (this.lungeCooldown > 0 && d > 6.25D && d < 196.0D) {
			Vec3 rel = target.position().subtract(this.position());
			Vec3 tangent = new Vec3(-rel.z, 0.0D, rel.x).normalize();
			double sign = (((this.tickCount / 70) + this.getId()) & 1) == 0 ? 1.0D : -1.0D;
			this.steerBias = tangent.scale(0.22D * sign);
		}
	}

	/** Тьма: все игроки В ВОДЕ ближе DARKNESS_RADIUS получают Darkness. Приманка при этом светится (emissive-слой). */
	private void applyDarknessAura() {
		if (this.tickCount % 10 != 0)
			return;
		AABB box = this.getBoundingBox().inflate(DARKNESS_RADIUS);
		for (Player p : this.level().getEntitiesOfClass(Player.class, box)) {
			if (p.isSpectator() || p.isCreative())
				continue;
			if (!(p.isInWater() || p.isUnderWater()))
				continue;
			if (this.distanceToSqr(p) > DARKNESS_RADIUS * DARKNESS_RADIUS)
				continue;
			p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, false, false), this);
			if (this.tickCount % 40 == 0)
				this.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 0.9F, 0.9F);
		}
	}

	/** Укус: Darkness дольше + отскок назад (hit & run), после чего почти сразу новый рывок.
	 *  Если сигнатура не сойдётся с вашей версией - удалите метод: остальное работает без него. */
	@Override
	public boolean doHurtTarget(ServerLevel level, Entity target) {
		boolean hit = super.doHurtTarget(level, target);
		if (hit) {
			level.broadcastEntityEvent(this, EVENT_BITE);
			this.playSound(SoundEvents.WARDEN_ATTACK_IMPACT, 0.9F, 1.4F + this.random.nextFloat() * 0.2F);
			if (target instanceof LivingEntity living)
				living.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0, false, false), this);
			Vec3 away = this.position().subtract(target.position());
			if (away.lengthSqr() > 1.0E-4D) {
				this.retreatDir = away.normalize().add(0.0D, 0.15D, 0.0D).normalize();
				this.retreatTicks = this.isEnraged() ? 6 : 10;
				this.lungeCooldown = Math.min(this.lungeCooldown, this.isEnraged() ? 8 : 16);
			}
		}
		return hit;
	}

	// ================================ клиент: анимации ================================

	@Override
	public void handleEntityEvent(byte id) {
		if (id == EVENT_LUNGE)
			this.clientLungeTicks = LUNGE_ANIM_TICKS;
		else if (id == EVENT_BITE)
			this.clientBiteTicks = 7;
		else
			super.handleEntityEvent(id);
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide())
			this.tickClientAnimation();
	}

	private void tickClientAnimation() {
		this.jawOpenO = this.jawOpen;
		this.lurkO = this.lurk;
		this.lungeO = this.lunge;
		this.aggroO = this.aggro;

		this.lurk += ((this.isLurking() ? 1.0F : 0.0F) - this.lurk) * 0.08F;
		float aggroTarget = this.isAggressive() ? (this.isEnraged() ? 1.5F : 1.0F) : 0.0F;
		this.aggro += (aggroTarget - this.aggro) * 0.15F;

		float jawTarget;
		float jawSpeed = 0.3F;
		if (this.clientBiteTicks > 0) { // клац: пасть захлопывается
			jawTarget = 0.0F;
			jawSpeed = 0.7F;
			this.clientBiteTicks--;
		} else if (this.clientLungeTicks > 0) {
			jawTarget = 1.0F;
			jawSpeed = 0.5F;
		} else {
			jawTarget = 0.1F + 0.3F * Math.min(this.aggro, 1.0F) + 0.1F * this.lurk;
		}
		this.jawOpen += (jawTarget - this.jawOpen) * jawSpeed;

		this.lunge += (this.clientLungeTicks / (float) LUNGE_ANIM_TICKS - this.lunge) * 0.4F;
		if (this.clientLungeTicks > 0)
			this.clientLungeTicks--;

		// sculk-души поднимаются от приманки (в засаде гуще)
		if (this.random.nextInt(this.lurk > 0.6F ? 5 : 14) == 0) {
			Vec3 fwd = this.calculateViewVector(0.0F, this.yBodyRot);
			this.level().addParticle(ParticleTypes.SCULK_SOUL,
					this.getX() + fwd.x * 1.0D + (this.random.nextDouble() - 0.5D) * 0.3D,
					this.getY() + 1.1D,
					this.getZ() + fwd.z * 1.0D + (this.random.nextDouble() - 0.5D) * 0.3D,
					0.0D, 0.03D, 0.0D);
		}
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.SCULK_CLICKING;
	}

	/** Реже, чем у обычных мобов, но заметнее: щёлканье sonar'а. */
	@Override
	public int getAmbientSoundInterval() {
		return 70;
	}

	/**
	 * Засада: замереть у дна и ждать. Теперь короче и чаще, а если жертва уже замечена
	 * (но дальше 8 блоков) - засаду выбирает ещё охотнее. Как только жертва ближе 6 блоков - рывок.
	 */
	static class LurkGoal extends Goal {
		private final SculkanglerEntity angler;
		private int timer;

		LurkGoal(SculkanglerEntity angler) {
			this.angler = angler;
			this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
		}

		@Override
		public boolean canUse() {
			if (!this.angler.isInWater() || !this.angler.isNearSeaFloor())
				return false;
			LivingEntity target = this.angler.getTarget();
			if (target != null && this.angler.distanceToSqr(target) < 64.0D)
				return false;
			return this.angler.getRandom().nextInt(reducedTickDelay(target == null ? 260 : 45)) == 0;
		}

		@Override
		public boolean canContinueToUse() {
			LivingEntity target = this.angler.getTarget();
			return this.timer > 0 && this.angler.isInWater() && this.angler.hurtTime == 0
					&& (target == null || this.angler.distanceToSqr(target) > 36.0D);
		}

		@Override
		public void start() {
			this.timer = 40 + this.angler.getRandom().nextInt(80);
			this.angler.getNavigation().stop();
			this.angler.setLurking(true);
		}

		@Override
		public void stop() {
			this.angler.setLurking(false);
		}

		@Override
		public void tick() {
			this.timer--;
			Vec3 dm = this.angler.getDeltaMovement();
			double y = this.angler.onGround() ? 0.0D : Math.min(dm.y, 0.0D) - 0.015D;
			this.angler.setDeltaMovement(dm.x * 0.5D, y, dm.z * 0.5D);
		}
	}

	// ============================ дальше - ваш код ============================

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return SoundEvents.GUARDIAN_HURT;
	}

	@Override
	public SoundEvent getDeathSound() {
		return SoundEvents.GUARDIAN_DEATH;
	}

	@Override
	public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		return false;
	}

	@Override
	public boolean canBreatheUnderwater() {
		return !this.canDrownInFluidType(NeoForgeMod.WATER_TYPE.value());
	}

	@Override
	public boolean isPushedByFluid() {
		return false;
	}

	@Override
	public boolean checkSpawnRules(LevelAccessor level, EntitySpawnReason reason) {
		return this.level().dimension() == Level.OVERWORLD ? super.checkSpawnRules(level, reason) : true;
	}

	/** Натуральный спавн: в воде, глубоко под уровнем моря, и "не всегда" (шанс 1 из 4 на попытку). */
	public static void init(RegisterSpawnPlacementsEvent event) {
		event.register(AquaDominusModEntities.SCULKANGLER.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.OCEAN_FLOOR, (entityType, world, reason, pos, random) -> world.getDifficulty() != Difficulty.PEACEFUL
				&& world.getFluidState(pos).is(FluidTags.WATER)
				&& (EntitySpawnReason.ignoresLightRequirements(reason) || (pos.getY() < world.getSeaLevel() - 10 && random.nextInt(4) == 0)), RegisterSpawnPlacementsEvent.Operation.REPLACE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.38);   // было 0.23
		builder = builder.add(Attributes.MAX_HEALTH, 36);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 6);
		builder = builder.add(Attributes.FOLLOW_RANGE, 40);       // было 24: замечает жертву издалека
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		builder = builder.add(NeoForgeMod.SWIM_SPEED, 1.0);       // было 0.23: именно это делало его вялым в воде
		return builder;
	}
}
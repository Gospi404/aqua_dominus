package com.gospi.aquadominus.event;

import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.nbt.CompoundTag;

import com.gospi.aquadominus.init.AquaDominusModItems;

@EventBusSubscriber(modid = "aqua_dominus")
public final class TetropiaGuideStartingBookEvents {
	private static final String RECEIVED_TAG = "aqua_dominus:received_starting_book_tetropia_guide";

	private TetropiaGuideStartingBookEvents() {
	}

	@SubscribeEvent
	public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
		if (!(event.getEntity() instanceof ServerPlayer player)) {
			return;
		}
		CompoundTag persistentData = player.getPersistentData();
		if (persistentData.getBooleanOr(RECEIVED_TAG, false)) {
			return;
		}
		ItemStack book = new ItemStack(AquaDominusModItems.TETROPIA_GUIDE.get());
		if (!player.getInventory().add(book)) {
			player.drop(book, false);
		}
		persistentData.putBoolean(RECEIVED_TAG, true);
	}

	@SubscribeEvent
	public static void onPlayerClone(PlayerEvent.Clone event) {
		if (event.getOriginal().getPersistentData().getBooleanOr(RECEIVED_TAG, false)) {
			event.getEntity().getPersistentData().putBoolean(RECEIVED_TAG, true);
		}
	}
}
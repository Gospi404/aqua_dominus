package com.gospi.aquadominus.event;

import com.gospi.aquadominus.AquaDominus;
import com.gospi.aquadominus.registry.ModRegistry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

@EventBusSubscriber(modid = AquaDominus.MODID)
public class WeightEvents {
    private static final double SINK_ACCEL = 0.045, MAX_SINK = 0.55;

    /** Высота до тика (клиент и сервер работают с разными объектами сущностей). */
    private static final Map<LivingEntity, Double> PRE_Y =
            Collections.synchronizedMap(new WeakHashMap<>());

    private static boolean weighted(LivingEntity le) {
        if (!le.getItemBySlot(EquipmentSlot.FEET).is(ModRegistry.ANKLE_WEIGHT)) return false;
        return !(le instanceof Player p && p.getAbilities().flying);
    }

    @SubscribeEvent
    public static void onPre(EntityTickEvent.Pre e) {
        if (!(e.getEntity() instanceof LivingEntity le)) return;
        if (weighted(le) && le.isInWater()) PRE_Y.put(le, le.getY());
        else PRE_Y.remove(le);
    }

    @SubscribeEvent
    public static void onPost(EntityTickEvent.Post e) {
        if (!(e.getEntity() instanceof LivingEntity le)) return;
        Double preY = PRE_Y.remove(le);
        if (preY == null || !weighted(le) || !le.isInWater()) return;

        // 1. Не даём подняться выше, чем были (кроме ходьбы по дну / ступенек)
        if (!le.onGround() && le.getY() > preY) {
            le.setPos(le.getX(), preY, le.getZ());
        }

        // 2. Тонем всё быстрее, импульс вверх гасится
        Vec3 v = le.getDeltaMovement();
        double y = Math.max(Math.min(v.y, 0.0) - SINK_ACCEL, -MAX_SINK);
        le.setDeltaMovement(v.x * 0.85, y, v.z * 0.85);
        le.setSwimming(false);

        // 3. Воздух кончается вдвое быстрее
        if (le.isEyeInFluid(FluidTags.WATER) && !le.level().isClientSide())
            le.setAirSupply(le.getAirSupply() - 1);

        if (le.level().isClientSide() && le.tickCount % 6 == 0)
            le.level().addParticle(ParticleTypes.BUBBLE, le.getX(), le.getY() + 0.2, le.getZ(), 0, 0.1, 0);
    }
}
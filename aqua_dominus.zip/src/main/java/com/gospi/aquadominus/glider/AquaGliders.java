package com.gospi.aquadominus.glider;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.RegisterEvent;

@EventBusSubscriber(modid = AquaGliders.MODID)
public class AquaGliders {
    public static final String MODID = "aqua_dominus";
    public static final Identifier GLIDER_ID = Identifier.fromNamespaceAndPath(MODID, "water_glider");

    public static final ResourceKey<EntityType<?>> ENTITY_KEY = ResourceKey.create(Registries.ENTITY_TYPE, GLIDER_ID);
    public static final ResourceKey<Item> ITEM_KEY = ResourceKey.create(Registries.ITEM, GLIDER_ID);
    public static final ResourceKey<Enchantment> LAVA_WALKER =
            ResourceKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath(MODID, "lava_walker"));
    public static final ResourceKey<Enchantment> SWIFT_GLIDE =
        	ResourceKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath(MODID, "swift_glide"));
	public static final ResourceKey<Enchantment> RAMMING =
        	ResourceKey.create(Registries.ENCHANTMENT, Identifier.fromNamespaceAndPath(MODID, "ramming"));

    public static EntityType<GliderEntity> GLIDER_ENTITY;
    public static Item GLIDER_ITEM;

    @SubscribeEvent
    public static void onRegister(RegisterEvent event) {
        event.register(Registries.ENTITY_TYPE, helper -> {
            GLIDER_ENTITY = EntityType.Builder.<GliderEntity>of(GliderEntity::new, MobCategory.MISC)
                    .sized(1.5f, 0.2f)
                    .passengerAttachments(0.73f)
                    .clientTrackingRange(10)
                    .build(ENTITY_KEY);
            helper.register(ENTITY_KEY, GLIDER_ENTITY);
        });
        event.register(Registries.ITEM, helper -> {
            GLIDER_ITEM = new GliderItem(new Item.Properties()
                    .setId(ITEM_KEY).durability(3).enchantable(10).fireResistant());
            helper.register(ITEM_KEY, GLIDER_ITEM);
        });
    }

    // Вкладка «Инструменты»
    @SubscribeEvent
    public static void onTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(GLIDER_ITEM);
        }
    }

    public static boolean hasLavaWalker(Level level, ItemStack stack) {
        return level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(LAVA_WALKER)
                .map(h -> EnchantmentHelper.getItemEnchantmentLevel(h, stack) > 0).orElse(false);
    }
    public static int enchantLevel(Level level, ItemStack stack, ResourceKey<Enchantment> key) {
    return level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).get(key)
            .map(h -> EnchantmentHelper.getItemEnchantmentLevel(h, stack)).orElse(0);
	}

    @SubscribeEvent
    public static void onAnvil(AnvilUpdateEvent e) {
        ItemStack left = e.getLeft(), right = e.getRight();
        if (left.is(GLIDER_ITEM) && right.is(Items.NAUTILUS_SHELL) && left.getDamageValue() > 0) {
            ItemStack out = left.copy();
            out.setDamageValue(left.getDamageValue() - 1);
            e.setOutput(out);
            e.setXpCost(1);
            e.setMaterialCost(1);
        }
    }
}
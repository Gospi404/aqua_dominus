package com.gospi.aquadominus.glider;

import java.util.List;

import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

public class GliderEntity extends Entity {
    private static final EntityDataAccessor<ItemStack> DATA_STACK =
            SynchedEntityData.defineId(GliderEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final Identifier LAVA_ADVANCEMENT =
            Identifier.fromNamespaceAndPath("aqua_dominus", "lava_glider");

    private static final double ACCEL = 0.05;
    private static final double SPRINT_MULT = 1.5;       // рывок на Ctrl
    private static final double SWIFT_PER_LEVEL = 0.15;  // Быстрый ход: +15% за уровень
    private static final double FRICTION = 0.92;
    private static final int WEAR_INTERVAL = 20 * 90;    // секунд движения на одну ступень износа

    private static final double JUMP_VY = 0.38;          // сила прыжка
    private static final int JUMP_COOLDOWN = 20;         // перезарядка прыжка, тиков
    private static final int TRICK_MIN_AIR = 14;         // сколько тиков в воздухе для «трюка»
    private static final double TRICK_BOOST = 1.25;      // ускорение за трюк

    private double lastSpeed;
    private int impactCooldown;
    private int wearTicks;

    private double prevX, prevY, prevZ;
    private boolean hasPrev;

    private boolean airborne;
    private int airTicks;
    private int jumpCooldown;
    private boolean jumpRequested;

    // Поля для рендерера
    public boolean lavaMode;
    public float visRoll, visRollO, visPitch, visPitchO, visFlip, visFlipO;

    public GliderEntity(EntityType<?> type, Level level) { super(type, level); }

    @Override protected void defineSynchedData(SynchedEntityData.Builder b) { b.define(DATA_STACK, ItemStack.EMPTY); }
    public ItemStack getStack() { return entityData.get(DATA_STACK); }
    public void setStack(ItemStack s) { entityData.set(DATA_STACK, s); }
    public boolean isBroken() { return getStack().getDamageValue() >= 2; }

    // Вызывается клиентом, когда игрок зажал пробел
    public void requestJump() { this.jumpRequested = true; }

    @Override public boolean fireImmune() { return true; }
    @Override public boolean isPushedByFluid() { return false; }
    @Override public boolean isPickable() { return true; }
    @Override public boolean shouldRiderSit() { return false; }
    @Override public boolean canSprint() { return true; }
    @Override protected boolean canAddPassenger(Entity p) { return getPassengers().isEmpty(); }
    @Override public LivingEntity getControllingPassenger() {
        return getFirstPassenger() instanceof LivingEntity le ? le : null;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand, Vec3 loc) {
        // Shift + ПКМ: забрать глайдер в инвентарь
        if (player.isSecondaryUseActive()) {
            if (!getPassengers().isEmpty()) return InteractionResult.PASS;
            if (!level().isClientSide()) {
                if (!player.hasInfiniteMaterials()) {
                    ItemStack back = getStack().copy();
                    if (!player.getInventory().add(back)) spawnAtLocation((ServerLevel) level(), back);
                }
                level().playSound(null, getX(), getY(), getZ(),
                        SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.4f, 1.2f);
                discard();
            }
            return InteractionResult.SUCCESS;
        }
        if (!level().isClientSide()) {
            player.startRiding(this);
            level().playSound(null, getX(), getY(), getZ(),
                    SoundEvents.GENERIC_SPLASH, SoundSource.NEUTRAL, 0.6f, 1.2f);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean hurtServer(ServerLevel level, DamageSource src, float amount) {
        if (src.getEntity() instanceof Player) {
            spawnAtLocation(level, getStack());
            discard();
            return true;
        }
        return false;
    }

	@Override
	protected void removePassenger(Entity passenger) {
    	super.removePassenger(passenger);
    	passenger.resetFallDistance();
	}

    private boolean canRide(FluidState fs, boolean lava) {
        return fs.is(FluidTags.WATER) || (lava && fs.is(FluidTags.LAVA));
    }

    private double findSurface(boolean lava) {
        BlockPos base = BlockPos.containing(getX(), getY() + 0.3, getZ());
        for (int i = 0; i < 3; i++) {
            BlockPos p = base.below(i);
            FluidState fs = level().getFluidState(p);
            if (canRide(fs, lava) && level().getFluidState(p.above()).isEmpty())
                return p.getY() + fs.getHeight(level(), p);
        }
        return Double.NaN;
    }

    @Override
    public void tick() {
        super.tick();
        if (impactCooldown > 0) impactCooldown--;
        if (jumpCooldown > 0) jumpCooldown--;

        // Скорость и вертикальное смещение по собственной прошлой позиции
        double dx = hasPrev ? getX() - prevX : 0.0;
        double dy = hasPrev ? getY() - prevY : 0.0;
        double dz = hasPrev ? getZ() - prevZ : 0.0;
        double speed = Math.hypot(dx, dz);
        prevX = getX();
        prevY = getY();
        prevZ = getZ();
        hasPrev = true;

        ItemStack stack = getStack();
        boolean lava = AquaGliders.hasLavaWalker(level(), stack);
        int swift = AquaGliders.enchantLevel(level(), stack, AquaGliders.SWIFT_GLIDE);
        int ram = AquaGliders.enchantLevel(level(), stack, AquaGliders.RAMMING);
        lavaMode = lava;

        double surf = findSurface(lava);
        boolean surfFound = !Double.isNaN(surf);
        LivingEntity driver = getControllingPassenger();
        boolean controlled = driver != null && !isBroken();
        boolean sprint = controlled && driver.isSprinting();
        Vec3 v = getDeltaMovement();
        // Без урона от падения для глайдера и водителя
		resetFallDistance();
		if (driver != null) driver.resetFallDistance();

        // Состояние «в воздухе». На сервере узнаём его по высоте над водой
        if (surfFound && !airborne && getY() - surf > 0.4) airborne = true;
        boolean landed = false;
        int flight = 0;
        if (airborne) {
            airTicks++;
            if (surfFound && airTicks > 3 && dy <= 0 && getY() - surf <= 0.3) {
                airborne = false;
                landed = true;
                flight = airTicks;
                airTicks = 0;
            } else if (!surfFound && onGround()) {
                airborne = false;
                airTicks = 0;
            }
        }
        boolean surfaceMode = surfFound && !airborne;

        // Защита водителя от огня на лаве
        if (!level().isClientSide() && lava && surfaceMode && driver != null) {
            driver.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, false, false));
            driver.clearFire();
        }

        // Вертикаль: плывем по поверхности или летим под гравитацией
        double vy = surfaceMode ? ((surf + (lava ? 0.1 : 0.0)) - getY()) * 0.4 : v.y - 0.04;

        // Прыжок (только на клиенте водителя, там и считается движение)
        if (jumpRequested) {
            jumpRequested = false;
            if (isLocalInstanceAuthoritative() && surfaceMode && controlled && jumpCooldown == 0) {
                vy = JUMP_VY;
                airborne = true;
                airTicks = 0;
                jumpCooldown = JUMP_COOLDOWN;
                surfaceMode = false;
            }
        }

        double vx = v.x, vz = v.z;
        if (controlled && (surfaceMode || airborne)) {
            setYRot(driver.getYRot());
            double rad = Math.toRadians(getYRot());
            float forward = driver.zza;
            double accel = ACCEL * (1.0 + SWIFT_PER_LEVEL * swift)
                    * (sprint ? SPRINT_MULT : 1.0)
                    * (surfaceMode ? 1.0 : 0.25);
            vx += -Math.sin(rad) * accel * forward;
            vz += Math.cos(rad) * accel * forward;
            double fr = surfaceMode ? FRICTION : 0.985;
            vx *= fr;
            vz *= fr;
        } else {
            vx *= 0.5;
            vz *= 0.5;
        }

        // Бонус за трюк
        if (landed && flight >= TRICK_MIN_AIR && isLocalInstanceAuthoritative()) {
            vx *= TRICK_BOOST;
            vz *= TRICK_BOOST;
        }

        setDeltaMovement(vx, vy, vz);

        if (isLocalInstanceAuthoritative()) move(MoverType.SELF, getDeltaMovement());
        else setDeltaMovement(Vec3.ZERO);

        updateTilt(speed, sprint);

        if (!level().isClientSide()) {
            if (landed) landingEffects(lava, surf, flight, driver);
            serverImpactCheck(driver, speed, ram);
            serverWear(driver, surfaceMode, speed, sprint);
            if (lava && surfaceMode && driver != null && tickCount % 20 == 0) awardLavaAdvancement(driver);
        }

        effects(lava, surfaceMode, sprint, speed);
    }

    // Наклон модели и сальто
    private void updateTilt(double speed, boolean sprint) {
        visRollO = visRoll;
        visPitchO = visPitch;
        visFlipO = visFlip;
        float turn = Mth.wrapDegrees(getYRot() - yRotO);
        float targetRoll = speed > 0.05 ? Mth.clamp(-turn * 1.5F, -18.0F, 18.0F) : 0.0F;
        float targetPitch = Mth.clamp((float) (speed * 25.0), 0.0F, 7.0F);
        if (sprint && speed > 0.05) targetPitch += 3.0F;
        visRoll += (targetRoll - visRoll) * 0.25F;
        visPitch += (targetPitch - visPitch) * 0.25F;
        visFlip = (airborne && airTicks >= 3) ? Math.min(360.0F, (airTicks - 3) * 24.0F) : 0.0F;
        if (visFlip == 0.0F) visFlipO = 0.0F;
    }

    // Приводнение: брызги, звук, сообщение о трюке
    private void landingEffects(boolean lava, double surf, int flight, LivingEntity driver) {
        ServerLevel sl = (ServerLevel) level();
        int n = Math.min(40, 10 + flight * 2);
        if (lava) {
            sl.sendParticles(ParticleTypes.LAVA, getX(), surf + 0.15, getZ(), n / 2, 0.7, 0.1, 0.7, 0.2);
            sl.sendParticles(ParticleTypes.FLAME, getX(), surf + 0.15, getZ(), n, 0.7, 0.1, 0.7, 0.1);
        } else {
            sl.sendParticles(ParticleTypes.SPLASH, getX(), surf + 0.15, getZ(), n * 2, 0.7, 0.1, 0.7, 0.3);
            sl.sendParticles(ParticleTypes.FISHING, getX(), surf + 0.1, getZ(), n, 0.7, 0.05, 0.7, 0.1);
        }
        level().playSound(null, getX(), getY(), getZ(),
                lava ? SoundEvents.LAVA_POP : SoundEvents.GENERIC_SPLASH,
                SoundSource.NEUTRAL, 1.0f, 0.9f);

        if (flight >= TRICK_MIN_AIR && driver instanceof ServerPlayer sp) {
            sp.connection.send(
    			new net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket(
        		Component.translatable("message.aqua_dominus.glider.trick")
    			)
			);
            level().playSound(null, getX(), getY(), getZ(),
                    SoundEvents.PLAYER_LEVELUP, SoundSource.NEUTRAL, 0.5f, 1.5f);
        }
    }

    // Износ за движение
    private void serverWear(LivingEntity driver, boolean surfaceMode, double speed, boolean sprint) {
        if (driver != null && surfaceMode && !isBroken() && speed > 0.08) {
            wearTicks += sprint ? 2 : 1;
            if (wearTicks >= WEAR_INTERVAL) {
                wearTicks = 0;
                damageGlider();
            }
        }
    }

    private void awardLavaAdvancement(LivingEntity driver) {
        if (!(driver instanceof ServerPlayer sp) || !(level() instanceof ServerLevel sl)) return;
        AdvancementHolder holder = sl.getServer().getAdvancements().get(LAVA_ADVANCEMENT);
        if (holder != null) sp.getAdvancements().award(holder, "ride");
    }

    private void effects(boolean lava, boolean surfaceMode, boolean sprint, double speed) {
        if (!surfaceMode || speed < 0.08) return;

        if (level().isClientSide()) {
            double rad = Math.toRadians(getYRot());
            double fx = -Math.sin(rad), fz = Math.cos(rad);
            double sx = Math.cos(rad), sz = Math.sin(rad);
            double px = getX() - fx * 0.8;
            double pz = getZ() - fz * 0.8;
            int count = sprint ? 4 : 2;

            for (int i = 0; i < count; i++) {
                double side = random.nextBoolean() ? 1.0 : -1.0;
                double off = 0.25 + random.nextDouble() * 0.25;
                double x = px + sx * side * off;
                double z = pz + sz * side * off;
                double vxp = sx * side * 0.08 - fx * 0.05;
                double vzp = sz * side * 0.08 - fz * 0.05;

                if (lava) {
                    level().addParticle(ParticleTypes.FLAME, x, getY() + 0.1, z, vxp * 0.3, 0.05, vzp * 0.3);
                    level().addParticle(ParticleTypes.SMOKE, x, getY() + 0.15, z, 0, 0.03, 0);
                    if (random.nextInt(3) == 0)
                        level().addParticle(ParticleTypes.LAVA, x, getY() + 0.1, z, 0, 0, 0);
                } else {
                    level().addParticle(ParticleTypes.SPLASH, x, getY() + 0.1, z, vxp, 0.1, vzp);
                    level().addParticle(ParticleTypes.FISHING, x, getY() + 0.05, z, vxp, 0, vzp);
                }
            }
        } else if (tickCount % 8 == 0) {
            level().playSound(null, getX(), getY(), getZ(),
                    lava ? SoundEvents.LAVA_AMBIENT : SoundEvents.GENERIC_SPLASH,
                    SoundSource.NEUTRAL, 0.25f, 1.0f);
        }
    }

    private void serverImpactCheck(LivingEntity driver, double speed, int ram) {
        if (driver != null && !isBroken() && impactCooldown == 0 && !airborne) {
            boolean hitBlock = lastSpeed > 0.15 && speed < lastSpeed * 0.4;
            List<LivingEntity> hit = speed > 0.1
                    ? level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(0.15),
                            e -> e != driver && e.isAlive())
                    : List.of();
            boolean hitMob = !hit.isEmpty();

            if (hitBlock || hitMob) {
                impactCooldown = 20;
                if (ram > 0 && hitMob) ramTargets(hit, driver, ram);
                // С Тараном при ударе по мобу глайдер портится реже
                int bound = (ram > 0 && hitMob && !hitBlock) ? 4 : 2;
                if (random.nextInt(bound) == 0) damageGlider();
            }
        }
        lastSpeed = speed;
    }

    // Таран: урон и отбрасывание
    private void ramTargets(List<LivingEntity> targets, LivingEntity driver, int ram) {
        ServerLevel sl = (ServerLevel) level();
        DamageSource src = driver instanceof Player p
                ? sl.damageSources().playerAttack(p)
                : sl.damageSources().mobAttack(driver);
        for (LivingEntity t : targets) {
            t.hurtServer(sl, src, 2.0f + 2.0f * ram);
            t.knockback(0.6 + 0.3 * ram, getX() - t.getX(), getZ() - t.getZ());
        }
        sl.playSound(null, getX(), getY(), getZ(),
                SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.NEUTRAL, 1.0f, 1.0f);
    }

    private void damageGlider() {
        ItemStack s = getStack().copy();
        int amount = EnchantmentHelper.processDurabilityChange((ServerLevel) level(), s, 1);
        if (amount > 0) {
            s.setDamageValue(Math.min(2, s.getDamageValue() + amount));
            setStack(s);
            boolean broken = s.getDamageValue() >= 2;
            level().playSound(null, getX(), getY(), getZ(),
                    broken ? SoundEvents.SHIELD_BREAK : SoundEvents.SHIELD_BLOCK,
                    SoundSource.NEUTRAL, 0.8f, 1.0f);

            ServerLevel sl = (ServerLevel) level();
            if (broken) {
                sl.sendParticles(ParticleTypes.POOF, getX(), getY() + 0.2, getZ(), 20, 0.5, 0.1, 0.5, 0.05);
                sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 0.2, getZ(), 15, 0.5, 0.1, 0.5, 0.02);
            } else {
                sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + 0.2, getZ(), 12, 0.5, 0.1, 0.5, 0.2);
            }
        }
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        in.read("Glider", ItemStack.CODEC).ifPresent(this::setStack);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        out.store("Glider", ItemStack.CODEC, getStack());
    }
}
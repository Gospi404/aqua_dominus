package com.gospi.aquadominus.glider;

import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

public class GliderItem extends Item {
    public GliderItem(Properties p) { super(p); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.ANY);
        if (hit.getType() == HitResult.Type.MISS) return InteractionResult.PASS;

        FluidState fs = level.getFluidState(hit.getBlockPos());
        boolean ok = fs.is(FluidTags.WATER)
                || (fs.is(FluidTags.LAVA) && AquaGliders.hasLavaWalker(level, stack));
        if (!ok) return InteractionResult.PASS;

        if (!level.isClientSide()) {
            GliderEntity e = new GliderEntity(AquaGliders.GLIDER_ENTITY, level);
            e.setPos(hit.getLocation());
            e.setYRot(player.getYRot());
            e.setStack(stack.copyWithCount(1));
            level.addFreshEntity(e);
            if (!player.hasInfiniteMaterials()) stack.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, TooltipDisplay display,
                                Consumer<Component> lines, TooltipFlag flag) {
        int d = stack.getDamageValue();
        String key = d >= 2 ? "broken" : d == 1 ? "damaged" : "good";
        ChatFormatting color = d >= 2 ? ChatFormatting.RED : d == 1 ? ChatFormatting.YELLOW : ChatFormatting.GREEN;
        lines.accept(Component.translatable("tooltip.aqua_dominus.glider.state." + key).withStyle(color));
        lines.accept(Component.translatable("tooltip.aqua_dominus.glider.repair").withStyle(ChatFormatting.GRAY));
    }
}
package com.gospi.aquadominus.glider;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.minecraft.util.ARGB;

class GliderRenderState extends EntityRenderState {
    public int damage;
    public float yaw;
    public float roll;
    public float pitch;
    public float flip;
    public boolean lava;
    public boolean foil;
}

public class GliderRenderer extends EntityRenderer<GliderEntity, GliderRenderState> {
    private static final Identifier[] TEXTURES = {
            Identifier.fromNamespaceAndPath("aqua_dominus", "textures/entities/glider.png"),
            Identifier.fromNamespaceAndPath("aqua_dominus", "textures/entities/glider_damaged.png"),
            Identifier.fromNamespaceAndPath("aqua_dominus", "textures/entities/glider_broken.png")
    };
    private static final int FULL_BRIGHT = 15728880;

    private final GliderModel model;

    public GliderRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.model = new GliderModel(ctx.bakeLayer(GliderModel.LAYER));
    }

    @Override
    public GliderRenderState createRenderState() {
        return new GliderRenderState();
    }

    @Override
    public void extractRenderState(GliderEntity entity, GliderRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        state.damage = Math.max(0, Math.min(2, entity.getStack().getDamageValue()));
        state.yaw = Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot());
        state.roll = Mth.lerp(partialTick, entity.visRollO, entity.visRoll);
        state.pitch = Mth.lerp(partialTick, entity.visPitchO, entity.visPitch);
        state.flip = Mth.lerp(partialTick, entity.visFlipO, entity.visFlip);
        state.lava = entity.lavaMode;
        state.foil = entity.getStack().hasFoil();
        if (state.lava) state.lightCoords = FULL_BRIGHT;
    }

    @Override
		public void submit(GliderRenderState state, PoseStack pose, SubmitNodeCollector collector, CameraRenderState camera) {
    		pose.pushPose();
    		float bob = Mth.sin(state.ageInTicks * 0.25F) * 0.015F;
    		pose.translate(0.0F, bob, 0.0F);
    		pose.mulPose(Axis.YP.rotationDegrees(180.0F - state.yaw));
    		pose.mulPose(Axis.XP.rotationDegrees(state.pitch + state.flip));
    		pose.mulPose(Axis.ZP.rotationDegrees(state.roll));
    		pose.scale(-1.0F, -1.0F, 1.0F);
    		pose.translate(0.0F, -1.501F, 0.0F);

    		collector.submitModel(model, state, pose,
            	model.renderType(TEXTURES[state.damage]),
            	state.lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor, null);

    	// Блеск зачарования: отдельный слой, который рисуется после основной модели
    	if (state.foil) {
    		float pulse = 0.5F + 0.5F * Mth.sin(state.ageInTicks * 0.12F);
    		int alpha = (int) (50 + 70 * pulse);
    		int tint = ARGB.color(alpha, 150, 90, 255);
    		collector.order(1).submitModel(model, state, pose,
            		RenderTypes.eyes(TEXTURES[state.damage]),
            		FULL_BRIGHT, OverlayTexture.NO_OVERLAY, tint, null, state.outlineColor, null);
		}

    	pose.popPose();
    	super.submit(state, pose, collector, camera);
	}
}

@EventBusSubscriber(modid = "aqua_dominus", value = Dist.CLIENT)
class AquaGlidersClient {
    @SubscribeEvent
    static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(GliderModel.LAYER, GliderModel::createBodyLayer);
    }

    @SubscribeEvent
    static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(AquaGliders.GLIDER_ENTITY, GliderRenderer::new);
    }

    // Пробел на глайдере = прыжок
    @SubscribeEvent
    static void clientTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        if (mc.player.getVehicle() instanceof GliderEntity g && mc.options.keyJump.isDown()) {
            g.requestJump();
        }
    }
}
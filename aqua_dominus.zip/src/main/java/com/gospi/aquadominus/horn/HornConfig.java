package com.gospi.aquadominus.horn;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.gospi.aquadominus.beacon.BeaconConfig;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * config/aqua_dominus-horns.toml
 * Предметы: "minecraft:nautilus_shell=2"; эффекты: "minecraft:regeneration;0" (id;уровень, 0 = I)
 */
public final class HornConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<List<? extends String>> BIOMES;
    public static final ModConfigSpec.IntValue RITUAL_RADIUS;

    public record Horn(ModConfigSpec.ConfigValue<List<? extends String>> offerings, ModConfigSpec.IntValue cooldownSeconds) {}
    public static final Map<HornKind, Horn> HORNS = new EnumMap<>(HornKind.class);

    // Рог глубин (босс)
    public static final ModConfigSpec.DoubleValue BOSS_HEALTH_MULT;
    public static final ModConfigSpec.DoubleValue BOSS_HEALTH_PER_EXTRA_PLAYER;
    public static final ModConfigSpec.IntValue BOSS_ESCORTS;
    public static final ModConfigSpec.IntValue BOSS_XP;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> BOSS_REWARDS;

    // Рог приливов (дух)
    public static final ModConfigSpec.IntValue SPIRIT_SECONDS;
    public static final ModConfigSpec.IntValue SPIRIT_RADIUS;
    public static final ModConfigSpec.BooleanValue SPIRIT_STORM;
    public static final ModConfigSpec.ConfigValue<List<? extends String>> SPIRIT_EFFECTS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Общее").push("general");
        BIOMES = b.comment("Биомы, где рога работают")
                .defineListAllowEmpty("biomes", List.of("minecraft:cold_ocean", "minecraft:deep_cold_ocean"),
                        () -> "minecraft:cold_ocean", o -> o instanceof String);
        RITUAL_RADIUS = b.comment("Подношения должны плавать в воде в этом радиусе от игрока")
                .defineInRange("ritualRadius", 8, 2, 32);
        b.pop();

        for (HornKind k : HornKind.values()) {
            b.comment("Ритуал: " + k.configName()).push(k.configName());
            List<String> def = k == HornKind.ABYSS
                    ? List.of("minecraft:nautilus_shell=2", "minecraft:prismarine_shard=16", "minecraft:ink_sac=8")
                    : List.of("minecraft:prismarine_crystals=16", "minecraft:kelp=32", "minecraft:sea_pickle=8");
            HORNS.put(k, new Horn(
                    b.comment("Подношения: бросить в воду рядом, затем протрубить")
                            .defineListAllowEmpty("offerings", def, () -> "minecraft:iron_ingot=1",
                                    o -> o instanceof String s && s.contains("=")),
                    b.defineInRange("cooldownSeconds", k == HornKind.ABYSS ? 300 : 600, 0, 86400)));
            b.pop();
        }

        b.comment("Рог глубин: морской страж").push("abyss_boss");
        BOSS_HEALTH_MULT = b.comment("Множитель здоровья (у старшего стража 80 HP)")
                .defineInRange("healthMultiplier", 2.0, 0.5, 20.0);
        BOSS_HEALTH_PER_EXTRA_PLAYER = b.comment("Прибавка к множителю за каждого игрока сверх первого")
                .defineInRange("healthPerExtraPlayer", 0.5, 0.0, 10.0);
        BOSS_ESCORTS = b.comment("Обычных стражей в свите").defineInRange("escorts", 4, 0, 20);
        BOSS_XP = b.defineInRange("rewardXp", 500, 0, 100000);
        BOSS_REWARDS = b.comment("Награда каждому участнику рядом")
                .defineListAllowEmpty("rewards", List.of("minecraft:heart_of_the_sea=1", "minecraft:prismarine_crystals=16",
                        "minecraft:diamond=3"), () -> "minecraft:diamond=1", o -> o instanceof String s && s.contains("="));
        b.pop();

        b.comment("Рог приливов: дух моря").push("tide_spirit");
        SPIRIT_SECONDS = b.defineInRange("durationSeconds", 180, 10, 3600);
        SPIRIT_RADIUS = b.comment("Радиус действия баффов вокруг духа").defineInRange("radius", 32, 4, 128);
        SPIRIT_STORM = b.comment("Вызывать грозу на время визита духа").define("storm", true);
        SPIRIT_EFFECTS = b.defineListAllowEmpty("effects",
                List.of("minecraft:dolphins_grace;0", "minecraft:conduit_power;0", "minecraft:regeneration;0",
                        "minecraft:water_breathing;0"),
                () -> "minecraft:regeneration;0", o -> o instanceof String s && s.split(";").length == 2);
        b.pop();

        SPEC = b.build();
    }

    public static List<BeaconConfig.ItemReq> items(List<? extends String> raw) {
        List<BeaconConfig.ItemReq> out = new ArrayList<>();
        for (String s : raw) {
            String[] p = s.split("=");
            var it = BeaconConfig.item(p[0].trim());
            if (it.isEmpty()) continue;
            try {
                out.add(new BeaconConfig.ItemReq(it.get(), Math.max(1, Integer.parseInt(p[1].trim()))));
            } catch (NumberFormatException ignored) {}
        }
        return out;
    }

    public static List<BeaconConfig.ItemReq> offerings(HornKind k) { return items(HORNS.get(k).offerings().get()); }
    public static List<BeaconConfig.ItemReq> bossRewards() { return items(BOSS_REWARDS.get()); }

    private HornConfig() {}
}

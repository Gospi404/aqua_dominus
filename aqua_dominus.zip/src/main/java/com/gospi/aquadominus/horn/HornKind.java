package com.gospi.aquadominus.horn;

public enum HornKind {
    /** Рог глубин: поднимает морского стража (босс). */
    ABYSS("abyss_horn"),
    /** Рог приливов: шторм и дружелюбный дух моря с баффами. */
    TIDE("tide_horn");

    private final String id;

    HornKind(String id) { this.id = id; }

    public String id() { return id; }
    public String configName() { return name().toLowerCase(java.util.Locale.ROOT); }
}

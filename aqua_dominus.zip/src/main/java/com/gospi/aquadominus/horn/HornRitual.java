package com.gospi.aquadominus.horn;

import java.util.ArrayList;
import java.util.List;

import com.gospi.aquadominus.beacon.BeaconConfig;
import com.gospi.aquadominus.beacon.ModRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;

public final class HornRitual {

    public static boolean inRightBiome(Level level, Player player) {
        Holder<Biome> biome = level.getBiome(player.blockPosition());
        for (String s : HornConfig.BIOMES.get()) {
            Identifier id = Identifier.tryParse(s);
            if (id != null && biome.is(id)) return true;
        }
        return false;
    }

    private record Plan(List<ItemEntity> entities, List<BeaconConfig.ItemReq> reqs) {}

    private static void tell(ServerPlayer p, String key, Object... args) {
        p.sendSystemMessage(Component.translatable("msg.aqua_dominus." + key, args));
    }

    /** Вызывается, когда игрок дотрубил в рог (сервер). */
    public static void perform(ServerLevel sl, ServerPlayer player, HornKind kind, ItemStack stack) {
        // 1. Ритуал: подношения должны плавать в воде рядом
        List<BeaconConfig.ItemReq> reqs = HornConfig.offerings(kind);
        List<ItemEntity> ents = sl.getEntitiesOfClass(ItemEntity.class,
                player.getBoundingBox().inflate(HornConfig.RITUAL_RADIUS.get()), ItemEntity::isInWater);
        MutableComponent missing = Component.empty();
        boolean ok = true;
        for (BeaconConfig.ItemReq r : reqs) {
            int have = 0;
            for (ItemEntity ie : ents) if (ie.getItem().is(r.item())) have += ie.getItem().getCount();
            if (have < r.count()) {
                ok = false;
                missing.append(Component.literal("\n - " + (r.count() - have) + "x ")
                        .append(new ItemStack(r.item()).getHoverName()));
            }
        }
        // гул рога слышен в любом случае
        horn(sl, player.blockPosition(), 1.0f);
        if (!ok) {
            tell(player, "horn_missing", missing);
            return;
        }

        // 2. Эффект
        boolean done = kind == HornKind.ABYSS ? SeaEvents.summonBoss(sl, player) : SeaEvents.summonSpirit(sl, player);
        if (!done) {
            tell(player, "horn_failed");
            return;
        }

        // 3. Только после успеха забираем подношения и ставим перезарядку
        consume(new Plan(ents, reqs));
        int cd = HornConfig.HORNS.get(kind).cooldownSeconds().get() * 20;
        if (cd > 0) player.getCooldowns().addCooldown(stack, cd);
    }

    private static void consume(Plan plan) {
        for (BeaconConfig.ItemReq r : plan.reqs()) {
            int left = r.count();
            for (ItemEntity ie : plan.entities()) {
                if (left <= 0) break;
                ItemStack s = ie.getItem().copy();
                if (!s.is(r.item())) continue;
                int d = Math.min(left, s.getCount());
                s.shrink(d);
                left -= d;
                if (s.isEmpty()) ie.discard(); else ie.setItem(s);
            }
        }
    }

    // ================= общие помощники =================

    public static void horn(ServerLevel sl, BlockPos pos, float volume) {
        sl.playSound(null, pos, SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.PLAYERS, 3f * volume, 0.5f);
        sl.playSound(null, pos, SoundEvents.NOTE_BLOCK_BASS.value(), SoundSource.PLAYERS, 3f * volume, 0.7f);
        sl.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 2f * volume, 0.5f);
        sl.sendParticles(ParticleTypes.BUBBLE_POP, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5,
                30, 2.5, 0.5, 2.5, 0.05);
    }

    public static boolean water(ServerLevel sl, BlockPos p) {
        return sl.getFluidState(p).is(FluidTags.WATER);
    }

    /** Ищет воду на расстоянии dist от center. deep = точка на дне (до 15 блоков вниз), иначе у поверхности. */
    public static BlockPos waterSpot(ServerLevel sl, BlockPos center, int dist, boolean deep) {
        RandomSource r = sl.getRandom();
        for (int i = 0; i < 12; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            BlockPos top = new BlockPos(center.getX() + (int) (Math.cos(a) * dist), center.getY(),
                    center.getZ() + (int) (Math.sin(a) * dist));
            if (!water(sl, top)) continue;
            if (!deep) return top;
            BlockPos p = top;
            int depth = 0;
            while (depth < 15 && water(sl, p.below())) {
                p = p.below();
                depth++;
            }
            return p.above(Math.min(2, depth));
        }
        return null;
    }

    /** Умножает максимальное здоровье и лечит до полного. */
    public static void scaleHealth(LivingEntity le, double mult) {
        AttributeInstance hp = le.getAttribute(Attributes.MAX_HEALTH);
        if (hp != null) {
            hp.setBaseValue(hp.getBaseValue() * mult);
            le.setHealth(le.getMaxHealth());
        }
    }

    private HornRitual() {}
}

package com.gospi.aquadominus.horn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import com.gospi.aquadominus.beacon.BeaconConfig;
import com.gospi.aquadominus.beacon.ModRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Всё, что происходит после гудка: босс Giant Squid и дух моря. Состояние в памяти, сущности помечены. */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class SeaEvents {
    /** Id вашего босса в реестре сущностей мода (если у него другое имя — поменяйте здесь). */
    private static final String BOSS_ID = "giant_squid";
    /** Тег, которым помечается босс, вызванный рогом. Сохраняется вместе с сущностью. */
    private static final String BOSS_TAG = "aqd_horn_boss";

    // Дух опознаётся по ключу перевода его имени (он сохраняется вместе с сущностью)
    private static final String KEY_SPIRIT = "entity.aqua_dominus.sea_spirit";

    private static boolean hasNameKey(Entity e, String key) {
        Component name = e.getCustomName();
        return name != null && name.getContents() instanceof TranslatableContents tc && tc.getKey().equals(key);
    }

    private static final class BossTrack {
        final UUID id;
        final ServerLevel level;
        BlockPos last;

        BossTrack(UUID id, ServerLevel level, BlockPos last) {
            this.id = id;
            this.level = level;
            this.last = last;
        }
    }

    private static final class SpiritTrack {
        final UUID id;
        final ServerLevel level;
        final long endTick;
        BlockPos last;

        SpiritTrack(UUID id, ServerLevel level, long endTick, BlockPos last) {
            this.id = id;
            this.level = level;
            this.endTick = endTick;
            this.last = last;
        }
    }

    private static final List<BossTrack> BOSSES = new ArrayList<>();
    private static final List<SpiritTrack> SPIRITS = new ArrayList<>();

    public static List<ServerPlayer> nearby(ServerLevel sl, BlockPos pos, double r) {
        return sl.getEntitiesOfClass(ServerPlayer.class, new AABB(pos).inflate(r), p -> p.isAlive() && !p.isSpectator());
    }

    // ================= Рог глубин: босс =================

    public static boolean summonBoss(ServerLevel sl, ServerPlayer player) {
        EntityType<?> type = BuiltInRegistries.ENTITY_TYPE
                .get(Identifier.fromNamespaceAndPath(ModRegistry.MODID, BOSS_ID))
                .map(Holder::value).orElse(null);
        if (type == null) return false; // босс с таким id не найден

        List<ServerPlayer> players = nearby(sl, player.blockPosition(), 48);
        BlockPos spot = HornRitual.waterSpot(sl, player.blockPosition(), 10, true);
        if (spot == null) spot = player.blockPosition().below(2);

        Entity boss = type.spawn(sl, spot, EntitySpawnReason.TRIGGERED);
        if (boss == null) return false;
        boss.addTag(BOSS_TAG);
        if (boss instanceof Mob m) {
            m.setPersistenceRequired();
            m.setTarget(player);
        }

        // «поднимается из глубины»
        sl.sendParticles(ParticleTypes.BUBBLE_POP, spot.getX() + 0.5, spot.getY() + 1, spot.getZ() + 0.5, 80, 1.5, 3.0, 1.5, 0.1);
        sl.sendParticles(ParticleTypes.SQUID_INK, spot.getX() + 0.5, spot.getY() + 1, spot.getZ() + 0.5, 40, 1.0, 1.0, 1.0, 0.1);
        sl.playSound(null, spot, SoundEvents.TRIAL_SPAWNER_SPAWN_MOB, SoundSource.HOSTILE, 3f, 0.5f);

        BOSSES.add(new BossTrack(boss.getUUID(), sl, boss.blockPosition()));
        for (ServerPlayer p : players) p.sendSystemMessage(Component.translatable("msg.aqua_dominus.horn_boss"));
        return true;
    }

    private static void tickBosses() {
        Iterator<BossTrack> it = BOSSES.iterator();
        while (it.hasNext()) {
            BossTrack b = it.next();
            Entity e = b.level.getEntity(b.id);
            List<ServerPlayer> near = nearby(b.level, b.last, 64);

            if (e instanceof LivingEntity le && le.isAlive()) {
                b.last = le.blockPosition();
            } else if (e == null && near.isEmpty()) {
                continue; // чанк выгружен, ждём
            } else {
                it.remove();
                rewardBoss(b.level, near, b.last);
            }
        }
    }

    private static void rewardBoss(ServerLevel sl, List<ServerPlayer> players, BlockPos at) {
        sl.playSound(null, at, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 2f, 1f);
        for (ServerPlayer p : players) {
            p.sendSystemMessage(Component.translatable("msg.aqua_dominus.horn_boss_dead"));
            for (BeaconConfig.ItemReq r : HornConfig.bossRewards()) {
                ItemStack s = new ItemStack(r.item(), r.count());
                if (!p.getInventory().add(s)) p.drop(s, false);
            }
            p.giveExperiencePoints(HornConfig.BOSS_XP.get());
        }
    }

    // ================= Рог приливов: шторм и дух =================

    public static boolean summonSpirit(ServerLevel sl, ServerPlayer player) {
        BlockPos spot = HornRitual.waterSpot(sl, player.blockPosition(), 3, false);
        if (spot == null) spot = player.blockPosition();

        Entity spirit = EntityType.DOLPHIN.spawn(sl, spot, EntitySpawnReason.TRIGGERED);
        if (spirit == null) return false;
        spirit.setCustomName(Component.translatable(KEY_SPIRIT));
        spirit.setCustomNameVisible(true);
        spirit.setInvulnerable(true);
        if (spirit instanceof Mob m) m.setPersistenceRequired();
        if (spirit instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 20 * HornConfig.SPIRIT_SECONDS.get(), 0, false, false));
        }

        long end = sl.getGameTime() + 20L * HornConfig.SPIRIT_SECONDS.get();
        SPIRITS.add(new SpiritTrack(spirit.getUUID(), sl, end, spirit.blockPosition()));

        if (HornConfig.SPIRIT_STORM.get()) {
            MinecraftServer server = sl.getServer();
            server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(),
                    "weather thunder " + (20 * HornConfig.SPIRIT_SECONDS.get()));
        }
        sl.sendParticles(ParticleTypes.NAUTILUS, spot.getX() + 0.5, spot.getY() + 1, spot.getZ() + 0.5, 80, 1.5, 1.5, 1.5, 0.5);
        sl.playSound(null, spot, SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 2f, 0.8f);
        for (ServerPlayer p : nearby(sl, player.blockPosition(), 48)) {
            p.sendSystemMessage(Component.translatable("msg.aqua_dominus.horn_spirit"));
        }
        return true;
    }

    private static void tickSpirits(long tick) {
        Iterator<SpiritTrack> it = SPIRITS.iterator();
        while (it.hasNext()) {
            SpiritTrack s = it.next();
            Entity e = s.level.getEntity(s.id);
            boolean expired = s.level.getGameTime() >= s.endTick;
            if (e == null || !e.isAlive() || expired) {
                if (e != null) {
                    s.level.sendParticles(ParticleTypes.NAUTILUS, e.getX(), e.getY() + 0.5, e.getZ(), 60, 1, 1, 1, 0.5);
                    e.discard();
                }
                for (ServerPlayer p : nearby(s.level, s.last, HornConfig.SPIRIT_RADIUS.get())) {
                    p.sendSystemMessage(Component.translatable("msg.aqua_dominus.horn_spirit_leave"));
                }
                it.remove();
                continue;
            }
            s.last = e.blockPosition();
            s.level.sendParticles(ParticleTypes.GLOW, e.getX(), e.getY() + 0.4, e.getZ(), 2, 0.4, 0.3, 0.4, 0.02);
            if (tick % 20 == 0) {
                for (ServerPlayer p : nearby(s.level, s.last, HornConfig.SPIRIT_RADIUS.get())) applyBuffs(p);
            }
        }
    }

    private static void applyBuffs(ServerPlayer p) {
        for (String entry : HornConfig.SPIRIT_EFFECTS.get()) {
            String[] parts = entry.split(";");
            Identifier id = Identifier.tryParse(parts[0].trim());
            if (id == null) continue;
            Holder<MobEffect> eff = BuiltInRegistries.MOB_EFFECT.get(id).orElse(null);
            if (eff == null) continue;
            int amp;
            try { amp = Integer.parseInt(parts[1].trim()); } catch (NumberFormatException ex) { amp = 0; }
            p.addEffect(new MobEffectInstance(eff, 120, amp, true, true));
        }
    }

    // ================= События =================

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post e) {
        int t = e.getServer().getTickCount();
        if (t % 10 == 0) tickBosses();
        tickSpirits(t);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        BOSSES.clear();
        SPIRITS.clear();
    }

    /** После перезапуска: босса, вызванного рогом, снова берём под контроль (награда), духа убираем. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent e) {
        if (!(e.getLevel() instanceof ServerLevel sl)) return;
        Entity ent = e.getEntity();
        if (hasNameKey(ent, KEY_SPIRIT)) {
            for (SpiritTrack s : SPIRITS) if (s.id.equals(ent.getUUID())) return;
            e.setCanceled(true);
        } else if (ent.entityTags().contains(BOSS_TAG)) {
            for (BossTrack b : BOSSES) if (b.id.equals(ent.getUUID())) return;
            BOSSES.add(new BossTrack(ent.getUUID(), sl, ent.blockPosition()));
        }
    }

    private SeaEvents() {}
}
package com.gospi.aquadominus.horn;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.Level;

public class SeaHornItem extends Item {
    private final HornKind kind;

    public SeaHornItem(Properties properties, HornKind kind) {
        super(properties);
        this.kind = kind;
    }

    public HornKind kind() { return kind; }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!HornRitual.inRightBiome(level, player)) {
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                sp.sendSystemMessage(Component.translatable("msg.aqua_dominus.horn_wrong_biome"));
            }
            return InteractionResult.FAIL;
        }
        player.startUsingItem(hand);
        return InteractionResult.CONSUME;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.TOOT_HORN;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 60;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (level instanceof ServerLevel sl && entity instanceof ServerPlayer player) {
            HornRitual.perform(sl, player, kind, stack);
        }
        return stack;
    }
}

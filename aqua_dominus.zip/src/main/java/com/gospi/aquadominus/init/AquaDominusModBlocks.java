/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

import com.gospi.aquadominus.block.*;
import com.gospi.aquadominus.AquaDominusMod;

public class AquaDominusModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AquaDominusMod.MODID);
	public static final DeferredBlock<Block> BREATHABLE_MAGMA;
	public static final DeferredBlock<Block> DEEP_OCEAN_CRATE_BOX;
	public static final DeferredBlock<Block> OCEAN_CRATE_BOX;
	public static final DeferredBlock<Block> RARE_WARM_OCEAN_CRATE_BOX;
	public static final DeferredBlock<Block> WARM_OCEAN_CRATE_BOX;
	public static final DeferredBlock<Block> COLD_OCEAN_CRATE_BOX;
	public static final DeferredBlock<Block> PEARL_OYSTER;
	public static final DeferredBlock<Block> BEACON_BRICKS;
	static {
		BREATHABLE_MAGMA = register("breathable_magma", BreathableMagmaBlock::new);
		DEEP_OCEAN_CRATE_BOX = register("deep_ocean_crate_box", DeepOceanCrateBoxBlock::new);
		OCEAN_CRATE_BOX = register("ocean_crate_box", OceanCrateBoxBlock::new);
		RARE_WARM_OCEAN_CRATE_BOX = register("rare_warm_ocean_crate_box", RareWarmOceanCrateBoxBlock::new);
		WARM_OCEAN_CRATE_BOX = register("warm_ocean_crate_box", WarmOceanCrateBoxBlock::new);
		COLD_OCEAN_CRATE_BOX = register("cold_ocean_crate_box", ColdOceanCrateBoxBlock::new);
		PEARL_OYSTER = register("pearl_oyster", PearlOysterBlock::new);
		BEACON_BRICKS = register("beacon_bricks", BeaconBricksBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}
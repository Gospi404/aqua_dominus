/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import com.gospi.aquadominus.entity.SculkanglerEntity;
import com.gospi.aquadominus.entity.GiantSquidEntity;
import com.gospi.aquadominus.AquaDominusMod;

@EventBusSubscriber
public class AquaDominusModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, AquaDominusMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<SculkanglerEntity>> SCULKANGLER = register("sculkangler",
			EntityType.Builder.<SculkanglerEntity>of(SculkanglerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.notInPeaceful().sized(0.9f, 1.2f));
	public static final DeferredHolder<EntityType<?>, EntityType<GiantSquidEntity>> GIANT_SQUID = register("giant_squid",
			EntityType.Builder.<GiantSquidEntity>of(GiantSquidEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.notInPeaceful().sized(1f, 1.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(AquaDominusMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		SculkanglerEntity.init(event);
		GiantSquidEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SCULKANGLER.get(), SculkanglerEntity.createAttributes().build());
		event.put(GIANT_SQUID.get(), GiantSquidEntity.createAttributes().build());
	}
}
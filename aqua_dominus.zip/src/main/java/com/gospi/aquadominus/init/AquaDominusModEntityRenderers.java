/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import com.gospi.aquadominus.client.renderer.SculkanglerRenderer;
import com.gospi.aquadominus.client.renderer.GiantSquidRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class AquaDominusModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AquaDominusModEntities.SCULKANGLER.get(), SculkanglerRenderer::new);
		event.registerEntityRenderer(AquaDominusModEntities.GIANT_SQUID.get(), GiantSquidRenderer::new);
	}
}
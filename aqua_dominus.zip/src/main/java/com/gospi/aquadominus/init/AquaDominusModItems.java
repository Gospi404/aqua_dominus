/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import java.util.function.Function;

import com.gospi.aquadominus.item.*;
import com.gospi.aquadominus.AquaDominusMod;

public class AquaDominusModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AquaDominusMod.MODID);
	public static final DeferredItem<Item> DIVING_SUIT_HELMET;
	public static final DeferredItem<Item> DIVING_SUIT_CHESTPLATE;
	public static final DeferredItem<Item> DIVING_SUIT_LEGGINGS;
	public static final DeferredItem<Item> DIVING_SUIT_BOOTS;
	public static final DeferredItem<Item> NAUTILUS_AIR_SHELL;
	public static final DeferredItem<Item> BREATHABLE_MAGMA;
	public static final DeferredItem<Item> TETROPIA_GUIDE;
	public static final DeferredItem<Item> DEEP_OCEAN_CRATE_BOX;
	public static final DeferredItem<Item> OCEAN_CRATE_BOX;
	public static final DeferredItem<Item> RARE_WARM_OCEAN_CRATE_BOX;
	public static final DeferredItem<Item> WARM_OCEAN_CRATE_BOX;
	public static final DeferredItem<Item> COLD_OCEAN_CRATE_BOX;
	public static final DeferredItem<Item> SCULKANGLER_SPAWN_EGG;
	public static final DeferredItem<Item> PEARL_OYSTER;
	public static final DeferredItem<Item> PEARL;
	public static final DeferredItem<Item> RAW_OYSTER;
	public static final DeferredItem<Item> COOKED_OYSTER;
	public static final DeferredItem<Item> NETHER_PRISM;
	public static final DeferredItem<Item> GIFT_OF_LIGHT;
	public static final DeferredItem<Item> DUNGEON_MECHANISM;
	public static final DeferredItem<Item> BEACON_BRICKS;
	public static final DeferredItem<Item> PRESSED_COPPER_INGOT;
	public static final DeferredItem<Item> SHARK_TOOTH;
	public static final DeferredItem<Item> GIANT_SQUID_SPAWN_EGG;
	public static final DeferredItem<Item> GREAT_HEART_OF_THE_SEA;
	static {
		DIVING_SUIT_HELMET = register("diving_suit_helmet", DivingSuitItem.Helmet::new);
		DIVING_SUIT_CHESTPLATE = register("diving_suit_chestplate", DivingSuitItem.Chestplate::new);
		DIVING_SUIT_LEGGINGS = register("diving_suit_leggings", DivingSuitItem.Leggings::new);
		DIVING_SUIT_BOOTS = register("diving_suit_boots", DivingSuitItem.Boots::new);
		NAUTILUS_AIR_SHELL = register("nautilus_air_shell", NautilusAirShellItem::new);
		BREATHABLE_MAGMA = block(AquaDominusModBlocks.BREATHABLE_MAGMA);
		TETROPIA_GUIDE = register("tetropia_guide", TetropiaGuideItem::new);
		DEEP_OCEAN_CRATE_BOX = block(AquaDominusModBlocks.DEEP_OCEAN_CRATE_BOX);
		OCEAN_CRATE_BOX = block(AquaDominusModBlocks.OCEAN_CRATE_BOX);
		RARE_WARM_OCEAN_CRATE_BOX = block(AquaDominusModBlocks.RARE_WARM_OCEAN_CRATE_BOX);
		WARM_OCEAN_CRATE_BOX = block(AquaDominusModBlocks.WARM_OCEAN_CRATE_BOX);
		COLD_OCEAN_CRATE_BOX = block(AquaDominusModBlocks.COLD_OCEAN_CRATE_BOX);
		SCULKANGLER_SPAWN_EGG = register("sculkangler_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(AquaDominusModEntities.SCULKANGLER.get())));
		PEARL_OYSTER = block(AquaDominusModBlocks.PEARL_OYSTER);
		PEARL = register("pearl", PearlItem::new);
		RAW_OYSTER = register("raw_oyster", RawOysterItem::new);
		COOKED_OYSTER = register("cooked_oyster", CookedOysterItem::new);
		NETHER_PRISM = register("nether_prism", NetherPrismItem::new);
		GIFT_OF_LIGHT = register("gift_of_light", GiftOfLightItem::new);
		DUNGEON_MECHANISM = register("dungeon_mechanism", DungeonMechanismItem::new);
		BEACON_BRICKS = block(AquaDominusModBlocks.BEACON_BRICKS);
		PRESSED_COPPER_INGOT = register("pressed_copper_ingot", PressedCopperIngotItem::new);
		SHARK_TOOTH = register("shark_tooth", SharkToothItem::new);
		GIANT_SQUID_SPAWN_EGG = register("giant_squid_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(AquaDominusModEntities.GIANT_SQUID.get())));
		GREAT_HEART_OF_THE_SEA = register("great_heart_of_the_sea", GreatHeartOfTheSeaItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import com.gospi.aquadominus.client.model.Modelshark;
import com.gospi.aquadominus.client.model.Modelseaper;
import com.gospi.aquadominus.client.model.Modelprismy;
import com.gospi.aquadominus.client.model.Modelgiant_squid;
import com.gospi.aquadominus.client.model.Modeldrake_skeleton;

@EventBusSubscriber(Dist.CLIENT)
public class AquaDominusModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelgiant_squid.LAYER_LOCATION, Modelgiant_squid::createBodyLayer);
		event.registerLayerDefinition(Modeldrake_skeleton.LAYER_LOCATION, Modeldrake_skeleton::createBodyLayer);
		event.registerLayerDefinition(Modelprismy.LAYER_LOCATION, Modelprismy::createBodyLayer);
		event.registerLayerDefinition(Modelseaper.LAYER_LOCATION, Modelseaper::createBodyLayer);
		event.registerLayerDefinition(Modelshark.LAYER_LOCATION, Modelshark::createBodyLayer);
	}
}
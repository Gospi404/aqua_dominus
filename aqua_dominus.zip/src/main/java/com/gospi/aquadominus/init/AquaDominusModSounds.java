/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import com.gospi.aquadominus.AquaDominusMod;

public class AquaDominusModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, AquaDominusMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> DECIMATION_MENU_MUSIC = REGISTRY.register("decimation_menu_music", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("aqua_dominus", "decimation_menu_music")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DECIMATION_BUTTON_HOVER = REGISTRY.register("decimation_button_hover",
			() -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("aqua_dominus", "decimation_button_hover")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DECIMATION_BUTTON_PRESS = REGISTRY.register("decimation_button_press",
			() -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("aqua_dominus", "decimation_button_press")));
	public static final DeferredHolder<SoundEvent, SoundEvent> DECIMATION_INTRO = REGISTRY.register("decimation_intro", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("aqua_dominus", "decimation_intro")));
}
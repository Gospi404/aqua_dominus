/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.gospi.aquadominus.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import com.gospi.aquadominus.AquaDominusMod;

@EventBusSubscriber
public class AquaDominusModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AquaDominusMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AquaDominusModItems.DIVING_SUIT_HELMET.get());
			tabData.accept(AquaDominusModItems.DIVING_SUIT_CHESTPLATE.get());
			tabData.accept(AquaDominusModItems.DIVING_SUIT_LEGGINGS.get());
			tabData.accept(AquaDominusModItems.DIVING_SUIT_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AquaDominusModItems.NAUTILUS_AIR_SHELL.get());
			tabData.accept(AquaDominusModItems.TETROPIA_GUIDE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AquaDominusModBlocks.BREATHABLE_MAGMA.get().asItem());
			tabData.accept(AquaDominusModBlocks.PEARL_OYSTER.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(AquaDominusModBlocks.DEEP_OCEAN_CRATE_BOX.get().asItem());
			tabData.accept(AquaDominusModBlocks.OCEAN_CRATE_BOX.get().asItem());
			tabData.accept(AquaDominusModBlocks.RARE_WARM_OCEAN_CRATE_BOX.get().asItem());
			tabData.accept(AquaDominusModBlocks.WARM_OCEAN_CRATE_BOX.get().asItem());
			tabData.accept(AquaDominusModBlocks.COLD_OCEAN_CRATE_BOX.get().asItem());
			tabData.accept(AquaDominusModBlocks.BEACON_BRICKS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AquaDominusModItems.SCULKANGLER_SPAWN_EGG.get());
			tabData.accept(AquaDominusModItems.GIANT_SQUID_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(AquaDominusModItems.PEARL.get());
			tabData.accept(AquaDominusModItems.NETHER_PRISM.get());
			tabData.accept(AquaDominusModItems.GIFT_OF_LIGHT.get());
			tabData.accept(AquaDominusModItems.DUNGEON_MECHANISM.get());
			tabData.accept(AquaDominusModItems.PRESSED_COPPER_INGOT.get());
			tabData.accept(AquaDominusModItems.SHARK_TOOTH.get());
			tabData.accept(AquaDominusModItems.GREAT_HEART_OF_THE_SEA.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(AquaDominusModItems.RAW_OYSTER.get());
			tabData.accept(AquaDominusModItems.COOKED_OYSTER.get());
		}
	}
}
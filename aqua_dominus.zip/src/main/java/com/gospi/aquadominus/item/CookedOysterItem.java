package com.gospi.aquadominus.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class CookedOysterItem extends Item {
	public CookedOysterItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(6).saturationModifier(3f).build()));
	}
}
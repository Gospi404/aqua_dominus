package com.gospi.aquadominus.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DungeonMechanismItem extends Item {
	public DungeonMechanismItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).stacksTo(1).fireResistant());
	}
}
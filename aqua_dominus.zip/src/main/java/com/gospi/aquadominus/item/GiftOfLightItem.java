package com.gospi.aquadominus.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GiftOfLightItem extends Item {
	public GiftOfLightItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).stacksTo(1).fireResistant());
	}
}
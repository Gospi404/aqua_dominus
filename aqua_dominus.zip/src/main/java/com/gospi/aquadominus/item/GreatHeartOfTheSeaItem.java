package com.gospi.aquadominus.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class GreatHeartOfTheSeaItem extends Item {
	public GreatHeartOfTheSeaItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC));
	}
}
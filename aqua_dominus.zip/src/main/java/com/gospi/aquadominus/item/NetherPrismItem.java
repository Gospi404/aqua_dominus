package com.gospi.aquadominus.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class NetherPrismItem extends Item {
	public NetherPrismItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).stacksTo(1).fireResistant());
	}
}
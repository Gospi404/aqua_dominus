package com.gospi.aquadominus.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class PearlItem extends Item {
	public PearlItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE));
	}
}
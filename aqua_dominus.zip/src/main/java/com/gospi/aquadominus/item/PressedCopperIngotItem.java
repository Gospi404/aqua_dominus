package com.gospi.aquadominus.item;

import net.minecraft.world.item.Item;

public class PressedCopperIngotItem extends Item {
	public PressedCopperIngotItem(Item.Properties properties) {
		super(properties);
	}
}
package com.gospi.aquadominus.item;

import net.minecraft.world.item.Item;

public class SharkToothItem extends Item {
	public SharkToothItem(Item.Properties properties) {
		super(properties);
	}
}
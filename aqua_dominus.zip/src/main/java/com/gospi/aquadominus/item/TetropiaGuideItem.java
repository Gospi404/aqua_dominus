package com.gospi.aquadominus.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.WrittenBookContent;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.network.Filterable;
import net.minecraft.network.chat.Component;
import net.minecraft.core.component.DataComponents;

import java.util.List;

public class TetropiaGuideItem extends WrittenBookItem {
	public TetropiaGuideItem(Item.Properties properties) {
		super(properties.stacksTo(1).component(() -> DataComponents.WRITTEN_BOOK_CONTENT, new WrittenBookContent(Filterable.passThrough("Tetropia Guide"), "Gospi_", 0, List.of(Filterable.passThrough(Component.literal("Tetropia Guide"))), true)));
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			openCustomBookScreen(hand);
		}
		return InteractionResult.SUCCESS;
	}

	/**
	 * Kept reflection-only so the common item class never has a hard client-class reference
	 * when loaded on a dedicated server. The input event is still the primary path because
	 * it fires before blocks/entities can consume the right click.
	 */
	private static void openCustomBookScreen(InteractionHand hand) {
		try {
			Class<?> minecraftClass = Class.forName("net.minecraft.client.Minecraft");
			Class<?> screenBase = Class.forName("net.minecraft.client.gui.screens.Screen");
			Class<?> screenClass = Class.forName("com.gospi.aquadominus.client.gui.TetropiaGuideBookScreen");
			Object minecraft = minecraftClass.getMethod("getInstance").invoke(null);
			Object screen = screenClass.getConstructor(InteractionHand.class).newInstance(hand);
			minecraftClass.getMethod("setScreen", screenBase).invoke(minecraft, screen);
		} catch (ReflectiveOperationException ignored) {
		}
	}
}
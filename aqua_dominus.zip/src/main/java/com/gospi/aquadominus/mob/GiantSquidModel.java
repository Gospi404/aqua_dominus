package com.gospi.aquadominus.client.mob;

import org.joml.Quaternionf;
import org.joml.Vector3f;

import com.gospi.aquadominus.client.model.Modelgiant_squid;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.phys.Vec3;

/**
 * Применяет позу из GiantSquidPose: наклон тела, сжатие мантии, глаза и все 24 сегмента щупалец.
 * Сегменты в экспорте Blockbench не связаны цепочкой (все дети ноги), поэтому позиции шарниров считаются здесь.
 */
public class GiantSquidModel extends Modelgiant_squid {
    private final ModelPart[] legs;
    private final ModelPart[][] seg;

    public GiantSquidModel(ModelPart root) {
        super(root);
        legs = new ModelPart[] {left_front_leg, left_middle_front_leg, left_middle_back_leg, left_back_leg,
                right_front_leg, right_middle_front_leg, right_middle_back_leg, right_back_leg};
        seg = new ModelPart[][] {
                {big, middle, small}, {big2, middle2, small2}, {big3, middle3, small3}, {big4, middle4, small4},
                {big5, middle5, small5}, {big6, middle6, small6}, {big7, middle7, small7}, {big8, middle8, small8}};
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);
        if (!(state instanceof GiantSquidRenderState s)) return;

        body.xRot = s.bodyPitch;
        body.xScale = 1f + s.squash * 0.6f;
        body.zScale = 1f + s.squash * 0.6f;
        body.yScale = 1f - s.squash;
        left_eye.yScale = s.eyeScale;
        left_eye.zScale = s.eyeScale;
        right_eye.yScale = s.eyeScale;
        right_eye.zScale = s.eyeScale;

        Quaternionf q = new Quaternionf();
        Vector3f euler = new Vector3f();
        for (int i = 0; i < 8; i++) {
            // разворот ноги теперь задают сами сегменты, поэтому сама нога без поворота
            legs[i].xRot = 0f;
            legs[i].yRot = 0f;
            legs[i].zRot = 0f;

            Vec3 pivot = new Vec3(0, 0.8333, -0.0833);
            for (int j = 0; j < 3; j++) {
                Vec3 d = s.dirs[i][j];
                if (d == null) d = new Vec3(0, 1, 0);
                ModelPart part = seg[i][j];
                part.x = (float) pivot.x;
                part.y = (float) pivot.y;
                part.z = (float) pivot.z;

                // поворот оси +Y к направлению d, затем разворот плоскости щупальца вокруг своей оси
                q.identity().rotationTo(0f, 1f, 0f, (float) d.x, (float) d.y, (float) d.z).rotateY(GiantSquidPose.SPIN[i]);
                q.getEulerAnglesZYX(euler);
                part.xRot = euler.x;
                part.yRot = euler.y;
                part.zRot = euler.z;

                pivot = pivot.add(d.scale(GiantSquidPose.LEN[j]));
            }
        }
    }
}
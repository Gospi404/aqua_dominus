package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.entity.GiantSquidEntity;

import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Поза гигантского кальмара: наклон тела, волны щупалец, позы атак и обход блоков.
 * Щупальца не проходят сквозь блоки: каждый сегмент проверяется лучом по миру, при попадании направление
 * отклоняется от поверхности (результат кэшируется и пересчитывается раз в тик).
 *
 * Все числа в пикселях модели. Система координат тела: начало в точке вращения тела (0, 10, 0).
 */
public final class GiantSquidPose {
    private static final double[][] BASE = {{3, -4.9167}, {6, -2.9167}, {6, 3.0833}, {3, 5.0833}};
    public static final float[] SPIN = {-0.3927f, -1.309f, -1.8326f, -2.7489f, 0.3927f, 1.309f, 1.8326f, 2.7489f};
    /** Длины сегментов: между шарнирами 13.5 и 12.5, последний сегмент 19. */
    public static final double[] LEN = {13.5, 12.5, 19.0};
    private static final double LEG_Y = 8.1667, START_Y = 0.8333, PIVOT_Y = 10.0;

    public static void fill(GiantSquidEntity e, GiantSquidRenderState s, float pt) {
        float age = e.tickCount + pt;
        int type = e.animTick > 0 ? e.animType : 0;
        float p = e.animLen > 0 ? Mth.clamp(1f - (e.animTick - pt) / e.animLen, 0f, 1f) : 0f;
        float tilt = e.smoothTilt;
        float speedMul = e.enraged ? 1.35f : 1f;

        // наклон: щупальцами вперёд по направлению движения
        double alpha = e.smoothPitch;
        float theta = (float) Math.atan2(-Math.cos(alpha), -Math.sin(alpha)) * tilt;
        float pulse = tilt > 0.15f ? (float) Math.pow(Math.max(0f, Mth.sin(age * 0.28f * speedMul)), 2) * tilt : 0f;

        s.bodyPitch = theta;
        s.squash = pulse * 0.07f + (type == GiantSquidEntity.A_INK ? Mth.sin(p * Mth.PI) * 0.12f : 0f);
        s.eyeScale = 1f + (type != 0 || e.grabbing ? 0.3f : 0f) + (e.enraged ? 0.25f : 0f);

        double yaw = Mth.rotLerp(pt, e.yBodyRotO, e.yBodyRot);
        Space space = new Space(e.getPosition(pt), yaw, theta);

        float stream = type == GiantSquidEntity.A_JET ? smooth(Mth.clamp(p / 0.4f, 0f, 1f)) : 0f;
        float grabW = e.grabbing ? 1f : type == GiantSquidEntity.A_GRAB ? smooth(Mth.clamp(p / 0.5f, 0f, 1f)) : 0f;
        Vec3 hold = space.worldToBody(e.getPosition(pt).add(-Math.sin(Math.toRadians(yaw)) * 1.5, 0.3, Math.cos(Math.toRadians(yaw)) * 1.5));

        Vec3[][] desired = new Vec3[8][3];
        double[][] bases = new double[8][2];
        for (int i = 0; i < 8; i++) {
            double bx = (i < 4 ? 1 : -1) * BASE[i % 4][0];
            double bz = BASE[i % 4][1];
            bases[i][0] = bx;
            bases[i][1] = bz;
            double ol = Math.hypot(bx, bz);
            double ox = bx / ol, oz = bz / ol;
            double phase = i * 0.9;
            Vec3 start = new Vec3(bx, LEG_Y + START_Y, bz);
            Vec3 toHold = hold.subtract(start).normalize();

            for (int j = 0; j < 3; j++) {
                double amp = 0.16 + 0.10 * j;
                double sx = Math.sin(age * 0.11 * speedMul - j * 0.9 + phase) * amp * (1 - 0.6 * tilt);
                double sz = Math.cos(age * 0.09 * speedMul - j * 0.9 + phase * 1.3) * amp * (1 - 0.6 * tilt);
                double splay = (0.12 + 0.22 * j) * (1 - 0.75 * tilt) * (1 - 0.5 * pulse);
                double y = 1.0;

                switch (type) {
                    case GiantSquidEntity.A_SLAM -> {
                        float r = slam(p);
                        y = 1.0 - 1.7 * r;                              // поднимает щупальца и бьёт вниз
                        splay += 0.6 * Math.max(r, 0) + 1.2 * Math.max(-r, 0);
                        sx *= 0.4;
                        sz *= 0.4;
                    }
                    case GiantSquidEntity.A_INK -> {
                        double c = Math.sin(p * Math.PI);                // сжимает щупальца в пучок
                        splay *= 1 - 0.9 * c;
                        sx *= 1 - 0.7 * c;
                        sz *= 1 - 0.7 * c;
                    }
                    case GiantSquidEntity.A_JET -> {
                        splay *= 1 - stream;                             // обтекаемая форма перед рывком
                        sx *= 1 - stream;
                        sz *= 1 - stream;
                    }
                    default -> { }
                }

                Vec3 d = new Vec3(ox * splay + sx, y, oz * splay + sz).normalize();
                if (grabW > 0f) {                                       // тянутся к добыче и сжимают её
                    double w = grabW * (0.55 + 0.2 * j);
                    Vec3 squeeze = new Vec3(Math.sin(age * 0.8 + i) * 0.08, 0, Math.cos(age * 0.8 + i) * 0.08).scale(grabW);
                    d = d.scale(1 - w).add(toHold.scale(w)).add(squeeze).normalize();
                }
                desired[i][j] = d;
            }
        }

        // обход блоков: раз в тик пересчитываем отклонения
        if (e.poseTick != e.tickCount) {
            e.poseTick = e.tickCount;
            updateAvoid(e, space, desired, bases);
        }
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 3; j++) {
                int k = (i * 3 + j) * 3;
                Vec3 d = desired[i][j].add(e.tentacleAvoid[k], e.tentacleAvoid[k + 1], e.tentacleAvoid[k + 2]);
                s.dirs[i][j] = d.lengthSqr() < 1.0E-6 ? desired[i][j] : d.normalize();
            }
        }
    }

    private static void updateAvoid(GiantSquidEntity e, Space space, Vec3[][] desired, double[][] bases) {
        Level level = e.level();
        for (int i = 0; i < 8; i++) {
            double bx = bases[i][0], bz = bases[i][1];
            double ol = Math.hypot(bx, bz);
            Vec3 outward = new Vec3(bx / ol, 0, bz / ol);
            Vec3 pos = new Vec3(bx, LEG_Y + START_Y, bz);

            for (int j = 0; j < 3; j++) {
                Vec3 dir = desired[i][j];
                for (int it = 0; it < 3; it++) {
                    Vec3 a = space.bodyToWorld(pos);
                    Vec3 b = space.bodyToWorld(pos.add(dir.scale(LEN[j])));
                    BlockHitResult hit = level.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
                    if (hit.getType() == HitResult.Type.MISS) break;

                    double total = a.distanceTo(b);
                    double t = total > 1.0E-6 ? a.distanceTo(hit.getLocation()) / total : 0;
                    Direction face = hit.getDirection();
                    Vec3 normal = space.worldDirToBody(new Vec3(face.getStepX(), face.getStepY(), face.getStepZ()));
                    // отгибаем от поверхности: чем раньше упёрлись, тем сильнее
                    dir = dir.add(normal.scale(1.0 - 0.5 * t)).add(outward.scale(0.35)).normalize();
                }
                Vec3 target = dir.subtract(desired[i][j]);
                int k = (i * 3 + j) * 3;
                e.tentacleAvoid[k] = Mth.lerp(0.5f, e.tentacleAvoid[k], (float) target.x);
                e.tentacleAvoid[k + 1] = Mth.lerp(0.5f, e.tentacleAvoid[k + 1], (float) target.y);
                e.tentacleAvoid[k + 2] = Mth.lerp(0.5f, e.tentacleAvoid[k + 2], (float) target.z);
                if (j < 2) pos = pos.add(dir.scale(LEN[j]));
            }
        }
    }

    private static float smooth(float k) {
        return k * k * (3f - 2f * k);
    }

    /** Удар: подъём щупалец, быстрый удар вниз и возврат. */
    private static float slam(float p) {
        if (p < 0.5f) return smooth(p / 0.5f);
        if (p < 0.6f) return Mth.lerp((p - 0.5f) / 0.1f, 1f, -0.5f);
        return Mth.lerp((p - 0.6f) / 0.4f, -0.5f, 0f);
    }

    /** Преобразования между системой тела (пиксели модели) и миром (блоки), как это делает рендер. */
    private record Space(Vec3 origin, double yawDeg, float pitch) {

        Vec3 bodyToWorld(Vec3 b) {
            double c = Math.cos(pitch), sn = Math.sin(pitch);
            double y = b.y * c - b.z * sn;
            double z = b.y * sn + b.z * c;
            return modelToWorld(new Vec3(b.x, y + PIVOT_Y, z));
        }

        Vec3 modelToWorld(Vec3 m) {
            double x = -m.x / 16, y = 1.501 - m.y / 16, z = m.z / 16;
            double th = Math.toRadians(180 - yawDeg);
            double cs = Math.cos(th), sn = Math.sin(th);
            return origin.add(x * cs + z * sn, y, -x * sn + z * cs);
        }

        Vec3 worldToBody(Vec3 w) {
            Vec3 l = w.subtract(origin);
            double th = Math.toRadians(180 - yawDeg);
            double cs = Math.cos(th), sn = Math.sin(th);
            double x2 = l.x * cs - l.z * sn;
            double z2 = l.x * sn + l.z * cs;
            Vec3 m = new Vec3(-x2 * 16, (1.501 - l.y) * 16 - PIVOT_Y, z2 * 16);
            double c = Math.cos(-pitch), s = Math.sin(-pitch);
            return new Vec3(m.x, m.y * c - m.z * s, m.y * s + m.z * c);
        }

        Vec3 worldDirToBody(Vec3 w) {
            double th = Math.toRadians(180 - yawDeg);
            double cs = Math.cos(th), sn = Math.sin(th);
            double x2 = w.x * cs - w.z * sn;
            double z2 = w.x * sn + w.z * cs;
            Vec3 m = new Vec3(-x2, -w.y, z2);
            double c = Math.cos(-pitch), s = Math.sin(-pitch);
            return new Vec3(m.x, m.y * c - m.z * s, m.y * s + m.z * c);
        }
    }

    private GiantSquidPose() {}
}
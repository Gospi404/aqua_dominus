package com.gospi.aquadominus.client.mob;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.phys.Vec3;

public class GiantSquidRenderState extends LivingEntityRenderState {
    /** Поворот тела вокруг оси X (радианы): 0 вертикально, около -90 градусов при плавании щупальцами вперёд. */
    public float bodyPitch;
    /** Сжатие/раздувание мантии. */
    public float squash;
    public float eyeScale = 1f;
    /** Направления сегментов щупалец (8 штук x 3 сегмента) в системе координат тела. */
    public final Vec3[][] dirs = new Vec3[8][3];
}
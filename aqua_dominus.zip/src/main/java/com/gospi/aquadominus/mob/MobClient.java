package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.gospi.aquadominus.client.model.Modelprismy;
import com.gospi.aquadominus.client.model.Modelseaper;
import com.gospi.aquadominus.client.model.Modelshark;
import com.gospi.aquadominus.drake.DrakeRegistry;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = ModRegistry.MODID, value = Dist.CLIENT)
public final class MobClient {

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MobLayers.PRISMY, Modelprismy::createBodyLayer);
        event.registerLayerDefinition(MobLayers.SEAPER, Modelseaper::createBodyLayer);
        event.registerLayerDefinition(MobLayers.SHARK, Modelshark::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(DrakeRegistry.PRISMY.get(), PrismyRenderer::new);
        event.registerEntityRenderer(DrakeRegistry.SEAPER.get(), SeaperRenderer::new);
        event.registerEntityRenderer(DrakeRegistry.SHARK.get(), SharkRenderer::new);
    }

    private MobClient() {}
}
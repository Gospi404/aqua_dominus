package com.gospi.aquadominus.mob;

import net.neoforged.neoforge.common.ModConfigSpec;

/** config/aqua_dominus-mobs.toml */
public final class MobConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<String> PRISMY_TAME_ITEM;
    public static final ModConfigSpec.DoubleValue PRISMY_TAME_CHANCE;
    public static final ModConfigSpec.IntValue PRISMY_REPEL_RADIUS;

    public static final ModConfigSpec.DoubleValue SEAPER_EXPLOSION_RADIUS;

    public static final ModConfigSpec.IntValue SHARK_WEAK_PERCENT;
    public static final ModConfigSpec.ConfigValue<String> SHARK_TOOTH_ITEM;
    public static final ModConfigSpec.DoubleValue SHARK_TOOTH_CHANCE;
    public static final ModConfigSpec.IntValue SHARK_HUNT_INTERVAL_SECONDS;
    public static final ModConfigSpec.DoubleValue SHARK_DRAG_CHANCE;
    public static final ModConfigSpec.IntValue SHARK_DRAG_SECONDS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Призми").push("prismy");
        PRISMY_TAME_ITEM = b.comment("Чем приручать (ПКМ)").define("tameItem", "minecraft:prismarine_shard");
        PRISMY_TAME_CHANCE = b.comment("Шанс приручения за один предмет").defineInRange("tameChance", 0.33, 0.0, 1.0);
        PRISMY_REPEL_RADIUS = b.comment("Радиус, в котором призми отпугивают утопленников")
                .defineInRange("repelRadius", 10, 2, 32);
        b.pop();

        b.comment("Сипер (подводный крипер)").push("seaper");
        SEAPER_EXPLOSION_RADIUS = b.comment("Сила взрыва (у крипера 3)").defineInRange("explosionRadius", 2.5, 0.5, 10.0);
        b.pop();

        b.comment("Акула").push("shark");
        SHARK_WEAK_PERCENT = b.comment("Нападает на игрока в воде, если у него меньше этого % здоровья")
                .defineInRange("weakPercent", 50, 5, 100);
        SHARK_TOOTH_ITEM = b.comment("Зуб, который акула может потерять при укусе (поменяйте на id своего предмета)")
                .define("toothItem", "aqua_dominus:shark_tooth");
        SHARK_TOOTH_CHANCE = b.defineInRange("toothChance", 0.15, 0.0, 1.0);
        SHARK_HUNT_INTERVAL_SECONDS = b.comment("Как часто акула может охотиться на рыб и кальмаров")
                .defineInRange("huntIntervalSeconds", 30, 5, 600);
        SHARK_DRAG_CHANCE = b.comment("Шанс схватить цель при укусе и утащить на дно").defineInRange("dragChance", 0.35, 0.0, 1.0);
        SHARK_DRAG_SECONDS = b.comment("Сколько секунд акула держит и тащит добычу").defineInRange("dragSeconds", 4, 1, 30);
        b.pop();

        SPEC = b.build();
    }

    private MobConfig() {}
}
package com.gospi.aquadominus.client.mob;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.Identifier;

/** Свои слои моделей (не совпадают с теми, что может регистрировать MCreator). */
public final class MobLayers {
    public static final ModelLayerLocation PRISMY = layer("prismy_mob");
    public static final ModelLayerLocation SEAPER = layer("seaper_mob");
    public static final ModelLayerLocation SHARK = layer("shark_mob");

    private static ModelLayerLocation layer(String name) {
        return new ModelLayerLocation(Identifier.fromNamespaceAndPath("aqua_dominus", name), "main");
    }

    private MobLayers() {}
}
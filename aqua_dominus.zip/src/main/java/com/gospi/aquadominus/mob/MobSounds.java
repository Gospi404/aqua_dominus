package com.gospi.aquadominus.mob;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Ванильные звуки по id (не зависит от типа констант SoundEvents). */
public final class MobSounds {
    public static SoundEvent get(String id) {
        return BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse(id));
    }

    private MobSounds() {}
}
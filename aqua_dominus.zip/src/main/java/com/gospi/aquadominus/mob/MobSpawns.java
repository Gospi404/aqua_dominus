package com.gospi.aquadominus.mob;

import com.gospi.aquadominus.beacon.ModRegistry;
import com.gospi.aquadominus.drake.DrakeRegistry;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/**
 * Правила естественного спавна (где мобы вообще МОГУТ появиться). Где и как часто: датапак
 * data/aqua_dominus/neoforge/biome_modifier и structure_modifier (вес, размер группы).
 */
@EventBusSubscriber(modid = ModRegistry.MODID)
public final class MobSpawns {

    @SubscribeEvent
    public static void register(RegisterSpawnPlacementsEvent event) {
        event.register(DrakeRegistry.PRISMY.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.OCEAN_FLOOR,
                MobSpawns::prismy, RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(DrakeRegistry.SEAPER.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.OCEAN_FLOOR,
                MobSpawns::seaper, RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(DrakeRegistry.SHARK.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.OCEAN_FLOOR,
                MobSpawns::shark, RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private static boolean natural(EntitySpawnReason reason) {
        return reason == EntitySpawnReason.NATURAL || reason == EntitySpawnReason.CHUNK_GENERATION;
    }

    private static boolean inWater(ServerLevelAccessor level, BlockPos pos) {
        return level.getFluidState(pos).is(FluidTags.WATER) && level.getFluidState(pos.above()).is(FluidTags.WATER);
    }

    /** Призми: в воде (в монументах), примерно каждая третья попытка. */
    private static boolean prismy(EntityType<PrismyEntity> type, ServerLevelAccessor level, EntitySpawnReason reason,
                                  BlockPos pos, RandomSource random) {
        if (!natural(reason)) return true;
        return inWater(level, pos) && random.nextInt(3) == 0;
    }

    /** Сипер: любая вода ниже поверхности, не на мирной сложности, редко. */
    private static boolean seaper(EntityType<SeaperEntity> type, ServerLevelAccessor level, EntitySpawnReason reason,
                                  BlockPos pos, RandomSource random) {
        if (!natural(reason)) return true;
        return level.getDifficulty() != Difficulty.PEACEFUL && inWater(level, pos)
                && pos.getY() < level.getSeaLevel() - 2 && random.nextInt(2) == 0;
    }

    /** Акула: глубже 3 блоков под поверхностью, редко. */
    private static boolean shark(EntityType<SharkEntity> type, ServerLevelAccessor level, EntitySpawnReason reason,
                                 BlockPos pos, RandomSource random) {
        if (!natural(reason)) return true;
        return inWater(level, pos) && pos.getY() <= level.getSeaLevel() - 3 && random.nextInt(2) == 0;
    }

    private MobSpawns() {}
}
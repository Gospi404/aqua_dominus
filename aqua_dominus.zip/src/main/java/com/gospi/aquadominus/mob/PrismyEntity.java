package com.gospi.aquadominus.mob;

import java.util.EnumSet;
import java.util.UUID;

import com.gospi.aquadominus.beacon.BeaconConfig;

import net.minecraft.core.UUIDUtil;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Призми: маленький светящийся подводный страж. Не атакует игрока, приручается (ПКМ призмариновым осколком),
 * следует за хозяином и отпугивает утопленников.
 */
public class PrismyEntity extends PathfinderMob {
    private UUID owner;
    private int dryTicks;

    public PrismyEntity(EntityType<PrismyEntity> type, Level level) {
        super(type, level);
        this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02F, 0.1F, true);
        this.lookControl = new SmoothSwimmingLookControl(this, 10);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 12)
                .add(Attributes.MOVEMENT_SPEED, 0.9)
                .add(Attributes.FOLLOW_RANGE, 16);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WaterBoundPathNavigation(this, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FollowOwnerSwimGoal(this));
        this.goalSelector.addGoal(2, new RandomSwimmingGoal(this, 1.0, 10));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
    }

    public Player owner() {
        return owner == null ? null : level().getPlayerByUUID(owner);
    }

    public boolean isTamed() { return owner != null; }

    // ================= Следование за хозяином =================

    private static final class FollowOwnerSwimGoal extends Goal {
        private final PrismyEntity prismy;

        FollowOwnerSwimGoal(PrismyEntity prismy) {
            this.prismy = prismy;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = prismy.owner();
            return o != null && prismy.distanceToSqr(o) > 16;
        }

        @Override
        public boolean canContinueToUse() {
            Player o = prismy.owner();
            return o != null && prismy.distanceToSqr(o) > 6.25;
        }

        @Override
        public void tick() {
            Player o = prismy.owner();
            if (o == null) return;
            prismy.getLookControl().setLookAt(o);
            if (prismy.tickCount % 10 == 0) prismy.getNavigation().moveTo(o, 1.3);
            if (prismy.distanceToSqr(o) > 30 * 30 && o.isInWater()) {
                prismy.setPos(o.getX(), o.getY() + 1, o.getZ());
                prismy.getNavigation().stop();
            }
        }
    }

    // ================= Плавание =================

    @Override
    public void travel(Vec3 travelVector) {
        if (isEffectiveAi() && isInWater()) {
            moveRelative(getSpeed(), travelVector);
            move(MoverType.SELF, getDeltaMovement());
            setDeltaMovement(getDeltaMovement().scale(0.9));
            if (getTarget() == null) setDeltaMovement(getDeltaMovement().add(0.0, -0.005, 0.0));
        } else {
            super.travel(travelVector);
        }
    }

    /** Водным мобам нужна своя проверка: по умолчанию мобы не спавнятся в жидкости. */
    @Override
    public boolean checkSpawnObstruction(net.minecraft.world.level.LevelReader level) {
        return level.isUnobstructed(this);
    }

    @Override public boolean canBreatheUnderwater() { return true; }
    @Override public boolean isPushedByFluid() { return false; }

    @Override
    public boolean removeWhenFarAway(double distance) { return !isTamed(); }

    // ================= Тик: отпугивание утопленников =================

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide() || !(level() instanceof ServerLevel sl)) return;

        // без воды высыхает
        if (!isInWater()) {
            if (++dryTicks % 40 == 0) hurtServer(sl, sl.damageSources().dryOut(), 1.0f);
        } else {
            dryTicks = 0;
        }

        if (tickCount % 4 == 0) repelDrowned(sl);
        if (tickCount % 12 == 0) {
            sl.sendParticles(ParticleTypes.GLOW, getX(), getY() + 0.3, getZ(), 1, 0.25, 0.25, 0.25, 0.01);
        }
    }

    private void repelDrowned(ServerLevel sl) {
        double r = MobConfig.PRISMY_REPEL_RADIUS.get();
        for (Mob m : sl.getEntitiesOfClass(Mob.class, getBoundingBox().inflate(r), x -> x.getType() == EntityType.DROWNED)) {
            if (m.getTarget() != null) m.setTarget(null);
            if (tickCount % 20 == 0 || m.getNavigation().isDone()) {
                Vec3 away = m.position().subtract(position()).normalize().scale(10);
                m.getNavigation().moveTo(m.getX() + away.x, m.getY(), m.getZ() + away.z, 1.3);
            }
        }
    }

    // ================= Приручение =================

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        Item tameItem = BeaconConfig.item(MobConfig.PRISMY_TAME_ITEM.get()).orElse(null);
        if (owner == null && tameItem != null && stack.is(tameItem)) {
            if (level().isClientSide()) return InteractionResult.SUCCESS;
            if (!player.hasInfiniteMaterials()) stack.shrink(1);
            ServerLevel sl = (ServerLevel) level();
            if (this.random.nextFloat() < MobConfig.PRISMY_TAME_CHANCE.get()) {
                owner = player.getUUID();
                setPersistenceRequired();
                heal(getMaxHealth());
                sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 0.6, getZ(), 8, 0.4, 0.4, 0.4, 0.05);
                player.sendSystemMessage(Component.translatable("mob.aqua_dominus.prismy_tamed"));
            } else {
                sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 0.5, getZ(), 6, 0.3, 0.3, 0.3, 0.02);
            }
            return InteractionResult.SUCCESS_SERVER;
        }
        return super.mobInteract(player, hand);
    }

    // ================= Звуки и сохранение =================

    @Override public SoundEvent getAmbientSound() { return MobSounds.get("entity.axolotl.idle_water"); }
    @Override public SoundEvent getHurtSound(DamageSource ds) { return MobSounds.get("entity.axolotl.hurt"); }
    @Override public SoundEvent getDeathSound() { return MobSounds.get("entity.axolotl.death"); }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        if (owner != null) out.store("owner", UUIDUtil.CODEC, owner);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        owner = in.read("owner", UUIDUtil.CODEC).orElse(null);
    }
}

package com.gospi.aquadominus.client.mob;

import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

/**
 * Сияние Призми: рисует поверх тела текстуру prismy_glow.png
 * на полной яркости.
 */
public class PrismyGlowLayer extends EyesLayer<LivingEntityRenderState, PrismyModel> {

    private static final RenderType GLOW = RenderTypes.eyes(
            Identifier.parse("aqua_dominus:textures/entities/prismy_glow.png")
    );

    public PrismyGlowLayer(RenderLayerParent<LivingEntityRenderState, PrismyModel> parent) {
        super(parent);
    }

    @Override
    public RenderType renderType() {
        return GLOW;
    }
}

package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.client.model.Modelprismy;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

/** Анимации Призми: покачивание, виляние хвоста, пульс шипов, глаз следит за взглядом. */
public class PrismyModel extends Modelprismy {

    public PrismyModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);
        float age = state.ageInTicks;
        float spd = Math.min(state.walkAnimationSpeed, 1f);

        // покачивание всего тела на месте
        float bob = Mth.sin(age * 0.1f) * 0.5f;
        body.y = 4f + bob;
        tail.y = 20f + bob;
        tail2.y = 20f + bob;
        spine1.y = 12.5f + bob;
        spine2.y = 20.5f + bob;
        spine3.y = 20.5f + bob;
        spine4.y = 29.5f + bob;

        // хвост виляет сильнее при плавании, второй сегмент отстаёт по фазе
        float swish = Mth.sin(age * 0.25f) * (0.25f + 0.5f * spd);
        tail.yRot = swish;
        tail2.yRot = Mth.sin(age * 0.25f - 0.9f) * (0.35f + 0.6f * spd);
        tail2.x = 0.25f + Mth.sin(swish) * 4f;
        tail2.z = 4f + Mth.cos(swish) * 4f;

        // шипы пульсируют
        float p = Mth.sin(age * 0.12f) * 0.12f;
        spine1.zRot = p;
        spine2.zRot = 1.5708f + p;
        spine3.zRot = -1.5708f - p;
        spine4.xRot = p;

        // глаз следит за направлением взгляда
        eye.x = Mth.clamp(state.yRot / 30f, -1f, 1f) * 1.5f;
        eye.y = 20.5f + bob + Mth.clamp(state.xRot / 45f, -1f, 1f) * 1.5f;
    }
}
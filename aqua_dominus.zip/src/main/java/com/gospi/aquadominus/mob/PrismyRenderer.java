package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.mob.PrismyEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class PrismyRenderer extends MobRenderer<PrismyEntity, LivingEntityRenderState, PrismyModel> {
    private static final Identifier TEXTURE = Identifier.parse("aqua_dominus:textures/entities/prismy.png");

    public PrismyRenderer(EntityRendererProvider.Context context) {
        super(context, new PrismyModel(context.bakeLayer(MobLayers.PRISMY)), 0.2f);
        this.addLayer(new PrismyGlowLayer(this));
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
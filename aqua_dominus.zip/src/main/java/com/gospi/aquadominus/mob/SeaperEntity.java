package com.gospi.aquadominus.mob;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Сипер: подводный крипер. Голова в стекле, вместо ног четыре водоросли.
 * Плывёт толчками, как медуза, преследует игрока, рядом с ним раздувается и взрывается.
 */
public class SeaperEntity extends PathfinderMob {
    public static final int MAX_FUSE = 30;
    private static final byte EVT_FUSE_ON = 110, EVT_FUSE_OFF = 111, EVT_PULSE = 112;
    public static final int PULSE_LEN = 12;

    // fuse/fusing синхронизируются событиями, чтобы клиент мог рисовать раздувание
    public int fuse, oldFuse;
    public boolean fusing;
    public int pulseAnim;

    private int pulseTimer = 20;
    private int dryTicks;

    public SeaperEntity(EntityType<SeaperEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 18)
                .add(Attributes.MOVEMENT_SPEED, 0.6)
                .add(Attributes.FOLLOW_RANGE, 24);
    }

    @Override
    protected void registerGoals() {
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    // ================= Тик =================

    @Override
    public void tick() {
        super.tick();
        if (pulseAnim > 0) pulseAnim--;
        oldFuse = fuse;
        if (fusing) {
            if (fuse < MAX_FUSE) fuse++;
        } else if (fuse > 0) {
            fuse--;
        }
        if (!level().isClientSide() && level() instanceof ServerLevel sl) serverTick(sl);
    }

    private void serverTick(ServerLevel sl) {
        // на мирной сложности враждебные мобы исчезают
        if (sl.getDifficulty() == Difficulty.PEACEFUL) {
            discard();
            return;
        }
        // без воды высыхает
        if (!isInWater()) {
            if (++dryTicks % 40 == 0) hurtServer(sl, sl.damageSources().dryOut(), 1.0f);
        } else {
            dryTicks = 0;
        }

        LivingEntity t = getTarget();
        if (t != null && !t.isAlive()) {
            setTarget(null);
            t = null;
        }

        // как крипер: загорается вблизи, гаснет, если цель отошла
        double d = t == null ? Double.MAX_VALUE : distanceToSqr(t);
        boolean want = t != null && (fusing ? d < 25 : d < 9 && hasLineOfSight(t));
        if (want != fusing) {
            fusing = want;
            sl.broadcastEntityEvent(this, want ? EVT_FUSE_ON : EVT_FUSE_OFF);
            if (want) playSound(MobSounds.get("entity.creeper.primed"), 1.0f, 0.5f);
        }
        if (fusing && fuse >= MAX_FUSE) {
            explode(sl);
            return;
        }

        // как медуза: плывёт толчками, во время поджига зависает
        if (!fusing && isInWater() && --pulseTimer <= 0) pulse(sl, t);
    }

    private void pulse(ServerLevel sl, LivingEntity t) {
        Vec3 dir;
        if (t != null) {
            dir = t.getEyePosition().subtract(position()).normalize();
        } else {
            double a = this.random.nextDouble() * Math.PI * 2;
            dir = new Vec3(Math.cos(a) * 0.8, this.random.nextDouble() * 0.6 - 0.2, Math.sin(a) * 0.8).normalize();
        }
        // не вылетаем из воды
        if (dir.y > 0 && !level().getFluidState(blockPosition().above(2)).is(FluidTags.WATER)) {
            dir = new Vec3(dir.x, Math.min(dir.y, 0), dir.z).normalize();
        }
        // без цели держится подальше от дна
        if (t == null && nearFloor(3)) dir = new Vec3(dir.x, Math.max(dir.y, 0.35), dir.z).normalize();
        setDeltaMovement(getDeltaMovement().add(dir.scale(t != null ? 0.38 : 0.22)));

        float yaw = (float) (Mth.atan2(dir.x, dir.z) * (180.0 / Math.PI));
        setYRot(-yaw);
        setYBodyRot(-yaw);
        setYHeadRot(-yaw);

        pulseTimer = t != null ? 14 : 26 + this.random.nextInt(20);
        pulseAnim = PULSE_LEN;
        sl.broadcastEntityEvent(this, EVT_PULSE);
        sl.sendParticles(ParticleTypes.BUBBLE, getX(), getY() + 0.4, getZ(), 4, 0.2, 0.2, 0.2, 0.02);
    }

    /** Есть ли твёрдый блок в пределах depth блоков под сипером. */
    private boolean nearFloor(int depth) {
        BlockPos p = blockPosition();
        for (int i = 1; i <= depth; i++) {
            BlockPos b = p.below(i);
            if (!level().getBlockState(b).getCollisionShape(level(), b).isEmpty()) return true;
        }
        return false;
    }

    private void explode(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.BUBBLE_POP, getX(), getY() + 0.5, getZ(), 40, 0.8, 0.8, 0.8, 0.1);
        sl.explode(this, getX(), getY(0.5), getZ(), MobConfig.SEAPER_EXPLOSION_RADIUS.get().floatValue(),
                Level.ExplosionInteraction.MOB);
        discard();
    }

    /** Плавание толчками: вода только гасит скорость, никакого собственного хода. */
    @Override
    public void travel(Vec3 travelVector) {
        if (isEffectiveAi() && isInWater()) {
            move(MoverType.SELF, getDeltaMovement());
            // нейтральная плавучесть; у дна мягко выталкивает вверх, чтобы не ползал по дну
            double lift = nearFloor(getTarget() == null ? 3 : 1) ? 0.02 : -0.0015;
            setDeltaMovement(getDeltaMovement().scale(0.93).add(0.0, lift, 0.0));
        } else {
            super.travel(travelVector);
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        switch (id) {
            case EVT_FUSE_ON -> fusing = true;
            case EVT_FUSE_OFF -> fusing = false;
            case EVT_PULSE -> pulseAnim = PULSE_LEN;
            default -> super.handleEntityEvent(id);
        }
    }

    /** 0..1: степень раздувания для рендера. */
    public float getSwelling(float partialTicks) {
        return Mth.lerp(partialTicks, oldFuse, fuse) / (MAX_FUSE - 2);
    }

    /** Водным мобам нужна своя проверка: по умолчанию мобы не спавнятся в жидкости. */
    @Override
    public boolean checkSpawnObstruction(net.minecraft.world.level.LevelReader level) {
        return level.isUnobstructed(this);
    }

    @Override public boolean canBreatheUnderwater() { return true; }
    @Override public boolean isPushedByFluid() { return false; }

    @Override public SoundEvent getHurtSound(DamageSource ds) { return MobSounds.get("entity.creeper.hurt"); }
    @Override public SoundEvent getDeathSound() { return MobSounds.get("entity.creeper.death"); }
}
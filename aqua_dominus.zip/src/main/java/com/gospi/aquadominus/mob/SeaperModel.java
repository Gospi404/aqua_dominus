package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.client.model.Modelseaper;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

/** Анимации Сипера: пульсирующее покачивание головы, водоросли-ноги колышутся и поджимаются при толчке. */
public class SeaperModel extends Modelseaper {
    // базовые повороты из Blockbench: xRot, yRot, zRot для LF, RF, LB, RB
    private static final float[][] BASE = {
            {0.6155f, 0.5236f, 0.9553f},
            {0.6155f, -0.5236f, -0.9553f},
            {-0.6155f, -0.5236f, 0.9553f},
            {-0.6155f, 0.5236f, -0.9553f}
    };

    public SeaperModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);
        float age = state.ageInTicks;
        float pulse = 0f;
        float swell = 0f;
        if (state instanceof SeaperRenderState s) {
            pulse = s.pulse;
            swell = s.swelling;
        }

        // голова медленно покачивается и подпрыгивает в такт толчкам
        float off = Mth.sin(age * 0.08f) * 0.8f - pulse * 0.6f;
        Head.y = 24f + off;
        Head.xRot = Mth.sin(age * 0.06f) * 0.05f + pulse * 0.1f;
        Head.yRot = Mth.clamp(state.yRot, -40f, 40f) * 0.0174533f;

        ModelPart[] legs = {left_front_leg, right_front_leg, left_back_leg, right_back_leg};
        float curl = pulse * 0.55f;
        for (int i = 0; i < 4; i++) {
            ModelPart leg = legs[i];
            float[] b = BASE[i];
            float wave = Mth.sin(age * 0.2f + i * 1.3f) * 0.18f;
            float tremble = swell > 0f ? Mth.sin(age * 1.5f + i) * 0.06f * swell : 0f;
            leg.y = 24f + off;
            leg.xRot = b[0] * (1f - curl) + wave;
            leg.yRot = b[1] + wave * 0.6f + tremble;
            leg.zRot = b[2] * (1f - curl * 0.8f) + wave * 0.5f;
        }
    }
}
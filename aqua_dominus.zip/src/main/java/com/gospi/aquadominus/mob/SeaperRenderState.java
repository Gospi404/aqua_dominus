package com.gospi.aquadominus.client.mob;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class SeaperRenderState extends LivingEntityRenderState {
    /** 0..1 раздувание перед взрывом. */
    public float swelling;
    /** 1 в момент толчка, затем затухает до 0. */
    public float pulse;
}
package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.mob.SeaperEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class SeaperRenderer extends MobRenderer<SeaperEntity, SeaperRenderState, SeaperModel> {
    private static final Identifier TEXTURE = Identifier.parse("aqua_dominus:textures/entities/seaper.png");

    public SeaperRenderer(EntityRendererProvider.Context context) {
        super(context, new SeaperModel(context.bakeLayer(MobLayers.SEAPER)), 0.4f);
    }

    @Override
    public SeaperRenderState createRenderState() {
        return new SeaperRenderState();
    }

    @Override
    public void extractRenderState(SeaperEntity entity, SeaperRenderState state, float partialTicks) {
        super.extractRenderState(entity, state, partialTicks);
        state.swelling = entity.getSwelling(partialTicks);
        state.pulse = Mth.clamp((entity.pulseAnim - partialTicks) / SeaperEntity.PULSE_LEN, 0f, 1f);
    }

    /** Раздувание перед взрывом, как у крипера. */
    @Override
    protected void scale(SeaperRenderState state, PoseStack poseStack) {
        float s = state.swelling;
        float shake = 1.0f + Mth.sin(s * 100.0f) * s * 0.01f;
        s = Mth.clamp(s, 0.0f, 1.0f);
        s *= s;
        s *= s;
        float xz = (1.0f + s * 0.4f) * shake;
        float y = (1.0f + s * 0.1f) / shake;
        poseStack.scale(xz, y, xz);
    }

    @Override
    public Identifier getTextureLocation(SeaperRenderState state) {
        return TEXTURE;
    }
}
package com.gospi.aquadominus.mob;

import java.util.List;
import java.util.UUID;

import com.gospi.aquadominus.beacon.BeaconConfig;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;

/**
 * Акула: нейтральна. Нападает на игрока в воде, если у него меньше половины здоровья,
 * иногда охотится на рыб и кальмаров. Укусив, может потерять зуб.
 */
public class SharkEntity extends PathfinderMob {
    private static final byte EVT_GRAB_ON = 113, EVT_GRAB_OFF = 114, EVT_BITE = 115;
    public static final int BITE_LEN = 14;

    /** Клиентская анимация (синхронизируется событиями). */
    public int biteTick;
    public boolean grabbing;

    private UUID grabbed;
    private int grabTicks, grabCooldown;
    private boolean huntingWeak;
    private int preyCooldown;
    private int dryTicks;

    public SharkEntity(EntityType<SharkEntity> type, Level level) {
        super(type, level);
        this.moveControl = new SmoothSwimmingMoveControl(this, 85, 10, 0.02F, 0.1F, true);
        this.lookControl = new SmoothSwimmingLookControl(this, 10);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30)
                .add(Attributes.MOVEMENT_SPEED, 1.0)
                .add(Attributes.ATTACK_DAMAGE, 6)
                .add(Attributes.FOLLOW_RANGE, 24);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WaterBoundPathNavigation(this, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.4, true));
        this.goalSelector.addGoal(2, new RandomSwimmingGoal(this, 1.0, 40));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this)); // дать сдачи, если ударили
    }

    // ================= Выбор цели =================

    private static boolean isPrey(Entity e) {
        EntityType<?> t = e.getType();
        return t == EntityType.COD || t == EntityType.SALMON || t == EntityType.TROPICAL_FISH
                || t == EntityType.PUFFERFISH || t == EntityType.SQUID || t == EntityType.GLOW_SQUID;
    }

    @Override
    public void tick() {
        super.tick();
        if (biteTick > 0) biteTick--;
        if (level().isClientSide() || !(level() instanceof ServerLevel sl)) return;

        if (!isInWater()) {
            if (++dryTicks % 40 == 0) hurtServer(sl, sl.damageSources().dryOut(), 1.0f);
        } else {
            dryTicks = 0;
        }
        if (tickCount % 10 == 0) scan(sl);
        tickGrab(sl);
    }

    private void scan(ServerLevel sl) {
        double weak = MobConfig.SHARK_WEAK_PERCENT.get() / 100.0;
        LivingEntity t = getTarget();

        // игрок восстановился (с запасом 10%): отстаём, если охотились только из-за слабости
        if (t instanceof ServerPlayer p && huntingWeak && (!p.isAlive() || p.isCreative()
                || p.getHealth() >= p.getMaxHealth() * (weak + 0.1))) {
            setTarget(null);
            huntingWeak = false;
            t = null;
        }
        if (t != null && !t.isAlive()) {
            setTarget(null);
            huntingWeak = false;
            t = null;
        }
        if (preyCooldown > 0) preyCooldown -= 10;
        if (t != null) return;

        // 1. слабый игрок в воде
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(20),
                pp -> pp.isAlive() && pp.isInWater() && !pp.isCreative() && !pp.isSpectator())) {
            if (p.getHealth() < p.getMaxHealth() * weak) {
                setTarget(p);
                huntingWeak = true;
                return;
            }
        }

        // 2. иногда охотится на обычных морских существ
        if (preyCooldown <= 0 && this.random.nextInt(4) == 0) {
            List<LivingEntity> prey = sl.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(16),
                    e -> e.isAlive() && isPrey(e));
            if (!prey.isEmpty()) {
                setTarget(prey.get(this.random.nextInt(prey.size())));
                preyCooldown = MobConfig.SHARK_HUNT_INTERVAL_SECONDS.get() * 20;
            }
        }
    }

    // ================= Укус =================

    @Override
    public boolean doHurtTarget(ServerLevel level, Entity target) {
        boolean hit = super.doHurtTarget(level, target);
        if (hit) {
            playSound(MobSounds.get("entity.dolphin.attack"), 1.0f, 0.7f);
            level.broadcastEntityEvent(this, EVT_BITE);
            biteTick = BITE_LEN;
            if (target instanceof LivingEntity victim && canDrag(victim)
                    && this.random.nextFloat() < MobConfig.SHARK_DRAG_CHANCE.get()) {
                grabbed = victim.getUUID();
                grabbing = true;
                grabTicks = MobConfig.SHARK_DRAG_SECONDS.get() * 20;
                level.broadcastEntityEvent(this, EVT_GRAB_ON);
            }
            if (this.random.nextFloat() < MobConfig.SHARK_TOOTH_CHANCE.get()) {
                BeaconConfig.item(MobConfig.SHARK_TOOTH_ITEM.get())
                        .ifPresent(i -> Block.popResource(level, blockPosition(), new ItemStack(i)));
                level.sendParticles(ParticleTypes.BUBBLE, getX(), getY() + 0.4, getZ(), 8, 0.3, 0.2, 0.3, 0.05);
            }
        }
        return hit;
    }

    // ================= Захват и затягивание на дно =================

    private boolean canDrag(LivingEntity v) {
        if (grabbing || grabCooldown > 0 || !v.isInWater() || v.getBbHeight() > 3.5f) return false;
        return !(v instanceof ServerPlayer p && (p.isCreative() || p.isSpectator()));
    }

    private void tickGrab(ServerLevel sl) {
        if (grabCooldown > 0) grabCooldown--;
        if (!grabbing) return;
        Entity v = grabbed == null ? null : sl.getEntity(grabbed);
        if (!(v instanceof LivingEntity victim) || !victim.isAlive() || --grabTicks <= 0 || !isInWater()) {
            release(sl);
            return;
        }
        // держит добычу в пасти и тащит вниз вместе с собой
        Vec3 mouth = getEyePosition().add(getViewVector(1.0f).scale(1.8));
        Vec3 center = victim.position().add(0, victim.getBbHeight() * 0.5, 0);
        victim.setDeltaMovement(mouth.subtract(center).scale(0.3).add(0, -0.1, 0));
        victim.hurtMarked = true;
        setDeltaMovement(getDeltaMovement().add(0, -0.05, 0));
        if (tickCount % 20 == 0) victim.hurtServer(sl, sl.damageSources().mobAttack(this), 2.0f);
    }

    private void release(ServerLevel sl) {
        grabbing = false;
        grabbed = null;
        grabCooldown = 200;
        sl.broadcastEntityEvent(this, EVT_GRAB_OFF);
    }

    /** Добыча может вырваться, если ударить акулу. */
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        boolean r = super.hurtServer(level, source, amount);
        if (r && grabbing && grabbed != null && source.getEntity() != null
                && source.getEntity().getUUID().equals(grabbed) && this.random.nextFloat() < 0.5f) {
            release(level);
        }
        return r;
    }

    @Override
    public void handleEntityEvent(byte id) {
        switch (id) {
            case EVT_BITE -> biteTick = BITE_LEN;
            case EVT_GRAB_ON -> grabbing = true;
            case EVT_GRAB_OFF -> grabbing = false;
            default -> super.handleEntityEvent(id);
        }
    }

    // ================= Плавание =================

    @Override
    public void travel(Vec3 travelVector) {
        if (isEffectiveAi() && isInWater()) {
            moveRelative(getSpeed(), travelVector);
            move(MoverType.SELF, getDeltaMovement());
            setDeltaMovement(getDeltaMovement().scale(0.9));
            if (getTarget() == null) setDeltaMovement(getDeltaMovement().add(0.0, -0.005, 0.0));
        } else {
            super.travel(travelVector);
        }
    }

    /** Водным мобам нужна своя проверка: по умолчанию мобы не спавнятся в жидкости. */
    @Override
    public boolean checkSpawnObstruction(net.minecraft.world.level.LevelReader level) {
        return level.isUnobstructed(this);
    }

    @Override public boolean canBreatheUnderwater() { return true; }
    @Override public boolean isPushedByFluid() { return false; }

    @Override public SoundEvent getHurtSound(DamageSource ds) { return MobSounds.get("entity.dolphin.hurt"); }
    @Override public SoundEvent getDeathSound() { return MobSounds.get("entity.dolphin.death"); }
}
package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.client.model.Modelshark;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.util.Mth;

/** Анимации акулы: изгиб хвоста и хвостового плавника, волна по телу, плавники, пасть при укусе, барахтанье на суше. */
public class SharkModel extends Modelshark {

    public SharkModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(LivingEntityRenderState state) {
        super.setupAnim(state);
        float age = state.ageInTicks;
        float spd = Math.min(state.walkAnimationSpeed, 1f);
        float bite = 0f;
        boolean grabbing = false;
        boolean inWater = true;
        if (state instanceof SharkRenderState s) {
            bite = s.biteProgress;
            grabbing = s.grabbing;
            inWater = s.inWater;
        }

        float rate = inWater ? 0.22f + spd * 0.25f : 0.9f;
        float amp = (inWater ? 0.18f + spd * 0.3f : 0.5f) + (grabbing ? 0.35f : 0f);
        float wave = Mth.sin(age * rate);

        // волна по телу: тело и голова слегка виляют
        body.yRot = wave * amp * 0.25f;
        head.yRot = -wave * amp * 0.2f + Mth.clamp(state.yRot, -30f, 30f) * 0.0174533f;
        head.xRot = Mth.clamp(state.xRot, -30f, 30f) * 0.0174533f;

        // хвост и хвостовой плавник двигаются вместе: плавник сидит на конце хвоста (9 пикселей от оси)
        float tailAngle = Mth.sin(age * rate - 0.7f) * amp;
        tail.yRot = tailAngle;
        tail_fin.x = Mth.sin(tailAngle) * 9f;
        tail_fin.z = 11f + Mth.cos(tailAngle) * 9f;
        tail_fin.yRot = 0.5236f + tailAngle * 1.4f;

        // грудные плавники машут, спинной слегка качается
        float flap = Mth.sin(age * 0.2f) * 0.15f;
        right_fin.zRot = -1.5708f - flap;
        left_fin.zRot = 1.5708f + flap;
        back_fin.xRot = -0.5236f + Mth.sin(age * 0.2f + 1f) * 0.06f;

        // укус: рывок вперёд, пасть широко раскрывается и захлопывается
        float open;
        float lunge;
        if (bite <= 0f) {
            open = 0f;
            lunge = 0f;
        } else if (bite < 0.4f) {
            float k = bite / 0.4f;
            open = k * k * (3f - 2f * k);
            lunge = k * 0.6f;
        } else if (bite < 0.6f) {
            float k = (bite - 0.4f) / 0.2f;
            open = 1f - k * k;
            lunge = 0.6f + k * 0.4f;
        } else {
            float k = (bite - 0.6f) / 0.4f;
            open = 0f;
            lunge = 1f - k;
        }
        top_head.xRot = -0.9f * open;
        bottom_head.xRot = 1.0f * open;
        head.z = -6f - lunge * 3f;
        body.xRot = -0.12f * lunge;

        // держит добычу: клыки сжаты, голова мотается, тянет носом вниз
        if (grabbing) {
            top_head.xRot = -0.2f;
            bottom_head.xRot = 0.15f;
            head.yRot += Mth.sin(age * 1.4f) * 0.5f;
            body.yRot += Mth.sin(age * 1.4f + 1f) * 0.25f;
            body.xRot += 0.35f;
        }

        // на суше: бьётся боком
        if (!inWater) {
            float flop = Mth.sin(age * 0.9f);
            body.zRot = flop * 0.4f;
            tail.zRot = flop * 0.5f;
            head.zRot = flop * 0.3f;
        } else {
            body.zRot = 0f;
            tail.zRot = 0f;
            head.zRot = 0f;
        }
    }
}
package com.gospi.aquadominus.client.mob;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class SharkRenderState extends LivingEntityRenderState {
    public float attackAnim;
    /** 0..1: фаза укуса (рывок вперёд, пасть раскрывается и захлопывается). */
    public float biteProgress;
    public boolean grabbing;
    public boolean inWater = true;
}
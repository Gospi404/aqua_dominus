package com.gospi.aquadominus.client.mob;

import com.gospi.aquadominus.mob.SharkEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;

public class SharkRenderer extends MobRenderer<SharkEntity, SharkRenderState, SharkModel> {
    private static final Identifier TEXTURE = Identifier.parse("aqua_dominus:textures/entities/shark.png");

    public SharkRenderer(EntityRendererProvider.Context context) {
        super(context, new SharkModel(context.bakeLayer(MobLayers.SHARK)), 0.8f);
    }

    @Override
    public SharkRenderState createRenderState() {
        return new SharkRenderState();
    }

    @Override
    public void extractRenderState(SharkEntity entity, SharkRenderState state, float partialTicks) {
        super.extractRenderState(entity, state, partialTicks);
        state.attackAnim = entity.getAttackAnim(partialTicks);
        state.inWater = entity.isInWater();
        state.biteProgress = entity.biteTick > 0
                ? Mth.clamp(1f - (entity.biteTick - partialTicks) / SharkEntity.BITE_LEN, 0f, 1f) : 0f;
        state.grabbing = entity.grabbing;
    }

    /** Акула крупнее исходной модели. */
    @Override
    protected void scale(SharkRenderState state, PoseStack poseStack) {
        poseStack.scale(1.35f, 1.35f, 1.35f);
    }

    @Override
    public Identifier getTextureLocation(SharkRenderState state) {
        return TEXTURE;
    }
}
package com.gospi.aquadominus.procedures;

import net.neoforged.neoforge.event.entity.player.ItemFishedEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import com.gospi.aquadominus.init.AquaDominusModBlocks;

@EventBusSubscriber
public class CrateBoxFishingProcedure {
	@SubscribeEvent
	public static void onPlayerFishItem(ItemFishedEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_cold_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_frozen_ocean"))
				|| world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("cold_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("frozen_ocean"))) {
			if (Math.random() < 0.4 + (entity instanceof LivingEntity _livingEntity4 && _livingEntity4.getAttributes().hasAttribute(Attributes.LUCK) ? _livingEntity4.getAttribute(Attributes.LUCK).getBaseValue() : 0) / 8) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.COLD_OCEAN_CRATE_BOX.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
		} else if (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_cold_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_frozen_ocean"))
				|| world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_lukewarm_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_ocean"))) {
			if (Math.random() < 0.4 + (entity instanceof LivingEntity _livingEntity13 && _livingEntity13.getAttributes().hasAttribute(Attributes.LUCK) ? _livingEntity13.getAttribute(Attributes.LUCK).getBaseValue() : 0) / 8) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.DEEP_OCEAN_CRATE_BOX.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
		} else if (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("deep_lukewarm_ocean")) || world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("lukewarm_ocean"))
				|| world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("warm_ocean"))) {
			if (Math.random() < 0.4 + (entity instanceof LivingEntity _livingEntity21 && _livingEntity21.getAttributes().hasAttribute(Attributes.LUCK) ? _livingEntity21.getAttribute(Attributes.LUCK).getBaseValue() : 0) / 8) {
				if (Math.random() < 0.7) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.WARM_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.RARE_WARM_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				}
			}
		} else if (world.getBiome(BlockPos.containing(x, y, z)).is(Identifier.parse("ocean"))) {
			if (Math.random() < 0.4 + (entity instanceof LivingEntity _livingEntity31 && _livingEntity31.getAttributes().hasAttribute(Attributes.LUCK) ? _livingEntity31.getAttribute(Attributes.LUCK).getBaseValue() : 0) / 8) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.OCEAN_CRATE_BOX.get()));
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
		} else {
			if (Math.random() < 0.4 + (entity instanceof LivingEntity _livingEntity36 && _livingEntity36.getAttributes().hasAttribute(Attributes.LUCK) ? _livingEntity36.getAttribute(Attributes.LUCK).getBaseValue() : 0) / 8) {
				if (Math.random() < 0.2125) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.WARM_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				} else if (Math.random() < 0.2125) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.DEEP_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				} else if (Math.random() < 0.2125) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				} else if (Math.random() < 0.2125) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.COLD_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn = new ItemEntity(_level, (entity.getX()), (entity.getY()), (entity.getZ()), new ItemStack(AquaDominusModBlocks.RARE_WARM_OCEAN_CRATE_BOX.get()));
						entityToSpawn.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn);
					}
				}
			}
		}
	}
}
package com.gospi.aquadominus.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;

import com.gospi.aquadominus.init.AquaDominusModItems;

public class DivingSuitTickUpdateProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (AquaDominusModItems.DIVING_SUIT_HELMET.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY).getItem()
				&& AquaDominusModItems.DIVING_SUIT_CHESTPLATE.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY).getItem()
				&& AquaDominusModItems.DIVING_SUIT_LEGGINGS.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY).getItem()
				&& AquaDominusModItems.DIVING_SUIT_BOOTS.get() == (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY).getItem()) {
			if (!entity.isUnderWater()) {
				if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.BREATH_OF_THE_NAUTILUS) ? _livEnt.getEffect(MobEffects.BREATH_OF_THE_NAUTILUS).getDuration() : 0) < 560) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.BREATH_OF_THE_NAUTILUS, 600, 0, false, false));
				}
			}
		}
	}
}
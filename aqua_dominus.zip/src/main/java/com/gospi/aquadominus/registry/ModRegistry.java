package com.gospi.aquadominus.registry;

import com.gospi.aquadominus.AquaDominus;
import com.gospi.aquadominus.block.DeepLanternBlock;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.equipment.Equippable;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.RegisterEvent;

public final class ModRegistry {
    public static Block DEEP_LANTERN;
    public static Item DEEP_LANTERN_ITEM, ANKLE_WEIGHT, GIANT_SQUID_SPAWN_EGG;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(AquaDominus.MODID, path);
    }

    private static Item.Properties ip(String n) {
        return new Item.Properties().setId(ResourceKey.create(Registries.ITEM, id(n)));
    }

    private static BlockBehaviour.Properties bp(String n) {
        return BlockBehaviour.Properties.of().setId(ResourceKey.create(Registries.BLOCK, id(n)));
    }

    public static void onRegister(RegisterEvent event) {
        if (DEEP_LANTERN == null) {
            DEEP_LANTERN = new DeepLanternBlock(bp("deep_lantern").strength(3.5F).requiresCorrectToolForDrops()
                    .sound(SoundType.LANTERN).lightLevel(s -> 15).noOcclusion()
                    .pushReaction(PushReaction.DESTROY));
        }

        event.register(Registries.BLOCK, h -> h.register(id("deep_lantern"), DEEP_LANTERN));

        event.register(Registries.ITEM, h -> {
            DEEP_LANTERN_ITEM = new BlockItem(DEEP_LANTERN, ip("deep_lantern").useBlockDescriptionPrefix());

            // Груз = «сапоги»: слот FEET + атрибуты, действующие только пока предмет надет
            ANKLE_WEIGHT = new Item(ip("ankle_weight").stacksTo(1)
                    .component(DataComponents.EQUIPPABLE,
                            Equippable.builder(EquipmentSlot.FEET)
                                    .setEquipSound(SoundEvents.ARMOR_EQUIP_IRON).build())
                    .attributes(ItemAttributeModifiers.builder()
                            .add(Attributes.JUMP_STRENGTH,
                                    new AttributeModifier(id("weight_jump"), -1.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                    EquipmentSlotGroup.FEET)
                            .add(Attributes.MOVEMENT_SPEED,
                                    new AttributeModifier(id("weight_speed"), -0.25, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL),
                                    EquipmentSlotGroup.FEET)
                            .add(Attributes.GRAVITY,
                                    new AttributeModifier(id("weight_gravity"), 0.06, AttributeModifier.Operation.ADD_VALUE),
                                    EquipmentSlotGroup.FEET)
                            .build()));

            h.register(id("deep_lantern"), DEEP_LANTERN_ITEM);
            h.register(id("ankle_weight"), ANKLE_WEIGHT);
        });
    }
}
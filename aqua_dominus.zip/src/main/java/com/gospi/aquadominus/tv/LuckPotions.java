package com.gospi.aquadominus.tv;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.alchemy.Potions;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent;

import static com.gospi.aquadominus.tv.TvPocketMod.MODID;

@EventBusSubscriber(modid = MODID)
public final class LuckPotions {
    @SubscribeEvent
    public static void brewing(RegisterBrewingRecipesEvent e) {
        // предмет pearl из вашего мода; если id другой — поменяйте строку
        Item pearl = BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath(MODID, "pearl"));
        e.getBuilder().addMix(Potions.AWKWARD, pearl, Potions.LUCK);
    }
}
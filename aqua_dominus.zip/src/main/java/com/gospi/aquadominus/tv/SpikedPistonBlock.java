package com.gospi.aquadominus.tv;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

public class SpikedPistonBlock extends DirectionalBlock {
    public static final MapCodec<SpikedPistonBlock> CODEC = simpleCodec(SpikedPistonBlock::new);
    public static final BooleanProperty EXTENDED = BlockStateProperties.EXTENDED;
    static final int ANIM_TICKS = 3;

    // форма выдвинутой базы: срезано 4 пикселя спереди
    private static final VoxelShape E_UP    = Block.box(0, 0, 0, 16, 12, 16);
    private static final VoxelShape E_DOWN  = Block.box(0, 4, 0, 16, 16, 16);
    private static final VoxelShape E_NORTH = Block.box(0, 0, 4, 16, 16, 16);
    private static final VoxelShape E_SOUTH = Block.box(0, 0, 0, 16, 16, 12);
    private static final VoxelShape E_WEST  = Block.box(4, 0, 0, 16, 16, 16);
    private static final VoxelShape E_EAST  = Block.box(0, 0, 0, 12, 16, 16);

    public SpikedPistonBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(EXTENDED, false));
    }

    @Override protected MapCodec<? extends DirectionalBlock> codec() { return CODEC; }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING, EXTENDED);
    }

    @Override public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getNearestLookingDirection().getOpposite())
                .setValue(EXTENDED, false);
    }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        if (!s.getValue(EXTENDED)) return Shapes.block();
        return switch (s.getValue(FACING)) {
            case UP -> E_UP; case DOWN -> E_DOWN; case NORTH -> E_NORTH;
            case SOUTH -> E_SOUTH; case WEST -> E_WEST; case EAST -> E_EAST;
        };
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide() && !old.is(state.getBlock())) check(level, pos, state);
    }

    @Override
    protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block,
                                   @Nullable Orientation orientation, boolean moved) {
        if (!level.isClientSide()) check(level, pos, state);
    }

    private void check(Level level, BlockPos pos, BlockState state) {
        if (!(level instanceof ServerLevel sl)) return;
        Direction f = state.getValue(FACING);
        BlockPos front = pos.relative(f);
        boolean powered = level.hasNeighborSignal(pos);
        boolean ext = state.getValue(EXTENDED);

        if (powered && !ext) {
            if (!level.getBlockState(front).canBeReplaced()) return;
            level.setBlock(pos, state.setValue(EXTENDED, true), 3);
            animate(sl, pos, f, true);
            level.playSound(null, pos, SoundEvents.PISTON_EXTEND, SoundSource.BLOCKS, 0.5f, 1f);
            level.scheduleTick(pos, this, ANIM_TICKS);
        } else if (!powered && ext && level.getBlockState(front).is(TvPocketMod.SPIKED_PISTON_HEAD.get())) {
            level.setBlock(front, Blocks.AIR.defaultBlockState(), 2); // без обновления соседей
            animate(sl, pos, f, false);
            level.playSound(null, pos, SoundEvents.PISTON_CONTRACT, SoundSource.BLOCKS, 0.5f, 1f);
            level.scheduleTick(pos, this, ANIM_TICKS);
        }
    }

    /** Конец анимации (запланированный тик переживает перезапуск сервера). */
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        if (!state.getValue(EXTENDED)) return;
        Direction f = state.getValue(FACING);
        BlockPos front = pos.relative(f);
        TvPocket.run(level, "kill @e[tag=" + animTag(pos) + "]");
        if (level.getBlockState(front).is(TvPocketMod.SPIKED_PISTON_HEAD.get())) return;

        if (level.hasNeighborSignal(pos) && level.getBlockState(front).canBeReplaced()) {
            level.setBlock(front, TvPocketMod.SPIKED_PISTON_HEAD.get().defaultBlockState().setValue(FACING, f), 3);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(front))) {
                e.hurtServer(level, level.damageSources().cactus(), 4f);
                e.push(f.getStepX(), f.getStepY() * 0.6 + 0.2, f.getStepZ());
            }
        } else {
            BlockState folded = state.setValue(EXTENDED, false);
            level.setBlock(pos, folded, 3);
            check(level, pos, folded);
        }
    }

    static String animTag(BlockPos p) { return "aqd_sp_" + p.getX() + "_" + p.getY() + "_" + p.getZ(); }

    /** Голова-дисплей плавно едет от базы вперёд (out=true) или обратно. */
    private static void animate(ServerLevel sl, BlockPos pos, Direction f, boolean out) {
        String step = f.getStepX() + "f," + f.getStepY() + "f," + f.getStepZ() + "f";
        String zero = "0f,0f,0f";
        String tag = animTag(pos);
        String rest = ",scale:[1f,1f,1f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}";
        TvPocket.run(sl, "summon minecraft:block_display " + pos.getX() + " " + pos.getY() + " " + pos.getZ()
                + " {Tags:[\"" + tag + "\"],block_state:{Name:\"" + TvPocketMod.MODID
                + ":spiked_piston_head\",Properties:{facing:\"" + f.getName() + "\"}},"
                + "transformation:{translation:[" + (out ? zero : step) + "]" + rest + "}");
        TvPocket.schedule(sl.getServer(), 1, () -> TvPocket.run(sl,
                "data merge entity @e[tag=" + tag + ",limit=1] {start_interpolation:0,interpolation_duration:"
                        + (ANIM_TICKS - 1) + ",transformation:{translation:[" + (out ? step : zero) + "]" + rest + "}"));
    }
}
package com.gospi.aquadominus.tv;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.ScheduledTickAccess;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class SpikedPistonHeadBlock extends DirectionalBlock {
    public static final MapCodec<SpikedPistonHeadBlock> CODEC = simpleCodec(SpikedPistonHeadBlock::new);

    // пластина 4 пикселя спереди + стержень 4x4
    private static final VoxelShape UP    = Shapes.or(Block.box(0, 12, 0, 16, 16, 16), Block.box(6, 0, 6, 10, 12, 10));
    private static final VoxelShape DOWN  = Shapes.or(Block.box(0, 0, 0, 16, 4, 16),   Block.box(6, 4, 6, 10, 16, 10));
    private static final VoxelShape NORTH = Shapes.or(Block.box(0, 0, 0, 16, 16, 4),   Block.box(6, 6, 4, 10, 10, 16));
    private static final VoxelShape SOUTH = Shapes.or(Block.box(0, 0, 12, 16, 16, 16), Block.box(6, 6, 0, 10, 10, 12));
    private static final VoxelShape WEST  = Shapes.or(Block.box(0, 0, 0, 4, 16, 16),   Block.box(4, 6, 6, 16, 10, 10));
    private static final VoxelShape EAST  = Shapes.or(Block.box(12, 0, 0, 16, 16, 16), Block.box(0, 6, 6, 12, 10, 10));

    public SpikedPistonHeadBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override protected MapCodec<? extends DirectionalBlock> codec() { return CODEC; }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        return switch (s.getValue(FACING)) {
            case UP -> UP; case DOWN -> DOWN; case NORTH -> NORTH;
            case SOUTH -> SOUTH; case WEST -> WEST; case EAST -> EAST;
        };
    }

    @Override
    protected boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        Direction f = state.getValue(FACING);
        BlockState base = level.getBlockState(pos.relative(f.getOpposite()));
        return base.is(TvPocketMod.SPIKED_PISTON.get())
                && base.getValue(SpikedPistonBlock.FACING) == f
                && base.getValue(SpikedPistonBlock.EXTENDED);
    }

    @Override
    protected BlockState updateShape(BlockState state, LevelReader level, ScheduledTickAccess ticks, BlockPos pos,
                                     Direction dir, BlockPos neighborPos, BlockState neighborState, RandomSource rand) {
        return canSurvive(state, level, pos) ? state : Blocks.AIR.defaultBlockState();
    }

    // сломал голову -> ломается и основа (без лишнего дропа)
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide()) {
            BlockPos basePos = pos.relative(state.getValue(FACING).getOpposite());
            if (level.getBlockState(basePos).is(TvPocketMod.SPIKED_PISTON.get()))
                level.destroyBlock(basePos, false);
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moved) {
        if (!level.isClientSide()) level.scheduleTick(pos, this, 10);
    }

    // шипы колют всех рядом каждые полсекунды (достают и до кончиков шипов)
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        Direction f = state.getValue(FACING);
        AABB box = new AABB(pos).inflate(0.15)
                .expandTowards(f.getStepX() * 0.3, f.getStepY() * 0.3, f.getStepZ() * 0.3);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box))
            e.hurtServer(level, level.damageSources().cactus(), 2f);
        level.scheduleTick(pos, this, 10);
    }
}
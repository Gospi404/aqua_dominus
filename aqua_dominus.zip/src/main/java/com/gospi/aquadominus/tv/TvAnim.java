package com.gospi.aquadominus.tv;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

final class TvAnim {
    static final int DURATION = 50; // тиков до исчезновения ТВ

    static void play(ServerPlayer p, ServerLevel lv, BlockPos o, Direction f) {
        MinecraftServer s = lv.getServer();
        String tv = "aqd_tv_" + p.getUUID();

        // ТВ создавался в (x-.5, y, z-.5) от позиции игрока; центр = позиция игрока
        final double bx = p.getX() - .5, by = p.getY(), bz = p.getZ() - .5;
        final double cx = p.getX(), cy = p.getY() + .5, cz = p.getZ();

        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, DURATION + 10, 0, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DURATION + 10, 10, false, false));
        lv.playSound(null, o, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1.5f);

        for (int t = 0; t < DURATION; t += 2) {
            final int tt = t;
            TvPocket.schedule(s, tt, () -> {
                double k = tt / (double) DURATION;
                double lift = 0.25 * Math.sin(Math.PI * k);
                double amp = 0.03 * Math.min(1.0, tt / 20.0);
                var r = lv.getRandom();
                for (Entity e : find(lv, tv)) { // ищем заново: чанк мог загрузиться позже
                    TvPocket.run(lv, "data merge entity " + e.getUUID() + " {teleport_duration:2}");
                    e.setPos(bx + (r.nextDouble() - .5) * amp, by + lift, bz + (r.nextDouble() - .5) * amp);
                }
                lv.sendParticles(ParticleTypes.ELECTRIC_SPARK, cx, cy + lift, cz, 6, .5, .5, .5, .3);
                lv.sendParticles(ParticleTypes.REVERSE_PORTAL, cx, cy + lift, cz, 4, .4, .4, .4, .05);
                if (k > .5) lv.sendParticles(ParticleTypes.END_ROD, cx, cy + lift, cz, 2, .4, .5, .4, .02);
            });
        }
        TvPocket.schedule(s, 20, () ->
                lv.playSound(null, o, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 1.0f));
        TvPocket.schedule(s, 36, () ->
                lv.playSound(null, o, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1f, 1.6f));

        TvPocket.schedule(s, DURATION, () -> {
            removeTv(lv, tv);
            p.removeEffect(MobEffects.INVISIBILITY);
            p.removeEffect(MobEffects.SLOWNESS);
            lv.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, cx, cy, cz, 40, .4, .6, .4, .3);
            lv.sendParticles(ParticleTypes.POOF, cx, cy, cz, 20, .4, .5, .4, .03);
            lv.playSound(null, o, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1.4f);
        });
        // страховка: если чанк загрузился совсем поздно
        TvPocket.schedule(s, DURATION + 20, () -> removeTv(lv, tv));
        TvPocket.schedule(s, DURATION + 60, () -> removeTv(lv, tv));
    }

    private static List<Entity> find(ServerLevel lv, String tag) {
        List<Entity> out = new ArrayList<>();
        for (Entity e : lv.getAllEntities())
            if (e.entityTags().contains(tag)) out.add(e);
        return out;
    }

    private static void removeTv(ServerLevel lv, String tag) {
        find(lv, tag).forEach(Entity::discard);
        TvPocket.run(lv, "kill @e[tag=" + tag + "]");
    }
}
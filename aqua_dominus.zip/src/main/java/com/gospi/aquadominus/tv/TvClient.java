package com.gospi.aquadominus.tv;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.network.ClientPacketDistributor;
import org.lwjgl.glfw.GLFW;

import static com.gospi.aquadominus.tv.TvPocketMod.MODID;

@EventBusSubscriber(modid = MODID, value = Dist.CLIENT)
public final class TvClient {
    static final KeyMapping.Category CAT = new KeyMapping.Category(Identifier.fromNamespaceAndPath(MODID, "main"));
    static final KeyMapping KEY = new KeyMapping("key." + MODID + ".tv_pocket",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CAT);

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.registerCategory(CAT);
        e.register(KEY);
    }

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post e) {
        while (KEY.consumeClick()) ClientPacketDistributor.sendToServer(new TvNet.EnterPayload());
    }
}
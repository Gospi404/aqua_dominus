package com.gospi.aquadominus.tv;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

import static com.gospi.aquadominus.tv.TvPocketMod.MODID;

@EventBusSubscriber(modid = MODID)
public final class TvNet {
    public record EnterPayload() implements CustomPacketPayload {
        public static final Type<EnterPayload> TYPE = new Type<>(Identifier.fromNamespaceAndPath(MODID, "tv_enter"));
        public static final StreamCodec<ByteBuf, EnterPayload> CODEC = StreamCodec.unit(new EnterPayload());
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent e) {
        e.registrar("1").playToServer(EnterPayload.TYPE, EnterPayload.CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) TvPocket.enter(sp);
                }));
    }
}
package com.gospi.aquadominus.tv;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Display;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;

import static com.gospi.aquadominus.tv.TvPocketMod.MODID;

@EventBusSubscriber(modid = MODID)
public final class TvPocket {
    public static final ResourceKey<Level> DIM =
            ResourceKey.create(Registries.DIMENSION, Identifier.fromNamespaceAndPath(MODID, "tv_pocket"));
    // ВАЖНО: проверка по нику легко подделывается на пиратских серверах. Лучше сверять UUID.
    public static final Set<String> ALLOWED = Set.of("Gospi_", "Dev");
    static final BlockPos EXIT_TV = new BlockPos(0, 64, -3);
    static final int FLOATERS = 15;
    static final String FLOATER = "aqd_floater";
    static final String ID_TRANSFORM =
            "transformation:{translation:[0f,0f,0f],scale:[1f,1f,1f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}";

    public record ReturnData(String dim, double x, double y, double z, float yaw, float pitch, String facing) {
        public static final ReturnData NONE = new ReturnData("", 0, 0, 0, 0, 0, "north");
        public static final Codec<ReturnData> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("dim").forGetter(ReturnData::dim),
                Codec.DOUBLE.fieldOf("x").forGetter(ReturnData::x),
                Codec.DOUBLE.fieldOf("y").forGetter(ReturnData::y),
                Codec.DOUBLE.fieldOf("z").forGetter(ReturnData::z),
                Codec.FLOAT.fieldOf("yaw").forGetter(ReturnData::yaw),
                Codec.FLOAT.fieldOf("pitch").forGetter(ReturnData::pitch),
                Codec.STRING.fieldOf("facing").forGetter(ReturnData::facing)
        ).apply(i, ReturnData::new));
    }

    // ---------- ВХОД ----------
    public static void enter(ServerPlayer p) {
        if (!ALLOWED.contains(p.getName().getString()) || p.level().dimension() == DIM) return;
        ServerLevel from = p.level();
        MinecraftServer server = from.getServer();
        ServerLevel pocket = server.getLevel(DIM);
        if (pocket == null) {
            p.sendSystemMessage(Component.literal("Измерение aqua_dominus:tv_pocket не найдено (проверь data/...)"));
            return;
        }
        Direction f = p.getDirection();
        BlockPos o = p.blockPosition();

                p.setData(TvPocketMod.RETURN, new ReturnData(from.dimension().identifier().toString(),
                p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot(), f.getName()));

        // телевизор-сущность на месте игрока
                run(from, String.format(Locale.ROOT,
                "summon minecraft:block_display %s %s %s {Tags:[\"aqd_tv_%s\"],block_state:{Name:\"%s:pocket_tv\",Properties:{facing:\"%s\"}},%s}",
                p.getX() - .5, p.getY(), p.getZ() - .5, p.getUUID(), MODID, f.getName(), ID_TRANSFORM));
        from.playSound(null, o, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 0.6f);

        // платформа и выходной ТВ (создаются один раз)
        if (pocket.getBlockState(new BlockPos(0, 63, 0)).isAir()) {
            for (int x = -4; x <= 4; x++)
                for (int z = -4; z <= 4; z++)
                    pocket.setBlock(new BlockPos(x, 63, z), Blocks.PURPLE_CONCRETE.defaultBlockState(), 3);
        }
        if (!pocket.getBlockState(EXIT_TV).is(TvPocketMod.TV.get())) {
            pocket.setBlock(EXIT_TV, TvPocketMod.TV.get().defaultBlockState()
                    .setValue(PocketTvBlock.FACING, Direction.SOUTH), 3);
        }

        p.teleportTo(pocket, 0.5, 64, 0.5, Set.of(), 180f, 0f, true);
                schedule(server, 40, () -> spawnFloaters(pocket));
    }

    // ---------- ВЫХОД ----------
    public static void exit(ServerPlayer p) {
        MinecraftServer server = p.level().getServer();
        ReturnData d = p.getData(TvPocketMod.RETURN);
        ServerLevel to = d.dim().isEmpty() ? null
                : server.getLevel(ResourceKey.create(Registries.DIMENSION, Identifier.parse(d.dim())));
        if (to == null) { // запасной вариант: данных нет
            ServerLevel ow = server.overworld();
            int y = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, 0, 0);
            p.teleportTo(ow, 0.5, y, 0.5, Set.of(), 0f, 0f, true);
            return;
        }
        p.teleportTo(to, d.x(), d.y(), d.z(), Set.of(), d.yaw(), d.pitch(), true);
        p.removeData(TvPocketMod.RETURN);
        Direction f = Direction.byName(d.facing());
        TvAnim.play(p, to, BlockPos.containing(d.x(), d.y(), d.z()), f == null ? Direction.NORTH : f);
    }

    // ---------- летающие телевизоры ----------
        static void spawnFloaters(ServerLevel pocket) {
        int n = 0;
        List<Entity> old = new ArrayList<>();
        for (Entity e : pocket.getAllEntities()) {
            if (!(e instanceof Display.BlockDisplay)) continue;
            if (e.entityTags().contains(FLOATER)) n++;
            else old.add(e); // телевизоры старой раскладки
        }
        old.forEach(Entity::discard);
        if (n >= FLOATERS) return;

        var r = pocket.getRandom();
        for (int i = n; i < FLOATERS; i++) {
            double s = 1.5 + r.nextDouble() * 3.5;
            double ang = i * Math.TAU / FLOATERS + (r.nextDouble() - .5) * 0.25;
            double rad = 16 + r.nextDouble() * 16;
            double dx = rad * Math.cos(ang), dz = rad * Math.sin(ang);
            double x = .5 + dx, z = .5 + dz;
            double y = 56 + r.nextDouble() * 30;
            float yaw = (float) Math.toDegrees(Math.atan2(dx, -dz)); // экраном к острову
            run(pocket, String.format(Locale.ROOT,
                    "summon minecraft:block_display %s %s %s {Tags:[\"%s\",\"aqd_s_%d\"],view_range:4f,Rotation:[%sf,0f],"
                            + "block_state:{Name:\"%s:pocket_tv\",Properties:{facing:\"south\"}},%s}",
                    x, y, z, FLOATER, (int) (s * 100), yaw, MODID, floaterTransform(s, 0f, 0f, 0f)));
        }
    }

    /** transformation с поворотом вокруг центра ТВ (s — размер). */
    static String floaterTransform(double s, float ax, float ay, float az) {
        Quaternionf q = new Quaternionf().rotationXYZ(ax, ay, az);
        Vector3f c = new Vector3f((float) s / 2, (float) s / 2, (float) s / 2);
        q.transform(c); // где оказывается центр коробки после поворота
        return String.format(Locale.ROOT,
                "transformation:{translation:[%sf,%sf,%sf],scale:[%sf,%sf,%sf],left_rotation:[%sf,%sf,%sf,%sf],right_rotation:[0f,0f,0f,1f]}",
                -c.x, -c.y, -c.z, s, s, s, q.x, q.y, q.z, q.w);
    }

    /** Новый плавный наклон для каждого телевизора. */
    static void wobbleFloaters(ServerLevel pocket) {
        var r = pocket.getRandom();
        List<Entity> list = new ArrayList<>();
        for (Entity en : pocket.getAllEntities())
            if (en.entityTags().contains(FLOATER)) list.add(en);
        for (Entity en : list) {
            double s = 3;
            for (String t : en.entityTags())
                if (t.startsWith("aqd_s_")) s = Integer.parseInt(t.substring(6)) / 100.0;
            run(pocket, "data merge entity " + en.getUUID() + " {start_interpolation:0,interpolation_duration:60,"
                    + floaterTransform(s, r.nextFloat() - .5f, r.nextFloat() - .5f, r.nextFloat() - .5f) + "}");
        }
    }

    // ---------- утилиты ----------
    public static void run(ServerLevel lv, String cmd) {
        MinecraftServer s = lv.getServer();
        s.getCommands().performPrefixedCommand(s.createCommandSourceStack().withLevel(lv).withSuppressedOutput(), cmd);
    }

    private record Task(long due, Runnable r) {}
    private static final List<Task> TASKS = new ArrayList<>();

    public static void schedule(MinecraftServer s, int delay, Runnable r) {
        TASKS.add(new Task(s.getTickCount() + delay, r));
    }

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post e) {
        MinecraftServer s = e.getServer();
        long now = s.getTickCount();
        for (Task t : new ArrayList<>(TASKS)) if (t.due() <= now) { TASKS.remove(t); t.r().run(); }

        ServerLevel pocket = s.getLevel(DIM);
        if (pocket == null || pocket.players().isEmpty()) return;
        if (now % 60 == 0) wobbleFloaters(pocket);
        for (ServerPlayer pl : pocket.players()) // упал в бездну -> обратно на платформу
            if (pl.getY() < -20) pl.teleportTo(pocket, 0.5, 64, 0.5, Set.of(), 180f, 0f, true);
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("tvpocket").executes(ctx -> {
            TvPocket.enter(ctx.getSource().getPlayerOrException());
            return 1;
        }));
    }
}

package com.gospi.aquadominus.tv;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.*;

import java.util.function.Supplier;

@Mod(TvPocketMod.MODID)
public class TvPocketMod {
    public static final String MODID = "aqua_dominus";

    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(MODID);

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(MODID);

    public static final DeferredBlock<SpikedPistonBlock> SPIKED_PISTON = BLOCKS.registerBlock("spiked_piston",
        SpikedPistonBlock::new,
        () -> BlockBehaviour.Properties.of().strength(1.5f).sound(SoundType.STONE));
public static final DeferredBlock<SpikedPistonHeadBlock> SPIKED_PISTON_HEAD = BLOCKS.registerBlock("spiked_piston_head",
        SpikedPistonHeadBlock::new,
        () -> BlockBehaviour.Properties.of().strength(1.5f).noOcclusion().noLootTable().sound(SoundType.STONE));
public static final DeferredItem<BlockItem> SPIKED_PISTON_ITEM = ITEMS.registerSimpleBlockItem(SPIKED_PISTON);

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MODID);

    public static final DeferredBlock<PocketTvBlock> TV =
            BLOCKS.registerBlock("pocket_tv", PocketTvBlock::new,
                    () -> BlockBehaviour.Properties.of()
                            .strength(-1f, 3600000f)
                            .noOcclusion()
                            .lightLevel(s -> 10)
                            .sound(SoundType.GLASS));

    public static final DeferredItem<BlockItem> TV_ITEM =
            ITEMS.registerSimpleBlockItem(TV);

    public static final Supplier<AttachmentType<TvPocket.ReturnData>> RETURN =
            ATTACHMENTS.register("tv_return", () ->
                    AttachmentType.builder(() -> TvPocket.ReturnData.NONE)
                            .serialize(TvPocket.ReturnData.CODEC.fieldOf("data"))
                            .build()
            );

    public TvPocketMod(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        ATTACHMENTS.register(bus);
    }
}
